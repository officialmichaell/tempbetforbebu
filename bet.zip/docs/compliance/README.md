# TemP — Compliance, Safety & Responsible Gaming

> **This is a prototype.** TemP ships with **mock providers only**. No real
> money is processed, no real sportsbook/casino/payment integration is wired,
> and every real-money feature flag defaults to `false`. Nothing in this
> repository constitutes a claim of licensing, regulatory approval, or legal
> compliance in any jurisdiction.

---

## 1. Development rules (non-negotiable)

These rules are enforced throughout the codebase:

1. **No fake payment integrations.** Payment providers are mocks behind an
   interface. We never pretend a real gateway is connected.
2. **No unauthorized third-party APIs.** We do not call 1xBet or any other
   proprietary betting API without a signed agreement.
3. **Mock providers only** in this build (`MockSportsbookProvider`,
   `MockCasinoProvider`, `MockPaymentProvider`).
4. **Never trust the client** for balance, odds, or bet results — all
   authoritative computation is server-side.
5. **Never expose secrets.** Bot tokens, JWT secrets, and DB credentials live
   only in server env.
6. **Keep provider integrations behind interfaces** so they can be swapped
   without touching call sites.
7. **Keep real-money disabled by default.**
8. **Do not copy proprietary branding or assets.** TemP uses its own “P” mark
   and palette; no third-party logos, screenshots, or copy.
9. **No fake regulatory claims.** We never state or imply we are licensed.
10. **Do not claim to be licensed** anywhere in UI, docs, or metadata.

## 2. Feature flags

All flags default to the safe value. Real money is opt-in and gated.

| Flag | Default | Meaning |
| --- | --- | --- |
| `ENABLE_TELEGRAM_AUTH` | `true` | Verify Telegram initData |
| `ENABLE_MOCK_BETTING` | `true` | Allow mock bet placement |
| `ENABLE_MOCK_WALLET` | `true` | Allow mock wallet movements |
| `ENABLE_REAL_BETTING` | `false` | Route bets to a real provider |
| `ENABLE_REAL_PAYMENTS` | `false` | Route payments to a real gateway |
| `ENABLE_WITHDRAWALS` | `true` | Allow withdrawal requests |
| `ENABLE_CASINO` | `true` | Show casino games |
| `ENABLE_SPORTSBOOK` | `true` | Show sportsbook |
| `REAL_MONEY_ENABLED` | `false` | Master real-money switch |
| `PRODUCTION_BETTING_ENABLED` | `false` | Production betting switch |
| `PAYMENTS_ENABLED` | `false` | Production payments switch |

## 3. Responsible gaming

TemP includes first-class responsible-gaming tooling:

- **Deposit limits** — daily / weekly / monthly caps.
- **Loss limits** — session and period loss caps.
- **Session reminders** — periodic “time played” nudges.
- **Reality checks** — elapsed-time and net-position summaries.
- **Self-exclusion** — temporary or permanent cool-off.
- **Cool-off periods** — 24h / 7d / 30d.
- **Age gate** — 18+ (or the local legal minimum) at onboarding.
- **Support resources** — links to help and a direct line to support.

These live under **Profile → Responsible Gaming** and are backed by the
`users` preferences and `settings` module.

## 4. KYC / AML posture (production roadmap)

Not implemented in the prototype. Before any real-money launch, the following
must be built and reviewed by counsel:

- Identity verification (KYC) at deposit/withdrawal thresholds.
- AML transaction monitoring and suspicious-activity reporting.
- Sanctions / PEP screening.
- Source-of-funds checks for large transactions.
- Record retention per local law.

## 5. Data protection

- Collect the minimum: Telegram ID, display name, and gameplay data.
- Store credentials and secrets encrypted at rest.
- Encrypt in transit (TLS everywhere).
- Provide data export and deletion on request.
- Log access to sensitive data in `audit_logs`.

## 6. Jurisdiction

Betting and gaming are regulated activities. **Do not operate for real money
in any jurisdiction without the required licence.** The Ethiopian market
context in this project is a product-design target only; it is not a statement
of regulatory status. Operators are responsible for obtaining all necessary
approvals before enabling real money.

## 7. Auditability

Every privileged action (admin login, wallet adjustment, deposit/withdrawal
decision, bet settlement, settings change) writes an immutable `audit_logs`
row capturing actor, action, target, before/after, and timestamp.

## 8. Production go-live checklist

- [ ] Legal review completed for target jurisdiction(s).
- [ ] Required licences obtained (if any).
- [ ] KYC/AML implemented and reviewed.
- [ ] Real payment provider contracted and integrated behind the interface.
- [ ] Real sportsbook/casino provider contracted and integrated.
- [ ] Real-money flags deliberately enabled in production only.
- [ ] Responsible-gaming limits enforced server-side.
- [ ] Penetration test passed.
- [ ] Backups, monitoring, and incident response in place.
- [ ] Terms of Service, Privacy Policy, and Responsible Gaming pages published.
