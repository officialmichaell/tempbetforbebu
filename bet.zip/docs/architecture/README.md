# TemP — Architecture

TemP is a **Telegram-native betting & gaming Mini App** for the Ethiopian market
(currency: **ETB**). This document describes the system architecture, the
monorepo layout, the data flow, and the safety model.

> **Prototype notice.** This build ships with **mock providers only**. No real
> money moves, no real sportsbook/casino/payment integration is wired, and all
> real-money feature flags default to `false`. See `docs/compliance/README.md`.

---

## 1. High-level topology

```
┌──────────────────────────────────────────────────────────────────────┐
│                          Telegram Client                              │
│   ┌────────────────────────┐        ┌────────────────────────────┐    │
│   │  TemP Mini App (web)   │        │  Admin Panel (admin)       │    │
│   │  React + Vite + TW     │        │  React + Vite + TW         │    │
│   └───────────┬────────────┘        └──────────────┬─────────────┘    │
└───────────────┼────────────────────────────────────┼──────────────────┘
                │  HTTPS (initData header)           │  HTTPS (JWT)
                ▼                                    ▼
        ┌───────────────────────────────────────────────────┐
        │              NestJS API (apps/api)                 │
        │  Auth · Wallet · Deposits · Withdrawals · Bets     │
        │  Sportsbook · Games · Promotions · Support · Admin │
        │  ── Provider interfaces ──                         │
        │     MockSportsbook · MockCasino · MockPayment      │
        └───────────────┬───────────────────────┬───────────┘
                        │                       │
                        ▼                       ▼
                 ┌────────────┐          ┌────────────┐
                 │ PostgreSQL │          │   Redis    │
                 │ (ledger)   │          │ (cache/RL) │
                 └────────────┘          └────────────┘
```

## 2. Monorepo layout

```
p-betting/
├── apps/
│   ├── web/        # Telegram Mini App (the star)
│   ├── api/        # NestJS backend
│   └── admin/      # Admin panel (separate app)
├── packages/
│   ├── ui/         # Shared design-system primitives
│   ├── types/      # Shared domain types
│   ├── config/     # Brand, colors, feature flags
│   └── utils/      # formatETB, odds math, seeded RNG, etc.
├── database/
│   ├── migrations/ # 001_init.sql (27 tables)
│   ├── seeds/      # deterministic seed data
│   ├── migrate.js  # migration runner
│   └── seed.js     # seed runner
├── docker/         # Dockerfiles + nginx
├── docs/           # architecture / api / telegram / compliance
├── docker-compose.yml
├── .env.example
└── package.json    # npm workspaces root
```

Workspaces are declared in the root `package.json` (`apps/*`, `packages/*`).
Shared packages are consumed via the `@temp/*` scope and resolved through
Vite aliases (web/admin) and tsconfig paths (api).

## 3. Frontend (apps/web)

- **Stack:** React 18, TypeScript, Vite 5, Tailwind CSS 3, Framer Motion 11,
  react-router-dom 6.
- **Shell:** a fixed glass header (logo, balance, hide/show, deposit, avatar)
  and a 4-tab bottom navigation — **Games · Promo · Contact · Profile**.
- **Telegram integration:** `src/lib/telegram.ts` wraps `window.Telegram.WebApp`,
  expands the viewport, applies theme/safe-area insets, and exposes `initData`.
  When no Telegram context is present (local dev), it falls back to a mock user
  so the prototype is fully testable in a normal browser.
- **State:** `src/store/AppContext.tsx` holds session, wallet, bet slip, and
  notifications. All money math is display-only; the server is the source of
  truth.
- **Mock data:** `src/lib/mockData.ts` deterministically generates 40 launch
  games, 10 coming-soon games, 6 sports with events/markets/odds, promotions,
  promo codes, leaderboard, streak, cashback, and notifications using a seeded
  PRNG (`mulberry32`) so the UI is stable across reloads.

### Design system

Glassmorphism on a deep-black canvas. Tokens live in `packages/config` and are
mirrored as CSS custom properties in `apps/web/src/styles/index.css`.

| Token | Value |
| --- | --- |
| Deep Black | `#080B10` |
| Dark Navy | `#0D1420` |
| Dark Surface | `#111927` |
| Glass | `rgba(255,255,255,0.05)` |
| Glass Border | `rgba(255,255,255,0.08)` |
| Electric Blue | `#2196FF` |
| Bright Blue | `#3B9CFF` |
| Purple | `#8B5CF6` |
| Cyan | `#22D3EE` |
| Success | `#22C55E` |
| Danger | `#EF4444` |
| Reward Gold | `#F5C518` |
| Muted | `#94A3B8` |

Glass card recipe: `background: rgba(255,255,255,0.05)`,
`backdrop-filter: blur(20px)`, `border: 1px solid rgba(255,255,255,0.08)`,
`box-shadow: 0 10px 40px rgba(0,0,0,0.25)`, `border-radius: 20px`.

## 4. Backend (apps/api)

- **Stack:** NestJS 10, TypeORM 0.3, PostgreSQL, Redis, class-validator,
  Passport-JWT, Swagger, Helmet, Throttler.
- **Global prefix:** `/api`. **Swagger:** `/api/docs`.
- **Modules:** `auth`, `wallet`, `deposits`, `withdrawals`, `sportsbook`,
  `bets`, `games`, `promotions`, `misc` (notifications, support, leaderboard,
  cashback, streak, settings).
- **Guards:** `JwtAuthGuard` (global via `APP_GUARD`), `RolesGuard` for RBAC,
  `@Public()` and `@Roles()` decorators.
- **Rate limiting:** `ThrottlerModule` at 120 requests / minute / IP by default.

### The wallet ledger (the most important part)

The wallet is **ledger-based**, never a mutable balance field that clients can
touch. Every financial movement is a row in `wallet_transactions` with a unique
`idempotency_key`. `WalletService.applyTransaction()`:

1. If an `idempotencyKey` is supplied and a matching row exists, **return it**
   (no double-credit).
2. Otherwise open a DB transaction and lock the wallet row with
   `pessimistic_write`.
3. Compute `next = round(current + amount, 2)`; reject if `next < 0`
   (`Insufficient balance`).
4. Persist the new balance **and** append the ledger row atomically.

This guarantees the four required properties: **atomic, idempotent, auditable,
server-side**.

### Provider abstraction

All third-party integrations sit behind interfaces in
`apps/api/src/providers/interfaces.ts`:

- `SportsbookProvider` — `getSports`, `getEvents`, `getEvent`, `placeBet`
- `CasinoProvider` — `getGames`, `launchGame`
- `PaymentProvider` — `createDeposit`, `createWithdrawal`, `verifyWebhook`

The prototype binds `MockSportsbookProvider`, `MockCasinoProvider`, and
`MockPaymentProvider`. Swapping in a real provider means implementing the
interface and changing one binding — no call-site changes.

## 5. Data flow — placing a bet

```
Mini App                API                         DB
   │  POST /api/bets      │                          │
   │  (initData header)   │                          │
   ├─────────────────────►│ verify initData (HMAC)   │
   │                      │ issue/verify JWT         │
   │                      │ validate selections      │
   │                      │ provider.placeBet()      │
   │                      │ applyTransaction(-stake) │──► ledger row (idempotent)
   │                      │ insert bet + selections  │──► bets / bet_selections
   │◄─────────────────────┤ { bet, newBalance }      │
```

## 6. Data flow — agent deposit

```
User → Deposit (PENDING) → Agent confirms (AGENT_CONFIRMED)
     → risk review (UNDER_REVIEW) → Admin (APPROVED | REJECTED)
     → on APPROVED: applyTransaction(+amount, idempotencyKey=deposit_<id>)
```

Withdrawals follow the parallel lifecycle:
`REQUESTED → UNDER_REVIEW → APPROVED → PROCESSING → COMPLETED`
(with `REJECTED` / `CANCELLED` as terminal alternatives). Funds are held at
request time and released on rejection.

## 7. Admin (apps/admin)

A separate React app (port 5174) with a sidebar of 15 sections: Dashboard,
Users, Wallet, Deposits, Withdrawals, Agents, Bets, Sportsbook, Games,
Promotions, Leaderboard, Notifications, Support, Settings, Audit Logs. It uses
the same glass design language plus data-table primitives (search, filter,
pagination). In production it authenticates against the API with an admin JWT
and the `admin` role.

## 8. Safety model

- **Never trust the client.** Balances, odds, and bet outcomes are computed
  server-side. The client only renders.
- **Secrets stay server-side.** The Telegram bot token is used only to derive
  the initData secret key; it is never sent to the browser.
- **Feature flags gate real money.** `REAL_MONEY_ENABLED`,
  `PRODUCTION_BETTING_ENABLED`, `PAYMENTS_ENABLED`, `ENABLE_REAL_BETTING`,
  `ENABLE_REAL_PAYMENTS` all default to `false`.
- **Auditability.** Every privileged action writes an `audit_logs` row.
- **Idempotency.** Financial endpoints accept an idempotency key so retries are
  safe.

## 9. Environments

| Env | Purpose | Real money |
| --- | --- | --- |
| `development` | local, mock providers, seeded DB | off |
| `staging` | pre-prod, mock providers, prod-like infra | off |
| `production` | live infra, real providers (when enabled) | gated by flags |

See `docs/api/README.md` for endpoint reference, `docs/telegram/README.md` for
Mini App setup, and `docs/compliance/README.md` for the legal/safety posture.
