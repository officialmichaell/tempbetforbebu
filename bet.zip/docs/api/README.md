# TemP — API Reference

Base URL: `http://localhost:3000/api` (dev) · Swagger UI: `/api/docs`

All endpoints are **JSON over HTTPS**. Authenticated endpoints require a bearer
JWT issued by `POST /api/auth/telegram`. The Mini App sends its Telegram
`initData` in the `X-Telegram-Init-Data` header (or in the login body) so the
server can verify it before issuing a token.

> **Prototype notice.** All providers are mocks. No real money moves. Real-money
> flags default to `false`.

---

## Authentication

### `POST /api/auth/telegram`
Exchange verified Telegram `initData` for a JWT.

```json
// request
{ "initData": "query_id=...&user=%7B...%7D&hash=..." }

// response
{
  "accessToken": "eyJ...",
  "user": { "id": "...", "telegram_id": 700000001, "first_name": "Abebe", "role": "user" }
}
```

The server recomputes the HMAC-SHA256 signature using the secret key
`HMAC_SHA256("WebAppData", botToken)` and rejects any mismatch, tampering, or
expired payload. In development with no bot token configured, a deterministic
mock user is returned so the prototype is testable.

### `GET /api/auth/me`
Returns the current authenticated user.

---

## Wallet

### `GET /api/wallet`
Returns the caller's wallet (balance, bonus balance, pending balance, currency).

### `GET /api/wallet/transactions`
Returns the immutable ledger, newest first.

```json
[
  { "id": "tx_1", "type": "deposit", "amount": "500.00", "balance_after": "500.00",
    "description": "Agent deposit", "created_at": "2024-09-07T10:00:00Z" }
]
```

Ledger entry types: `deposit`, `withdrawal`, `bet_stake`, `bet_win`,
`bet_refund`, `bonus`, `cashback`, `adjustment`.

---

## Deposits (agent-assisted)

### `POST /api/deposits`
Create a deposit request.

```json
{ "amount": 500, "method": "Telebirr", "agentId": "ag_1", "reference": "TX123" }
```

### `GET /api/deposits` · `GET /api/deposits/:id`
List / fetch deposits.

**Lifecycle:** `PENDING → AGENT_CONFIRMED → UNDER_REVIEW → APPROVED | REJECTED | CANCELLED`.
On `APPROVED`, the wallet is credited exactly once via
`applyTransaction(+amount, idempotencyKey="deposit_<id>")`.

---

## Withdrawals

### `POST /api/withdrawals`
Request a withdrawal. Funds are held immediately.

```json
{ "amount": 200, "method": "Telebirr", "account": "+2519XXXXXXXX" }
```

### `GET /api/withdrawals` · `GET /api/withdrawals/:id`

**Lifecycle:** `REQUESTED → UNDER_REVIEW → APPROVED → PROCESSING → COMPLETED`
(alternatives: `REJECTED`, `CANCELLED`). On rejection the held funds are
released back to the wallet.

---

## Sportsbook

### `GET /api/sports`
List sports.

### `GET /api/events?sport=s1&live=true`
List events with markets and selections. `live` filters in-play events.

### `GET /api/events/:id`
Single event with full market list.

---

## Bets

### `POST /api/bets`
Place a bet (mock). Server validates selections, computes odds, debits the
stake atomically, and records the bet.

```json
{
  "type": "accumulator",
  "stake": 100,
  "idempotencyKey": "bet_abc123",
  "selections": [
    { "eventId": "evt_1", "selectionId": "evt_1_s1", "odds": 2.0 },
    { "eventId": "evt_2", "selectionId": "evt_2_s1", "odds": 1.5 }
  ]
}
```

```json
// response
{ "id": "bet_1", "status": "open", "totalOdds": 3.0, "potentialWin": 300,
  "stake": "100.00", "newBalance": "400.00" }
```

### `GET /api/bets` · `GET /api/bets/:id`
Bet history / detail with selections.

---

## Games

### `GET /api/games?category=crash`
List games (40 launch + 10 coming-soon).

### `GET /api/games/:id`
Game detail.

---

## Promotions

### `GET /api/promotions`
List active promotions (welcome bonus, daily promos, cashback, free bets,
deposit bonuses, tournaments, missions, rewards).

### `POST /api/promo-codes/redeem`
```json
{ "code": "TEMPWELCOME" }
```

### `GET /api/cashback` · `POST /api/cashback/claim`
Daily cashback status and claim.

### `GET /api/streak`
7-day streak status.

---

## Misc

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/leaderboard?period=weekly` | Weekly / monthly / all-time leaderboard |
| `GET` | `/api/notifications` | Notifications with unread count |
| `PATCH` | `/api/notifications/:id/read` | Mark one read |
| `POST` | `/api/support/tickets` | Open a support ticket |
| `GET` | `/api/support/tickets` | List my tickets |
| `GET` | `/api/users/me` | Profile |
| `PATCH` | `/api/users/me` | Update profile / preferences |

---

## Errors

Errors use a consistent envelope:

```json
{ "statusCode": 400, "message": "Insufficient balance", "error": "Bad Request" }
```

| Status | Meaning |
| --- | --- |
| 400 | Validation / business rule failure |
| 401 | Missing or invalid auth |
| 403 | Authenticated but not permitted (RBAC) |
| 404 | Not found |
| 429 | Rate limited (120 req/min default) |
| 500 | Unexpected server error |

---

## Idempotency

Financial endpoints (`POST /api/bets`, deposit approval, withdrawal release,
cashback claim) accept an `idempotencyKey`. Replaying the same key returns the
original result and never double-applies the ledger entry. This is enforced by
a unique constraint on `wallet_transactions.idempotency_key`.

---

## Admin API (RBAC)

Admin endpoints require a JWT with `role: admin` and are guarded by
`RolesGuard`. They cover users, wallet adjustments, deposit/withdrawal review,
agents, bets, sportsbook, games, promotions, cashback, streaks, leaderboard,
notifications, support, settings, and audit logs. Every privileged mutation
writes an `audit_logs` row.
