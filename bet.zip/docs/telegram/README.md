# TemP — Telegram Mini App Setup

TemP is **Telegram-first**. There is no email/password, no username/password,
and no password reset. A user's Telegram ID is their primary identity.

---

## 1. Create the bot

1. Open [@BotFather](https://t.me/BotFather) in Telegram.
2. `/newbot` → choose a name (e.g. `TemP`) and a username (e.g. `TemPAppBot`).
3. Copy the **bot token** — this is a secret. Store it only in the server
   environment (`TELEGRAM_BOT_TOKEN`). **Never** ship it to the browser.

## 2. Create the Mini App

1. In BotFather: `/newapp` → select your bot → set a title, description,
   photo, and the **Web App URL** (your deployed `apps/web` URL, HTTPS).
2. Optionally set a menu button: `/setmenubutton` → choose the bot → provide
   the URL and a label like “Open TemP”.

## 3. Configure the environment

```bash
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...      # server only
TELEGRAM_BOT_USERNAME=TemPAppBot
ENABLE_TELEGRAM_AUTH=true
VITE_API_URL=https://api.your-domain.com/api
```

## 4. How authentication works

When the Mini App opens, Telegram injects `window.Telegram.WebApp.initData` —
a URL-encoded query string containing the user, auth date, and a `hash`.

The client sends `initData` to `POST /api/auth/telegram`. The server:

1. Parses the query string and removes `hash`.
2. Builds `data_check_string` by sorting the remaining `key=value` pairs
   alphabetically and joining with `\n`.
3. Derives the secret key: `secret = HMAC_SHA256("WebAppData", botToken)`.
4. Computes `HMAC_SHA256(secret, data_check_string)` and compares it to `hash`
   in constant time.
5. Rejects if the signature is invalid or `auth_date` is older than the allowed
   window (default 24h).
6. Upserts the user by `telegram_id` and issues a JWT.

This is implemented in `apps/api/src/common/telegram-verify.ts` and covered by
`apps/api/test/telegram-verify.spec.ts`.

> **The client is never trusted.** The client cannot mint a session, cannot set
> its own balance, and cannot declare a bet result. Everything authoritative is
> computed server-side.

## 5. Development fallback

If `TELEGRAM_BOT_TOKEN` is unset (local dev), the API returns a deterministic
mock user (`telegram_id: 700000001`, “Abebe Kebede”) so you can exercise the
whole app in a normal browser. This fallback is **disabled** whenever a token is
present.

## 6. Telegram UX integration

`apps/web/src/lib/telegram.ts`:

- Calls `WebApp.ready()` and `WebApp.expand()` on mount.
- Reads `themeParams` and `colorScheme` to align the glass UI.
- Applies `safeAreaInset` / `contentSafeAreaInset` so the header and bottom nav
  never collide with Telegram chrome or device notches.
- Uses `WebApp.HapticFeedback` for tactile feedback on key actions.
- Uses `WebApp.BackButton` to mirror in-app navigation.
- Uses `WebApp.MainButton` where a primary action is expected.

## 7. Testing inside Telegram

1. Deploy `apps/web` to an HTTPS URL (see the root README deployment section).
2. Point the BotFather Web App URL at it.
3. Open the bot in Telegram and tap the menu button.
4. Confirm the header shows your real Telegram name and the balance loads.

## 8. Security checklist

- [ ] Bot token stored only in server env, never in client bundles.
- [ ] `initData` verified on every authenticated request (not just login).
- [ ] `auth_date` freshness window enforced.
- [ ] HTTPS everywhere; HSTS enabled at the edge.
- [ ] JWT signed with a strong `JWT_SECRET`, short expiry, refresh supported.
- [ ] Rate limiting enabled (Throttler).
- [ ] Audit logging on all privileged actions.
