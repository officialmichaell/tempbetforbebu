/**
 * Provider abstraction layer.
 *
 * The application NEVER hard-codes a single sportsbook/casino/payment provider.
 * All integrations go through these interfaces. In development, mock providers
 * are used. In production, licensed providers implement the same interfaces —
 * the frontend and business logic do not change.
 */

export interface ProviderEvent {
  id: string;
  sport: string;
  league: string;
  home: string;
  away: string;
  startTime: string;
  isLive: boolean;
  liveScore?: { home: number; away: number; minute?: number };
  markets: ProviderMarket[];
}

export interface ProviderMarket {
  id: string;
  name: string;
  selections: { id: string; name: string; odds: number; active: boolean }[];
}

export interface SportsbookProvider {
  readonly name: string;
  getSports(): Promise<{ id: string; name: string; icon: string }[]>;
  getEvents(filter?: { sport?: string; live?: boolean }): Promise<ProviderEvent[]>;
  getEvent(id: string): Promise<ProviderEvent | null>;
  placeBet(input: {
    userId: string;
    selections: { eventId: string; selectionId: string; odds: number }[];
    stake: number;
    type: 'single' | 'accumulator';
  }): Promise<{ providerBetId: string | null; accepted: boolean; totalOdds: number; potentialWin: number; reason?: string }>;
}

export interface CasinoProvider {
  readonly name: string;
  getGames(): Promise<{ id: string; title: string; category: string; provider: string }[]>;
  launchGame(input: { userId: string; gameId: string }): Promise<{ launchUrl: string; sessionId: string }>;
}

export interface PaymentProvider {
  readonly name: string;
  createDeposit(input: { userId: string; amount: number; method: string }): Promise<{
    reference: string;
    status: 'pending' | 'confirmed' | 'failed';
  }>;
  createWithdrawal(input: { userId: string; amount: number; method: string; account: string }): Promise<{
    reference: string;
    status: 'requested' | 'processing' | 'completed' | 'failed';
  }>;
  verifyWebhook(payload: unknown, signature: string): boolean;
}
