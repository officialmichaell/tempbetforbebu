import { Injectable } from '@nestjs/common';
import { CasinoProvider } from './interfaces';

@Injectable()
export class MockCasinoProvider implements CasinoProvider {
  readonly name = 'mock';

  async getGames() {
    return [
      { id: 'game_11', title: 'Roulette', category: 'Table Games', provider: 'TemP Originals' },
      { id: 'game_18', title: 'Crash', category: 'Crash', provider: 'TemP Originals' },
      { id: 'game_21', title: 'Golden Fortune', category: 'Slots', provider: 'TemP Slots' },
    ];
  }

  async launchGame(input: { userId: string; gameId: string }) {
    return {
      launchUrl: `https://mock-casino.local/launch?game=${input.gameId}&user=${input.userId}`,
      sessionId: `sess_${Date.now()}`,
    };
  }
}
