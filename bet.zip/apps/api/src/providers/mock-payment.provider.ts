import { Injectable } from '@nestjs/common';
import { PaymentProvider } from './interfaces';

@Injectable()
export class MockPaymentProvider implements PaymentProvider {
  readonly name = 'mock';

  async createDeposit(input: { userId: string; amount: number; method: string }) {
    return { reference: `MOCKDEP_${Date.now()}`, status: 'pending' as const };
  }

  async createWithdrawal(input: { userId: string; amount: number; method: string; account: string }) {
    return { reference: `MOCKWD_${Date.now()}`, status: 'requested' as const };
  }

  verifyWebhook(_payload: unknown, signature: string): boolean {
    // Mock: accept any non-empty signature. Real providers verify HMAC.
    return Boolean(signature);
  }
}
