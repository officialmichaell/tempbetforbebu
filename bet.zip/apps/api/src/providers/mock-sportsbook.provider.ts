import { Injectable } from '@nestjs/common';
import { SportsbookProvider, ProviderEvent } from './interfaces';
import { seededRandom } from '@temp/utils';

const SPORTS = [
  { id: 's1', name: 'Football', icon: '⚽' },
  { id: 's2', name: 'Basketball', icon: '🏀' },
  { id: 's3', name: 'Tennis', icon: '🎾' },
  { id: 's4', name: 'Volleyball', icon: '🏐' },
  { id: 's5', name: 'Esports', icon: '🎮' },
  { id: 's6', name: 'Horse Racing', icon: '🐎' },
];

const TEAMS: Record<string, string[]> = {
  s1: ['Manchester United', 'Arsenal', 'Chelsea', 'Liverpool', 'Real Madrid', 'Barcelona', 'Saint George SC', 'Fasil Kenema'],
  s2: ['Lakers', 'Celtics', 'Warriors', 'Bulls', 'Heat', 'Nuggets'],
  s3: ['Djokovic', 'Alcaraz', 'Sinner', 'Medvedev'],
  s4: ['Italy', 'Brazil', 'Poland', 'France'],
  s5: ['NAVI', 'FaZe', 'G2', 'Vitality'],
  s6: ['Thunder Bolt', 'Silver Arrow', 'Desert King', 'Night Fury'],
};

const LEAGUES: Record<string, string> = {
  s1: 'Premier League',
  s2: 'NBA',
  s3: 'ATP Masters',
  s4: 'Nations League',
  s5: 'CS2 Major',
  s6: 'Addis Derby',
};

@Injectable()
export class MockSportsbookProvider implements SportsbookProvider {
  readonly name = 'mock';
  private rng = seededRandom(20240907);

  async getSports() {
    return SPORTS;
  }

  async getEvents(filter?: { sport?: string; live?: boolean }): Promise<ProviderEvent[]> {
    const events: ProviderEvent[] = [];
    let idx = 0;
    for (const sport of SPORTS) {
      if (filter?.sport && filter.sport !== sport.id) continue;
      const teams = TEAMS[sport.id];
      for (let i = 0; i < 4; i++) {
        idx++;
        const isLive = i % 3 === 0;
        if (filter?.live !== undefined && filter.live !== isLive) continue;
        const home = teams[(i * 2) % teams.length];
        let away = teams[(i * 2 + 1) % teams.length];
        if (away === home) away = teams[(i * 2 + 2) % teams.length];
        const id = `evt_${idx}`;
        events.push({
          id,
          sport: sport.id,
          league: LEAGUES[sport.id],
          home,
          away,
          startTime: new Date(Date.now() + (isLive ? -1 : 1) * (i + 1) * 3600e3).toISOString(),
          isLive,
          liveScore: isLive ? { home: Math.floor(this.rng() * 4), away: Math.floor(this.rng() * 4), minute: 10 + Math.floor(this.rng() * 80) } : undefined,
          markets: [
            {
              id: `${id}_m1`,
              name: 'Match Result',
              selections: [
                { id: `${id}_s1`, name: 'Home', odds: this.odds(1.4, 4.0), active: true },
                { id: `${id}_s2`, name: 'Draw', odds: this.odds(2.8, 4.4), active: true },
                { id: `${id}_s3`, name: 'Away', odds: this.odds(1.6, 4.8), active: true },
              ],
            },
            {
              id: `${id}_m2`,
              name: 'Over / Under 2.5',
              selections: [
                { id: `${id}_s4`, name: 'Over 2.5', odds: this.odds(1.7, 2.7), active: true },
                { id: `${id}_s5`, name: 'Under 2.5', odds: this.odds(1.7, 2.7), active: true },
              ],
            },
          ],
        });
      }
    }
    return events;
  }

  async getEvent(id: string): Promise<ProviderEvent | null> {
    const all = await this.getEvents();
    return all.find((e) => e.id === id) ?? null;
  }

  async placeBet(input: {
    userId: string;
    selections: { eventId: string; selectionId: string; odds: number }[];
    stake: number;
    type: 'single' | 'accumulator';
  }) {
    if (!input.selections || input.selections.length === 0) {
      return { providerBetId: null, accepted: false, totalOdds: 0, potentialWin: 0, reason: 'No selections' };
    }
    if (input.stake <= 0) {
      return { providerBetId: null, accepted: false, totalOdds: 0, potentialWin: 0, reason: 'Invalid stake' };
    }
    const totalOdds =
      input.type === 'accumulator'
        ? input.selections.reduce((a, s) => a * s.odds, 1)
        : input.selections[0]?.odds ?? 0;
    const rounded = Math.round(totalOdds * 100) / 100;
    return {
      providerBetId: `mock_${Date.now()}`,
      accepted: true,
      totalOdds: rounded,
      potentialWin: Math.round(input.stake * rounded * 100) / 100,
    };
  }

  private odds(min: number, max: number) {
    return Math.round((min + this.rng() * (max - min)) * 100) / 100;
  }
}
