export interface AppConfig {
  nodeEnv: string;
  port: number;
  databaseUrl: string;
  redisUrl: string;
  telegram: {
    botToken: string;
    botUsername: string;
    authMaxAge: number;
  };
  jwt: {
    secret: string;
    expiresIn: string;
  };
  providers: {
    sportsbook: string;
    casino: string;
    payment: string;
  };
  urls: {
    app: string;
    api: string;
    admin: string;
  };
  flags: {
    ENABLE_TELEGRAM_AUTH: boolean;
    ENABLE_MOCK_BETTING: boolean;
    ENABLE_MOCK_WALLET: boolean;
    ENABLE_REAL_BETTING: boolean;
    ENABLE_REAL_PAYMENTS: boolean;
    ENABLE_WITHDRAWALS: boolean;
    ENABLE_CASINO: boolean;
    ENABLE_SPORTSBOOK: boolean;
    REAL_MONEY_ENABLED: boolean;
    PRODUCTION_BETTING_ENABLED: boolean;
    PAYMENTS_ENABLED: boolean;
  };
}

const bool = (v: string | undefined, def = false) =>
  v === undefined ? def : v.toLowerCase() === 'true';

export default (): AppConfig => ({
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: Number(process.env.PORT ?? 3000),
  databaseUrl: process.env.DATABASE_URL ?? '',
  redisUrl: process.env.REDIS_URL ?? '',
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN ?? '',
    botUsername: process.env.TELEGRAM_BOT_USERNAME ?? 'TemP_bot',
    authMaxAge: Number(process.env.TELEGRAM_AUTH_MAX_AGE ?? 86400),
  },
  jwt: {
    secret: process.env.JWT_SECRET ?? 'dev-only-secret-change-me',
    expiresIn: process.env.JWT_EXPIRES_IN ?? '7d',
  },
  providers: {
    sportsbook: process.env.SPORTSBOOK_PROVIDER ?? 'mock',
    casino: process.env.CASINO_PROVIDER ?? 'mock',
    payment: process.env.PAYMENT_PROVIDER ?? 'mock',
  },
  urls: {
    app: process.env.APP_URL ?? 'http://localhost:5173',
    api: process.env.API_URL ?? 'http://localhost:3000',
    admin: process.env.ADMIN_URL ?? 'http://localhost:5174',
  },
  flags: {
    ENABLE_TELEGRAM_AUTH: bool(process.env.ENABLE_TELEGRAM_AUTH, true),
    ENABLE_MOCK_BETTING: bool(process.env.ENABLE_MOCK_BETTING, true),
    ENABLE_MOCK_WALLET: bool(process.env.ENABLE_MOCK_WALLET, true),
    ENABLE_REAL_BETTING: bool(process.env.ENABLE_REAL_BETTING, false),
    ENABLE_REAL_PAYMENTS: bool(process.env.ENABLE_REAL_PAYMENTS, false),
    ENABLE_WITHDRAWALS: bool(process.env.ENABLE_WITHDRAWALS, true),
    ENABLE_CASINO: bool(process.env.ENABLE_CASINO, true),
    ENABLE_SPORTSBOOK: bool(process.env.ENABLE_SPORTSBOOK, true),
    REAL_MONEY_ENABLED: bool(process.env.REAL_MONEY_ENABLED, false),
    PRODUCTION_BETTING_ENABLED: bool(process.env.PRODUCTION_BETTING_ENABLED, false),
    PAYMENTS_ENABLED: bool(process.env.PAYMENTS_ENABLED, false),
  },
});
