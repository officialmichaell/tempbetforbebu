import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, Wallet } from '../../entities';
import { verifyTelegramInitData, mockTelegramUser } from '../../common/telegram-verify';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @InjectRepository(User) private users: Repository<User>,
    @InjectRepository(Wallet) private wallets: Repository<Wallet>,
    private jwt: JwtService,
    private config: ConfigService,
  ) {}

  /**
   * Authenticate via Telegram initData. Verifies the HMAC signature server-side,
   * then finds or creates the user. Telegram ID is the primary external identity.
   */
  async authenticate(initData: string) {
    const botToken = this.config.get<string>('telegram.botToken') ?? '';
    const maxAge = this.config.get<number>('telegram.authMaxAge') ?? 86400;
    const nodeEnv = this.config.get<string>('nodeEnv');

    let verified;
    try {
      if (botToken) {
        verified = verifyTelegramInitData(initData, botToken, maxAge);
      } else if (nodeEnv !== 'production') {
        // Dev fallback so the prototype is testable without a bot token.
        this.logger.warn('No TELEGRAM_BOT_TOKEN set — using mock Telegram user (dev only)');
        verified = mockTelegramUser();
      } else {
        throw new Error('Telegram bot token not configured');
      }
    } catch (e) {
      throw new UnauthorizedException(e instanceof Error ? e.message : 'Telegram auth failed');
    }

    const tg = verified.user;
    const telegramId = String(tg.id);

    let user = await this.users.findOne({ where: { telegram_id: telegramId } });
    if (!user) {
      user = this.users.create({
        telegram_id: telegramId,
        telegram_username: tg.username ?? null,
        first_name: tg.first_name,
        last_name: tg.last_name ?? null,
        avatar_url: tg.photo_url ?? null,
        status: 'active',
        language: tg.language_code ?? 'en',
      });
      user = await this.users.save(user);
      // Create wallet with zero balance (ledger-derived)
      await this.wallets.save(
        this.wallets.create({ user_id: user.id, balance: '0', bonus_balance: '0', pending_balance: '0', currency: 'ETB' }),
      );
      this.logger.log(`Created new user ${user.id} (tg ${telegramId})`);
    } else {
      // Refresh profile fields
      user.telegram_username = tg.username ?? user.telegram_username;
      user.first_name = tg.first_name ?? user.first_name;
      user.last_name = tg.last_name ?? user.last_name;
      user.avatar_url = tg.photo_url ?? user.avatar_url;
      await this.users.save(user);
    }

    const token = await this.jwt.signAsync({ sub: user.id, telegram_id: telegramId, role: 'user' });
    return { user, token };
  }

  async me(userId: string) {
    const user = await this.users.findOne({ where: { id: userId } });
    if (!user) throw new UnauthorizedException('User not found');
    return user;
  }
}
