import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Withdrawal } from '../../entities';
import { WalletService } from '../wallet/wallet.service';
import { MockPaymentProvider } from '../../providers/mock-payment.provider';

@Injectable()
export class WithdrawalsService {
  constructor(
    @InjectRepository(Withdrawal) private withdrawals: Repository<Withdrawal>,
    private wallet: WalletService,
    private payment: MockPaymentProvider,
  ) {}

  async create(userId: string, amount: number, method: string, account: string) {
    if (amount <= 0) throw new BadRequestException('Amount must be positive');
    const w = await this.wallet.getWallet(userId);
    if (amount > Number(w.balance)) throw new BadRequestException('Insufficient balance');

    const ref = await this.payment.createWithdrawal({ userId, amount, method, account });
    const withdrawal = await this.withdrawals.save(
      this.withdrawals.create({
        user_id: userId,
        amount: amount.toFixed(2),
        method,
        account,
        state: 'REQUESTED',
        note: ref.reference,
      }),
    );
    // Debit immediately (hold) — idempotent
    await this.wallet.applyTransaction({
      userId,
      type: 'withdrawal',
      amount: -amount,
      description: `Withdrawal to ${method}`,
      idempotencyKey: `withdrawal_${withdrawal.id}`,
      reference: ref.reference,
    });
    return withdrawal;
  }

  async list(userId: string) {
    return this.withdrawals.find({ where: { user_id: userId }, order: { created_at: 'DESC' } });
  }

  async get(userId: string, id: string) {
    return this.withdrawals.findOne({ where: { id, user_id: userId } });
  }

  async transition(id: string, state: string) {
    const w = await this.withdrawals.findOne({ where: { id } });
    if (!w) throw new BadRequestException('Withdrawal not found');
    w.state = state;
    await this.withdrawals.save(w);
    // On REJECTED, refund the held amount idempotently
    if (state === 'REJECTED') {
      await this.wallet.applyTransaction({
        userId: w.user_id,
        type: 'bet_refund',
        amount: Number(w.amount),
        description: 'Withdrawal rejected — refund',
        idempotencyKey: `withdrawal_refund_${w.id}`,
      });
    }
    return w;
  }
}
