import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { IsNumber, IsString, Min } from 'class-validator';
import { ApiTags } from '@nestjs/swagger';
import { WithdrawalsService } from './withdrawals.service';
import { JwtAuthGuard } from '../../common/guards';

class CreateWithdrawalDto {
  @IsNumber() @Min(1) amount: number;
  @IsString() method: string;
  @IsString() account: string;
}

@ApiTags('withdrawals')
@UseGuards(JwtAuthGuard)
@Controller('withdrawals')
export class WithdrawalsController {
  constructor(private withdrawals: WithdrawalsService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateWithdrawalDto) {
    return this.withdrawals.create(req.user.sub, dto.amount, dto.method, dto.account);
  }

  @Get()
  list(@Req() req: any) {
    return this.withdrawals.list(req.user.sub);
  }

  @Get(':id')
  get(@Req() req: any, @Param('id') id: string) {
    return this.withdrawals.get(req.user.sub, id);
  }
}
