import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { SportsbookService } from './sportsbook.service';
import { JwtAuthGuard } from '../../common/guards';

@ApiTags('sports')
@UseGuards(JwtAuthGuard)
@Controller()
export class SportsbookController {
  constructor(private sportsbook: SportsbookService) {}

  @Get('sports')
  sports() {
    return this.sportsbook.getSports();
  }

  @Get('events')
  events(@Query('sport') sport?: string, @Query('live') live?: string) {
    return this.sportsbook.getEvents({
      sport,
      live: live === undefined ? undefined : live === 'true',
    });
  }

  @Get('events/:id')
  event(@Param('id') id: string) {
    return this.sportsbook.getEvent(id);
  }
}
