import { Injectable } from '@nestjs/common';
import { MockSportsbookProvider } from '../../providers/mock-sportsbook.provider';

@Injectable()
export class SportsbookService {
  constructor(private provider: MockSportsbookProvider) {}

  getSports() {
    return this.provider.getSports();
  }

  getEvents(filter?: { sport?: string; live?: boolean }) {
    return this.provider.getEvents(filter);
  }

  getEvent(id: string) {
    return this.provider.getEvent(id);
  }
}
