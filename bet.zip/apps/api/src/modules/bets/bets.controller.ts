import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { IsArray, IsIn, IsNumber, IsString, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiTags } from '@nestjs/swagger';
import { BetsService } from './bets.service';
import { JwtAuthGuard } from '../../common/guards';

class SelectionDto {
  @IsString() event_id: string;
  @IsString() event_label: string;
  @IsString() market_name: string;
  @IsString() selection_name: string;
  @IsNumber() odds: number;
}

class PlaceBetDto {
  @IsArray() @ValidateNested({ each: true }) @Type(() => SelectionDto) selections: SelectionDto[];
  @IsNumber() @Min(1) stake: number;
  @IsIn(['single', 'accumulator']) type: 'single' | 'accumulator';
}

@ApiTags('bets')
@UseGuards(JwtAuthGuard)
@Controller('bets')
export class BetsController {
  constructor(private bets: BetsService) {}

  @Post()
  place(@Req() req: any, @Body() dto: PlaceBetDto) {
    return this.bets.place(req.user.sub, dto);
  }

  @Get()
  list(@Req() req: any) {
    return this.bets.list(req.user.sub);
  }

  @Get(':id')
  get(@Req() req: any, @Param('id') id: string) {
    return this.bets.get(req.user.sub, id);
  }
}
