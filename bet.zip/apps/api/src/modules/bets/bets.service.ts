import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Bet, BetSelection } from '../../entities';
import { WalletService } from '../wallet/wallet.service';
import { MockSportsbookProvider } from '../../providers/mock-sportsbook.provider';

export interface PlaceBetInput {
  selections: {
    event_id: string;
    event_label: string;
    market_name: string;
    selection_name: string;
    odds: number;
  }[];
  stake: number;
  type: 'single' | 'accumulator';
}

@Injectable()
export class BetsService {
  constructor(
    @InjectRepository(Bet) private bets: Repository<Bet>,
    @InjectRepository(BetSelection) private selections: Repository<BetSelection>,
    private wallet: WalletService,
    private sportsbook: MockSportsbookProvider,
  ) {}

  async place(userId: string, input: PlaceBetInput) {
    if (input.stake <= 0) throw new BadRequestException('Stake must be positive');
    if (!input.selections?.length) throw new BadRequestException('No selections');

    // Server-side odds validation via provider (never trust client odds)
    const providerResult = await this.sportsbook.placeBet({
      userId,
      selections: input.selections.map((s) => ({ eventId: s.event_id, selectionId: '', odds: s.odds })),
      stake: input.stake,
      type: input.type,
    });
    if (!providerResult.accepted) throw new BadRequestException('Bet rejected by provider');

    // Debit stake atomically (idempotency key generated per bet)
    const bet = await this.bets.save(
      this.bets.create({
        user_id: userId,
        type: input.type,
        stake: input.stake.toFixed(2),
        total_odds: providerResult.totalOdds.toFixed(2),
        potential_win: providerResult.potentialWin.toFixed(2),
        state: 'pending',
      }),
    );

    for (const s of input.selections) {
      await this.selections.save(
        this.selections.create({
          bet_id: bet.id,
          event_id: s.event_id,
          event_label: s.event_label,
          market_name: s.market_name,
          selection_name: s.selection_name,
          odds: s.odds.toFixed(2),
        }),
      );
    }

    await this.wallet.applyTransaction({
      userId,
      type: 'bet_stake',
      amount: -input.stake,
      description: `Bet ${bet.id}`,
      idempotencyKey: `bet_${bet.id}`,
    });

    return { ...bet, selections: input.selections };
  }

  async list(userId: string) {
    const bets = await this.bets.find({ where: { user_id: userId }, order: { created_at: 'DESC' } });
    const result: Array<Bet & { selections: BetSelection[] }> = [];
    for (const b of bets) {
      const sels = await this.selections.find({ where: { bet_id: b.id } });
      result.push({ ...b, selections: sels });
    }
    return result;
  }

  async get(userId: string, id: string) {
    const bet = await this.bets.findOne({ where: { id, user_id: userId } });
    if (!bet) return null;
    const sels = await this.selections.find({ where: { bet_id: bet.id } });
    return { ...bet, selections: sels };
  }
}
