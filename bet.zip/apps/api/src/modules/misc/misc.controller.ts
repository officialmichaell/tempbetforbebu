import { Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { IsString } from 'class-validator';
import { ApiTags } from '@nestjs/swagger';
import { Leaderboard, Notification, SupportTicket, User } from '../../entities';
import { JwtAuthGuard } from '../../common/guards';

class TicketDto {
  @IsString() subject: string;
  @IsString() category: string;
  @IsString() message: string;
}

@ApiTags('misc')
@UseGuards(JwtAuthGuard)
@Controller()
export class MiscController {
  constructor(
    @InjectRepository(Leaderboard) private leaderboard: Repository<Leaderboard>,
    @InjectRepository(Notification) private notifications: Repository<Notification>,
    @InjectRepository(SupportTicket) private tickets: Repository<SupportTicket>,
    @InjectRepository(User) private users: Repository<User>,
  ) {}

  @Get('leaderboard')
  async lb(@Query('period') period = 'weekly') {
    const rows = await this.leaderboard.find({ where: { period }, order: { points: 'DESC' }, take: 50 });
    return rows.map((r, i) => ({ rank: i + 1, ...r }));
  }

  @Get('notifications')
  notifs(@Req() req: any) {
    return this.notifications.find({ where: { user_id: req.user.sub }, order: { created_at: 'DESC' } });
  }

  @Patch('notifications/:id/read')
  async read(@Req() req: any, @Param('id') id: string) {
    await this.notifications.update({ id, user_id: req.user.sub }, { read: true });
    return { ok: true };
  }

  @Post('support/tickets')
  createTicket(@Req() req: any, @Body() dto: TicketDto) {
    return this.tickets.save(
      this.tickets.create({ user_id: req.user.sub, subject: dto.subject, category: dto.category, message: dto.message, state: 'open' }),
    );
  }

  @Get('support/tickets')
  listTickets(@Req() req: any) {
    return this.tickets.find({ where: { user_id: req.user.sub }, order: { created_at: 'DESC' } });
  }

  @Get('users/me')
  me(@Req() req: any) {
    return this.users.findOne({ where: { id: req.user.sub } });
  }

  @Patch('users/me')
  async updateMe(@Req() req: any, @Body() body: Partial<User>) {
    await this.users.update({ id: req.user.sub }, body);
    return this.users.findOne({ where: { id: req.user.sub } });
  }
}
