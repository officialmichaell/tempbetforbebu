import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { Wallet, WalletTransaction } from '../../entities';

/**
 * Wallet service built around an immutable transaction ledger.
 *
 * Financial operations are:
 *  - atomic (wrapped in a DB transaction)
 *  - idempotent (idempotency_key unique constraint)
 *  - auditable (every change is a ledger row)
 *  - server-side (never trust client balance)
 */
@Injectable()
export class WalletService {
  constructor(
    @InjectRepository(Wallet) private wallets: Repository<Wallet>,
    @InjectRepository(WalletTransaction) private txs: Repository<WalletTransaction>,
    private dataSource: DataSource,
  ) {}

  async getWallet(userId: string) {
    let wallet = await this.wallets.findOne({ where: { user_id: userId } });
    if (!wallet) {
      wallet = await this.wallets.save(
        this.wallets.create({ user_id: userId, balance: '0', bonus_balance: '0', pending_balance: '0', currency: 'ETB' }),
      );
    }
    return wallet;
  }

  async getTransactions(userId: string) {
    return this.txs.find({ where: { user_id: userId }, order: { created_at: 'DESC' } });
  }

  /**
   * Apply a ledger entry atomically and idempotently.
   * Returns the existing transaction if the idempotency key was already used.
   */
  async applyTransaction(input: {
    userId: string;
    type: string;
    amount: number;
    description?: string;
    idempotencyKey?: string;
    reference?: string;
  }): Promise<WalletTransaction> {
    if (input.idempotencyKey) {
      const existing = await this.txs.findOne({ where: { idempotency_key: input.idempotencyKey } });
      if (existing) return existing;
    }

    return this.dataSource.transaction(async (manager) => {
      const wallet = await manager.findOne(Wallet, { where: { user_id: input.userId }, lock: { mode: 'pessimistic_write' } });
      if (!wallet) throw new NotFoundException('Wallet not found');

      const current = Number(wallet.balance);
      const next = Math.round((current + input.amount) * 100) / 100;
      if (next < 0) throw new BadRequestException('Insufficient balance');

      wallet.balance = next.toFixed(2);
      await manager.save(wallet);

      const tx = manager.create(WalletTransaction, {
        wallet_id: wallet.id,
        user_id: input.userId,
        type: input.type,
        amount: input.amount.toFixed(2),
        balance_after: next.toFixed(2),
        description: input.description ?? null,
        idempotency_key: input.idempotencyKey ?? null,
        reference: input.reference ?? null,
      });
      return manager.save(tx);
    });
  }
}
