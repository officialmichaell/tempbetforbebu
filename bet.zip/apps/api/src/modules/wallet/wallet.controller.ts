import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { WalletService } from './wallet.service';
import { JwtAuthGuard } from '../../common/guards';

@ApiTags('wallet')
@UseGuards(JwtAuthGuard)
@Controller('wallet')
export class WalletController {
  constructor(private wallet: WalletService) {}

  @Get()
  get(@Req() req: any) {
    return this.wallet.getWallet(req.user.sub);
  }

  @Get('transactions')
  transactions(@Req() req: any) {
    return this.wallet.getTransactions(req.user.sub);
  }
}
