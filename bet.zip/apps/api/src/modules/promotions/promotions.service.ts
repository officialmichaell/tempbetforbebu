import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Promotion, PromoCode, Cashback, Streak } from '../../entities';
import { WalletService } from '../wallet/wallet.service';

@Injectable()
export class PromotionsService {
  constructor(
    @InjectRepository(Promotion) private promos: Repository<Promotion>,
    @InjectRepository(PromoCode) private codes: Repository<PromoCode>,
    @InjectRepository(Cashback) private cashback: Repository<Cashback>,
    @InjectRepository(Streak) private streaks: Repository<Streak>,
    private wallet: WalletService,
  ) {}

  list() {
    return this.promos.find({ where: { active: true } });
  }

  async redeem(userId: string, code: string) {
    const key = code.trim().toUpperCase();
    const promo = await this.codes.findOne({ where: { code: key } });
    if (!promo || !promo.active) return { state: 'invalid', reward: 0, message: 'Invalid promo code.' };
    if (promo.expires_at && new Date(promo.expires_at) < new Date()) {
      return { state: 'expired', reward: 0, message: 'This promo code has expired.' };
    }
    const reward = Number(promo.reward);
    // Idempotent credit per user+code
    await this.wallet.applyTransaction({
      userId,
      type: 'promo_credit',
      amount: reward,
      description: `Promo code ${key}`,
      idempotencyKey: `promo_${userId}_${key}`,
    });
    return { state: 'success', reward, message: `Success! ${reward} ETB credited.` };
  }

  async getCashback(userId: string) {
    let cb = await this.cashback.findOne({ where: { user_id: userId } });
    if (!cb) {
      cb = await this.cashback.save(this.cashback.create({ user_id: userId, percentage: '5', accumulated: '0' }));
    }
    return cb;
  }

  async claimCashback(userId: string) {
    const cb = await this.getCashback(userId);
    const amount = Number(cb.accumulated);
    if (amount <= 0) throw new BadRequestException('No cashback available');
    await this.wallet.applyTransaction({
      userId,
      type: 'cashback',
      amount,
      description: 'Daily cashback claim',
      idempotencyKey: `cashback_${userId}_${new Date().toISOString().slice(0, 10)}`,
    });
    cb.accumulated = '0';
    cb.last_claimed_at = new Date();
    await this.cashback.save(cb);
    return { amount };
  }

  async getStreak(userId: string) {
    let s = await this.streaks.findOne({ where: { user_id: userId } });
    if (!s) s = await this.streaks.save(this.streaks.create({ user_id: userId, current: 0, best: 0 }));
    return s;
  }
}
