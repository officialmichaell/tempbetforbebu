import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { IsString } from 'class-validator';
import { ApiTags } from '@nestjs/swagger';
import { PromotionsService } from './promotions.service';
import { JwtAuthGuard } from '../../common/guards';

class RedeemDto {
  @IsString() code: string;
}

@ApiTags('promotions')
@UseGuards(JwtAuthGuard)
@Controller()
export class PromotionsController {
  constructor(private promos: PromotionsService) {}

  @Get('promotions')
  list() {
    return this.promos.list();
  }

  @Post('promo-codes/redeem')
  redeem(@Req() req: any, @Body() dto: RedeemDto) {
    return this.promos.redeem(req.user.sub, dto.code);
  }

  @Get('cashback')
  cashback(@Req() req: any) {
    return this.promos.getCashback(req.user.sub);
  }

  @Post('cashback/claim')
  claim(@Req() req: any) {
    return this.promos.claimCashback(req.user.sub);
  }

  @Get('streak')
  streak(@Req() req: any) {
    return this.promos.getStreak(req.user.sub);
  }
}
