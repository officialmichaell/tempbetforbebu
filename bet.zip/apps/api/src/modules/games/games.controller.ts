import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ApiTags } from '@nestjs/swagger';
import { Game } from '../../entities';
import { JwtAuthGuard } from '../../common/guards';

@ApiTags('games')
@UseGuards(JwtAuthGuard)
@Controller('games')
export class GamesController {
  constructor(@InjectRepository(Game) private games: Repository<Game>) {}

  @Get()
  list() {
    return this.games.find({ order: { title: 'ASC' } });
  }

  @Get(':id')
  get(@Param('id') id: string) {
    return this.games.findOne({ where: { id } });
  }
}
