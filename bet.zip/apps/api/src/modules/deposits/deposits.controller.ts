import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { IsNumber, IsString, Min } from 'class-validator';
import { ApiTags } from '@nestjs/swagger';
import { DepositsService } from './deposits.service';
import { JwtAuthGuard } from '../../common/guards';

class CreateDepositDto {
  @IsNumber() @Min(1) amount: number;
  @IsString() method: string;
}

@ApiTags('deposits')
@UseGuards(JwtAuthGuard)
@Controller('deposits')
export class DepositsController {
  constructor(private deposits: DepositsService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateDepositDto) {
    return this.deposits.create(req.user.sub, dto.amount, dto.method);
  }

  @Get()
  list(@Req() req: any) {
    return this.deposits.list(req.user.sub);
  }

  @Get(':id')
  get(@Req() req: any, @Param('id') id: string) {
    return this.deposits.get(req.user.sub, id);
  }
}
