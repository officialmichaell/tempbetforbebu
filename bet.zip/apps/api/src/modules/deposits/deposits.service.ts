import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Deposit, Agent } from '../../entities';
import { WalletService } from '../wallet/wallet.service';
import { MockPaymentProvider } from '../../providers/mock-payment.provider';

@Injectable()
export class DepositsService {
  constructor(
    @InjectRepository(Deposit) private deposits: Repository<Deposit>,
    @InjectRepository(Agent) private agents: Repository<Agent>,
    private wallet: WalletService,
    private payment: MockPaymentProvider,
  ) {}

  async create(userId: string, amount: number, method: string) {
    if (amount <= 0) throw new BadRequestException('Amount must be positive');
    const agent = await this.agents.findOne({ where: { status: 'active' } });
    const ref = await this.payment.createDeposit({ userId, amount, method });
    const deposit = await this.deposits.save(
      this.deposits.create({
        user_id: userId,
        agent_id: agent?.id ?? null,
        amount: amount.toFixed(2),
        method,
        state: 'PENDING',
        reference: ref.reference,
      }),
    );
    return deposit;
  }

  async list(userId: string) {
    return this.deposits.find({ where: { user_id: userId }, order: { created_at: 'DESC' } });
  }

  async get(userId: string, id: string) {
    return this.deposits.findOne({ where: { id, user_id: userId } });
  }

  /** Admin/agent transition. On APPROVED, credit the wallet ledger idempotently. */
  async transition(id: string, state: string) {
    const deposit = await this.deposits.findOne({ where: { id } });
    if (!deposit) throw new BadRequestException('Deposit not found');
    deposit.state = state;
    await this.deposits.save(deposit);

    if (state === 'APPROVED') {
      await this.wallet.applyTransaction({
        userId: deposit.user_id,
        type: 'deposit',
        amount: Number(deposit.amount),
        description: `Deposit via ${deposit.method}`,
        idempotencyKey: `deposit_${deposit.id}`,
        reference: deposit.reference ?? undefined,
      });
    }
    return deposit;
  }
}
