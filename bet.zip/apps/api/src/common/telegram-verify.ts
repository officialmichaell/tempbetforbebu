import { createHmac } from 'crypto';

export interface TelegramInitUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
}

export interface VerifiedTelegramData {
  user: TelegramInitUser;
  authDate: number;
  queryId?: string;
}

/**
 * Verify Telegram WebApp initData using the bot token.
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 *
 * SECURITY: This is the ONLY trusted source of Telegram identity.
 * Never trust user data supplied directly by the frontend.
 */
export function verifyTelegramInitData(
  initData: string,
  botToken: string,
  maxAgeSeconds = 86400,
): VerifiedTelegramData {
  if (!initData) throw new Error('Missing initData');
  if (!botToken) throw new Error('Server bot token not configured');

  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash) throw new Error('Missing hash');

  params.delete('hash');
  const dataCheckString = [...params.entries()]
    .map(([k, v]) => `${k}=${v}`)
    .sort()
    .join('\n');

  const secretKey = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const computed = createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

  if (computed !== hash) throw new Error('Invalid Telegram signature');

  const authDate = Number(params.get('auth_date') ?? 0);
  const now = Math.floor(Date.now() / 1000);
  if (maxAgeSeconds > 0 && now - authDate > maxAgeSeconds) {
    throw new Error('Telegram auth data expired');
  }

  const userJson = params.get('user');
  if (!userJson) throw new Error('Missing user in initData');
  const user = JSON.parse(userJson) as TelegramInitUser;

  return { user, authDate, queryId: params.get('query_id') ?? undefined };
}

/**
 * Development-only fallback: when no bot token is configured, accept a
 * mock user so the prototype is testable. NEVER enable in production.
 */
export function mockTelegramUser(): VerifiedTelegramData {
  return {
    user: {
      id: 700000001,
      first_name: 'Abebe',
      last_name: 'Kebede',
      username: 'abebe_demo',
      language_code: 'en',
    },
    authDate: Math.floor(Date.now() / 1000),
  };
}
