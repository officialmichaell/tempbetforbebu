import {
  Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn,
  OneToMany, ManyToOne, JoinColumn, Index, Unique,
} from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column({ type: 'bigint' }) telegram_id: string;
  @Column({ nullable: true }) telegram_username: string | null;
  @Column() first_name: string;
  @Column({ nullable: true }) last_name: string | null;
  @Column({ nullable: true }) phone: string | null;
  @Column({ nullable: true }) avatar_url: string | null;
  @Column({ default: 'active' }) status: string;
  @Column({ default: 'en' }) language: string;
  @CreateDateColumn() created_at: Date;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('wallets')
export class Wallet {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column() user_id: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) balance: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) bonus_balance: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) pending_balance: string;
  @Column({ default: 'ETB' }) currency: string;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('wallet_transactions')
@Unique(['idempotency_key'])
export class WalletTransaction {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() wallet_id: string;
  @Index() @Column() user_id: string;
  @Column() type: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) balance_after: string;
  @Column({ nullable: true }) reference: string | null;
  @Column({ nullable: true }) idempotency_key: string | null;
  @Column({ nullable: true }) description: string | null;
  @CreateDateColumn() created_at: Date;
}

@Entity('deposits')
export class Deposit {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column({ nullable: true }) agent_id: string | null;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;
  @Column() method: string;
  @Column({ default: 'PENDING' }) state: string;
  @Column({ nullable: true }) reference: string | null;
  @Column({ nullable: true }) note: string | null;
  @CreateDateColumn() created_at: Date;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('withdrawals')
export class Withdrawal {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;
  @Column() method: string;
  @Column() account: string;
  @Column({ default: 'REQUESTED' }) state: string;
  @Column({ nullable: true }) note: string | null;
  @CreateDateColumn() created_at: Date;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('agents')
export class Agent {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() name: string;
  @Column({ nullable: true }) telegram_username: string | null;
  @Column({ nullable: true }) phone: string | null;
  @Column({ default: 'active' }) status: string;
  @CreateDateColumn() created_at: Date;
}

@Entity('agent_transactions')
export class AgentTransaction {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() agent_id: string;
  @Column({ nullable: true }) deposit_id: string | null;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;
  @Column() type: string;
  @CreateDateColumn() created_at: Date;
}

@Entity('sports')
export class Sport {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ unique: true }) key: string;
  @Column() name: string;
  @Column() icon: string;
}

@Entity('leagues')
export class League {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() sport_id: string;
  @Column() name: string;
  @Column({ nullable: true }) country: string | null;
}

@Entity('events')
export class Event {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() sport_id: string;
  @Column() league_id: string;
  @Column() home: string;
  @Column() away: string;
  @Column({ type: 'timestamptz' }) start_time: Date;
  @Column({ default: false }) is_live: boolean;
}

@Entity('markets')
export class Market {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() event_id: string;
  @Column() name: string;
}

@Entity('odds')
export class Odd {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() market_id: string;
  @Column() name: string;
  @Column({ type: 'numeric', precision: 8, scale: 2 }) odds: string;
  @Column({ default: true }) active: boolean;
}

@Entity('bets')
export class Bet {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column() type: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) stake: string;
  @Column({ type: 'numeric', precision: 10, scale: 2 }) total_odds: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) potential_win: string;
  @Column({ default: 'pending' }) state: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, nullable: true }) payout: string | null;
  @CreateDateColumn() created_at: Date;
}

@Entity('bet_selections')
export class BetSelection {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() bet_id: string;
  @Column() event_id: string;
  @Column() event_label: string;
  @Column() market_name: string;
  @Column() selection_name: string;
  @Column({ type: 'numeric', precision: 8, scale: 2 }) odds: string;
}

@Entity('bet_results')
export class BetResult {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() bet_id: string;
  @Column() outcome: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) payout: string;
  @CreateDateColumn() created_at: Date;
}

@Entity('games')
export class Game {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ unique: true }) slug: string;
  @Column() title: string;
  @Column() category: string;
  @Column() provider: string;
  @Column({ nullable: true }) badge: string | null;
  @Column({ default: false }) coming_soon: boolean;
  @Column({ default: true }) active: boolean;
}

@Entity('game_sessions')
export class GameSession {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Index() @Column() game_id: string;
  @CreateDateColumn() started_at: Date;
  @Column({ type: 'timestamptz', nullable: true }) ended_at: Date | null;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) bet_total: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) win_total: string;
}

@Entity('promotions')
export class Promotion {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() title: string;
  @Column() description: string;
  @Column() category: string;
  @Column({ nullable: true }) badge: string | null;
  @Column({ nullable: true }) cta: string | null;
  @Column({ default: true }) active: boolean;
}

@Entity('promo_codes')
export class PromoCode {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ unique: true }) code: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) reward: string;
  @Column({ nullable: true }) expires_at: Date | null;
  @Column({ default: true }) active: boolean;
}

@Entity('bonuses')
export class Bonus {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column() type: string;
  @Column({ type: 'numeric', precision: 14, scale: 2 }) amount: string;
  @Column({ default: 'active' }) state: string;
  @CreateDateColumn() created_at: Date;
}

@Entity('cashback')
export class Cashback {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column({ type: 'numeric', precision: 5, scale: 2, default: 5 }) percentage: string;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) accumulated: string;
  @Column({ type: 'timestamptz', nullable: true }) last_claimed_at: Date | null;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('streaks')
export class Streak {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column() user_id: string;
  @Column({ default: 0 }) current: number;
  @Column({ default: 0 }) best: number;
  @Column({ type: 'date', nullable: true }) last_claim_date: string | null;
}

@Entity('leaderboards')
export class Leaderboard {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column() period: string;
  @Column({ default: 0 }) points: number;
  @Column({ type: 'numeric', precision: 14, scale: 2, default: 0 }) winnings: string;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('notifications')
export class Notification {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column() type: string;
  @Column() title: string;
  @Column() body: string;
  @Column({ default: false }) read: boolean;
  @CreateDateColumn() created_at: Date;
}

@Entity('support_tickets')
export class SupportTicket {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column() user_id: string;
  @Column() subject: string;
  @Column() category: string;
  @Column({ type: 'text' }) message: string;
  @Column({ default: 'open' }) state: string;
  @CreateDateColumn() created_at: Date;
  @UpdateDateColumn() updated_at: Date;
}

@Entity('admin_users')
export class AdminUser {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ unique: true }) email: string;
  @Column() name: string;
  @Column() password_hash: string;
  @Column({ default: 'admin' }) role: string;
  @Column({ default: false }) two_factor_enabled: boolean;
  @CreateDateColumn() created_at: Date;
}

@Entity('audit_logs')
export class AuditLog {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() actor: string;
  @Column() action: string;
  @Column() entity: string;
  @Column() entity_id: string;
  @Column({ type: 'jsonb', nullable: true }) meta: Record<string, unknown> | null;
  @CreateDateColumn() created_at: Date;
}
