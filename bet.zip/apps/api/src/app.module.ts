import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';

import configuration from './config/configuration';

// Entities
import {
  User, Wallet, WalletTransaction, Deposit, Withdrawal, Agent, AgentTransaction,
  Sport, League, Event, Market, Odd, Bet, BetSelection, BetResult, Game, GameSession,
  Promotion, PromoCode, Bonus, Cashback, Streak, Leaderboard, Notification,
  SupportTicket, AdminUser, AuditLog,
} from './entities';

// Providers (mock implementations behind interfaces)
import { MockSportsbookProvider } from './providers/mock-sportsbook.provider';
import { MockCasinoProvider } from './providers/mock-casino.provider';
import { MockPaymentProvider } from './providers/mock-payment.provider';

// Feature modules (controllers + services)
import { AuthController } from './modules/auth/auth.controller';
import { AuthService } from './modules/auth/auth.service';
import { WalletController } from './modules/wallet/wallet.controller';
import { WalletService } from './modules/wallet/wallet.service';
import { DepositsController } from './modules/deposits/deposits.controller';
import { DepositsService } from './modules/deposits/deposits.service';
import { WithdrawalsController } from './modules/withdrawals/withdrawals.controller';
import { WithdrawalsService } from './modules/withdrawals/withdrawals.service';
import { SportsbookController } from './modules/sportsbook/sportsbook.controller';
import { SportsbookService } from './modules/sportsbook/sportsbook.service';
import { BetsController } from './modules/bets/bets.controller';
import { BetsService } from './modules/bets/bets.service';
import { GamesController } from './modules/games/games.controller';
import { PromotionsController } from './modules/promotions/promotions.controller';
import { PromotionsService } from './modules/promotions/promotions.service';
import { MiscController } from './modules/misc/misc.controller';

const ENTITIES = [
  User, Wallet, WalletTransaction, Deposit, Withdrawal, Agent, AgentTransaction,
  Sport, League, Event, Market, Odd, Bet, BetSelection, BetResult, Game, GameSession,
  Promotion, PromoCode, Bonus, Cashback, Streak, Leaderboard, Notification,
  SupportTicket, AdminUser, AuditLog,
];

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
      envFilePath: ['.env', '../../.env'],
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const url = config.get<string>('databaseUrl');
        const nodeEnv = config.get<string>('nodeEnv');
        // In development without a database URL, fall back to an in-memory
        // sqlite-free configuration is not possible with pg; instead we keep
        // synchronize on for dev so the schema is created automatically.
        return {
          type: 'postgres' as const,
          url: url || undefined,
          host: url ? undefined : process.env.DATABASE_HOST ?? 'localhost',
          port: url ? undefined : Number(process.env.DATABASE_PORT ?? 5432),
          username: url ? undefined : process.env.DATABASE_USER ?? 'temp',
          password: url ? undefined : process.env.DATABASE_PASSWORD ?? 'temp',
          database: url ? undefined : process.env.DATABASE_NAME ?? 'temp',
          entities: ENTITIES,
          synchronize: nodeEnv !== 'production',
          logging: nodeEnv === 'development' ? ['error', 'warn'] : false,
          ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false,
        };
      },
    }),
    TypeOrmModule.forFeature(ENTITIES),
    JwtModule.registerAsync({
      global: true,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.get<string>('jwt.secret'),
        signOptions: { expiresIn: config.get<string>('jwt.expiresIn') ?? '7d' },
      }),
    }),
    ThrottlerModule.forRoot([
      { name: 'default', ttl: 60_000, limit: 120 },
    ]),
  ],
  controllers: [
    AuthController,
    WalletController,
    DepositsController,
    WithdrawalsController,
    SportsbookController,
    BetsController,
    GamesController,
    PromotionsController,
    MiscController,
  ],
  providers: [
    // Global rate limiting
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    // Mock providers (swap for licensed providers via env in production)
    MockSportsbookProvider,
    MockCasinoProvider,
    MockPaymentProvider,
    // Services
    AuthService,
    WalletService,
    DepositsService,
    WithdrawalsService,
    SportsbookService,
    BetsService,
    PromotionsService,
  ],
})
export class AppModule {}
