import { createHmac } from 'crypto';
import { verifyTelegramInitData, mockTelegramUser } from '../src/common/telegram-verify';

/**
 * Build a valid initData string signed with the given bot token,
 * mirroring Telegram's documented algorithm.
 */
function signInitData(botToken: string, fields: Record<string, string>): string {
  const params = new URLSearchParams(fields);
  const dataCheckString = [...params.entries()]
    .map(([k, v]) => `${k}=${v}`)
    .sort()
    .join('\n');
  const secretKey = createHmac('sha256', 'WebAppData').update(botToken).digest();
  const hash = createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
  params.set('hash', hash);
  return params.toString();
}

describe('verifyTelegramInitData', () => {
  const botToken = '123456:TEST_BOT_TOKEN';
  const user = { id: 700000001, first_name: 'Abebe', username: 'abebe_demo' };

  it('accepts a correctly signed payload', () => {
    const initData = signInitData(botToken, {
      auth_date: String(Math.floor(Date.now() / 1000)),
      user: JSON.stringify(user),
    });
    const result = verifyTelegramInitData(initData, botToken, 86400);
    expect(result.user.id).toBe(700000001);
    expect(result.user.first_name).toBe('Abebe');
  });

  it('rejects a tampered payload (wrong signature)', () => {
    const initData = signInitData(botToken, {
      auth_date: String(Math.floor(Date.now() / 1000)),
      user: JSON.stringify(user),
    });
    const tampered = initData.replace('Abebe', 'Hacker');
    expect(() => verifyTelegramInitData(tampered, botToken, 86400)).toThrow(/signature/i);
  });

  it('rejects a payload signed with a different bot token', () => {
    const initData = signInitData('999:OTHER_TOKEN', {
      auth_date: String(Math.floor(Date.now() / 1000)),
      user: JSON.stringify(user),
    });
    expect(() => verifyTelegramInitData(initData, botToken, 86400)).toThrow(/signature/i);
  });

  it('rejects expired auth data', () => {
    const initData = signInitData(botToken, {
      auth_date: String(Math.floor(Date.now() / 1000) - 100000),
      user: JSON.stringify(user),
    });
    expect(() => verifyTelegramInitData(initData, botToken, 86400)).toThrow(/expired/i);
  });

  it('rejects missing hash', () => {
    expect(() => verifyTelegramInitData('auth_date=1&user=%7B%7D', botToken, 86400)).toThrow(/hash/i);
  });

  it('rejects empty initData', () => {
    expect(() => verifyTelegramInitData('', botToken, 86400)).toThrow(/initData/i);
  });

  it('mockTelegramUser returns a deterministic dev user', () => {
    const a = mockTelegramUser();
    const b = mockTelegramUser();
    expect(a.user.id).toBe(b.user.id);
    expect(a.user.id).toBe(700000001);
  });
});
