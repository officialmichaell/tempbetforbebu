import { MockSportsbookProvider } from '../src/providers/mock-sportsbook.provider';
import { MockPaymentProvider } from '../src/providers/mock-payment.provider';
import { MockCasinoProvider } from '../src/providers/mock-casino.provider';

describe('MockSportsbookProvider', () => {
  const provider = new MockSportsbookProvider();

  it('exposes sports', async () => {
    const sports = await provider.getSports();
    expect(sports.length).toBeGreaterThan(0);
    expect(sports[0]).toHaveProperty('name');
  });

  it('returns events with markets and odds', async () => {
    const events = await provider.getEvents();
    expect(events.length).toBeGreaterThan(0);
    expect(events[0].markets.length).toBeGreaterThan(0);
    expect(events[0].markets[0].selections[0].odds).toBeGreaterThan(1);
  });

  it('filters live events', async () => {
    const live = await provider.getEvents({ live: true });
    expect(live.every((e) => e.isLive)).toBe(true);
  });

  it('accepts a valid bet and computes accumulator odds', async () => {
    const res = await provider.placeBet({
      userId: 'u1',
      selections: [
        { eventId: 'e1', selectionId: 's1', odds: 2.0 },
        { eventId: 'e2', selectionId: 's2', odds: 1.5 },
      ],
      stake: 100,
      type: 'accumulator',
    });
    expect(res.accepted).toBe(true);
    expect(res.totalOdds).toBeCloseTo(3.0, 2);
    expect(res.potentialWin).toBeCloseTo(300, 2);
  });

  it('rejects a bet with no selections', async () => {
    const res = await provider.placeBet({ userId: 'u1', selections: [], stake: 100, type: 'single' });
    expect(res.accepted).toBe(false);
  });
});

describe('MockPaymentProvider', () => {
  const provider = new MockPaymentProvider();

  it('creates a pending deposit reference', async () => {
    const res = await provider.createDeposit({ userId: 'u1', amount: 500, method: 'Telebirr' });
    expect(res.status).toBe('pending');
    expect(res.reference).toMatch(/^MOCKDEP_/);
  });

  it('creates a requested withdrawal reference', async () => {
    const res = await provider.createWithdrawal({ userId: 'u1', amount: 200, method: 'Telebirr', account: '+2519' });
    expect(res.status).toBe('requested');
    expect(res.reference).toMatch(/^MOCKWD_/);
  });

  it('verifies webhooks by signature presence (mock)', () => {
    expect(provider.verifyWebhook({}, 'sig')).toBe(true);
    expect(provider.verifyWebhook({}, '')).toBe(false);
  });
});

describe('MockCasinoProvider', () => {
  const provider = new MockCasinoProvider();

  it('lists games and launches a session', async () => {
    const games = await provider.getGames();
    expect(games.length).toBeGreaterThan(0);
    const launch = await provider.launchGame({ userId: 'u1', gameId: games[0].id });
    expect(launch.launchUrl).toContain(games[0].id);
    expect(launch.sessionId).toMatch(/^sess_/);
  });
});
