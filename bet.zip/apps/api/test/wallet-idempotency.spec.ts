import { WalletService } from '../src/modules/wallet/wallet.service';
import { Wallet, WalletTransaction } from '../src/entities';

/**
 * In-memory fakes that emulate the TypeORM repositories + DataSource
 * transaction semantics closely enough to test ledger behaviour.
 */
function makeFakes(initialBalance = 0) {
  const wallet: Wallet = {
    id: 'w1', user_id: 'u1', balance: initialBalance.toFixed(2),
    bonus_balance: '0', pending_balance: '0', currency: 'ETB', updated_at: new Date(),
  } as Wallet;

  const txs: WalletTransaction[] = [];

  const walletsRepo = {
    findOne: async () => wallet,
    save: async (w: Wallet) => w,
    create: (x: Partial<Wallet>) => x as Wallet,
  } as any;

  const txsRepo = {
    findOne: async ({ where }: any) =>
      txs.find((t) => t.idempotency_key === where.idempotency_key) ?? null,
    find: async () => txs,
  } as any;

  const manager = {
    findOne: async () => wallet,
    save: async (x: any) => {
      // Persist ledger rows so idempotency lookups can find them.
      if (x && x.idempotency_key !== undefined && x.type !== undefined) {
        if (!txs.includes(x)) txs.push(x);
      }
      return x;
    },
    create: (_e: any, x: any) => x,
  } as any;

  const dataSource = {
    transaction: async (fn: (m: any) => Promise<any>) => fn(manager),
  } as any;

  const service = new WalletService(walletsRepo, txsRepo, dataSource);
  return { service, wallet, txs };
}

describe('WalletService — ledger integrity', () => {
  it('credits the wallet and writes a ledger row', async () => {
    const { service, wallet, txs } = makeFakes(0);
    const tx = await service.applyTransaction({ userId: 'u1', type: 'deposit', amount: 500 });
    expect(Number(wallet.balance)).toBe(500);
    expect(Number(tx.balance_after)).toBe(500);
    expect(txs.length).toBe(1);
  });

  it('is idempotent: the same key never double-credits', async () => {
    const { service, wallet, txs } = makeFakes(0);
    const key = 'deposit_dep_123';
    const first = await service.applyTransaction({ userId: 'u1', type: 'deposit', amount: 500, idempotencyKey: key });
    const second = await service.applyTransaction({ userId: 'u1', type: 'deposit', amount: 500, idempotencyKey: key });
    expect(Number(wallet.balance)).toBe(500); // NOT 1000
    expect(first.id).toBe(second.id);
    expect(txs.length).toBe(1);
  });

  it('rejects a debit that would make the balance negative', async () => {
    const { service } = makeFakes(100);
    await expect(
      service.applyTransaction({ userId: 'u1', type: 'bet_stake', amount: -250 }),
    ).rejects.toThrow(/insufficient/i);
  });

  it('handles a full deposit → bet → win → withdrawal sequence', async () => {
    const { service, wallet } = makeFakes(0);
    await service.applyTransaction({ userId: 'u1', type: 'deposit', amount: 500, idempotencyKey: 'd1' });
    await service.applyTransaction({ userId: 'u1', type: 'bet_stake', amount: -100, idempotencyKey: 'b1' });
    await service.applyTransaction({ userId: 'u1', type: 'bet_win', amount: 180, idempotencyKey: 'w1' });
    await service.applyTransaction({ userId: 'u1', type: 'withdrawal', amount: -200, idempotencyKey: 'wd1' });
    expect(Number(wallet.balance)).toBe(380);
  });

  it('rounds to 2 decimals (no floating point drift)', async () => {
    const { service, wallet } = makeFakes(0);
    await service.applyTransaction({ userId: 'u1', type: 'deposit', amount: 0.1 });
    await service.applyTransaction({ userId: 'u1', type: 'deposit', amount: 0.2 });
    expect(Number(wallet.balance)).toBe(0.3);
  });
});
