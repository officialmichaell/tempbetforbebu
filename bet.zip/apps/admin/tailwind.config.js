/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        deepBlack: '#080B10',
        darkNavy: '#0D1420',
        darkSurface: '#111927',
        electric: '#2196FF',
        bright: '#3B9CFF',
        purple: '#8B5CF6',
        cyan: '#22D3EE',
        success: '#22C55E',
        danger: '#EF4444',
        gold: '#F5C518',
        muted: '#94A3B8',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        glass: '20px',
      },
      boxShadow: {
        glass: '0 10px 40px rgba(0,0,0,0.25)',
        glow: '0 0 24px rgba(33,150,255,0.35)',
      },
    },
  },
  plugins: [],
};
