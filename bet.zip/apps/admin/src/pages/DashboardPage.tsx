import { GlassCard, StatTile, SectionHeader, Pill } from '../components/ui';
import { IconUsers, IconDeposit, IconWithdraw, IconBet, IconTrend, IconSupport, IconAgent } from '../components/Icons';
import { DASHBOARD, REVENUE_SERIES, DEPOSITS, WITHDRAWALS, USERS, AUDIT_LOGS } from '../lib/adminData';
import { formatETB, timeAgo } from '@temp/utils';

export default function DashboardPage() {
  const max = Math.max(...REVENUE_SERIES.map((r) => r.deposits));
  const pendingDeps = DEPOSITS.filter((d) => d.state === 'PENDING' || d.state === 'AGENT_CONFIRMED').slice(0, 5);
  const pendingWds = WITHDRAWALS.filter((w) => w.state === 'REQUESTED' || w.state === 'UNDER_REVIEW').slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile label="Total Users" value={DASHBOARD.totalUsers.toLocaleString()} delta={`+${DASHBOARD.newUsersToday} today`} accent="#2196FF" icon={<IconUsers width={18} height={18} />} />
        <StatTile label="Active 24h" value={DASHBOARD.activeUsers24h.toLocaleString()} delta="+12.4%" accent="#22C55E" icon={<IconTrend width={18} height={18} />} />
        <StatTile label="Total Deposits" value={formatETB(DASHBOARD.totalDeposits)} delta="+8.1%" accent="#8B5CF6" icon={<IconDeposit width={18} height={18} />} />
        <StatTile label="Total Withdrawals" value={formatETB(DASHBOARD.totalWithdrawals)} delta="-3.2%" accent="#F5C518" icon={<IconWithdraw width={18} height={18} />} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile label="GGR" value={formatETB(DASHBOARD.ggr)} accent="#22D3EE" icon={<IconTrend width={18} height={18} />} />
        <StatTile label="Total Bets" value={DASHBOARD.totalBets.toLocaleString()} accent="#3B9CFF" icon={<IconBet width={18} height={18} />} />
        <StatTile label="Pending Deposits" value={String(DASHBOARD.pendingDeposits)} accent="#F5C518" icon={<IconDeposit width={18} height={18} />} />
        <StatTile label="Pending Withdrawals" value={String(DASHBOARD.pendingWithdrawals)} accent="#EF4444" icon={<IconWithdraw width={18} height={18} />} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="p-5 lg:col-span-2">
          <SectionHeader title="Revenue — Last 14 Days" subtitle="Deposits vs withdrawals vs GGR (mock)" />
          <div className="flex items-end gap-2 h-48 mt-4">
            {REVENUE_SERIES.map((r) => (
              <div key={r.day} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col justify-end gap-0.5" style={{ height: 160 }}>
                  <div className="w-full rounded-t bg-gradient-to-t from-electric to-bright" style={{ height: `${(r.deposits / max) * 100}%` }} title={`Deposits ${formatETB(r.deposits)}`} />
                  <div className="w-full rounded-t bg-purple/60" style={{ height: `${(r.withdrawals / max) * 100}%` }} title={`Withdrawals ${formatETB(r.withdrawals)}`} />
                </div>
                <span className="text-[9px] text-muted">{r.day}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-3 text-[11px] text-muted">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-electric" /> Deposits</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-purple/60" /> Withdrawals</span>
          </div>
        </GlassCard>

        <GlassCard className="p-5">
          <SectionHeader title="Operations" subtitle="Items needing attention" />
          <div className="space-y-3">
            <OpRow icon={<IconDeposit width={16} height={16} />} label="Deposits awaiting review" value={DASHBOARD.pendingDeposits} accent="#F5C518" />
            <OpRow icon={<IconWithdraw width={16} height={16} />} label="Withdrawals awaiting review" value={DASHBOARD.pendingWithdrawals} accent="#EF4444" />
            <OpRow icon={<IconSupport width={16} height={16} />} label="Open support tickets" value={DASHBOARD.openTickets} accent="#8B5CF6" />
            <OpRow icon={<IconAgent width={16} height={16} />} label="Active agents" value={DASHBOARD.activeAgents} accent="#22C55E" />
          </div>
        </GlassCard>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard className="p-5">
          <SectionHeader title="Recent Deposits" subtitle="Latest agent deposits" />
          <div className="space-y-2">
            {pendingDeps.map((d) => {
              const u = USERS.find((x) => x.id === d.user_id);
              return (
                <div key={d.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <div>
                    <div className="text-sm font-semibold">{u?.first_name} {u?.last_name}</div>
                    <div className="text-[11px] text-muted">{d.method} · {timeAgo(d.created_at)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold">{formatETB(d.amount)}</div>
                    <Pill state={d.state} />
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>

        <GlassCard className="p-5">
          <SectionHeader title="Recent Withdrawals" subtitle="Latest payout requests" />
          <div className="space-y-2">
            {pendingWds.map((w) => {
              const u = USERS.find((x) => x.id === w.user_id);
              return (
                <div key={w.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <div>
                    <div className="text-sm font-semibold">{u?.first_name} {u?.last_name}</div>
                    <div className="text-[11px] text-muted">{w.method} · {timeAgo(w.created_at)}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold">{formatETB(w.amount)}</div>
                    <Pill state={w.state} />
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-5">
        <SectionHeader title="Recent Activity" subtitle="Audit trail (mock)" />
        <div className="space-y-1">
          {AUDIT_LOGS.slice(0, 6).map((l) => (
            <div key={l.id} className="flex items-center justify-between py-2 text-sm border-b border-white/5 last:border-0">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-electric" />
                <span className="font-mono text-xs text-bright">{l.action}</span>
                <span className="text-muted text-xs">{l.entity} · {l.entity_id}</span>
              </div>
              <span className="text-[11px] text-muted">{l.actor} · {timeAgo(l.created_at)}</span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}

function OpRow({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: number; accent: string }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2.5">
        <span className="w-8 h-8 rounded-lg grid place-items-center" style={{ background: `${accent}22`, color: accent }}>{icon}</span>
        <span className="text-sm text-muted">{label}</span>
      </div>
      <span className="font-bold">{value}</span>
    </div>
  );
}
