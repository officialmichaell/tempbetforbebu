import { useState } from 'react';
import { DataTable, type Column } from '../components/DataTable';
import { Pill, Button, Modal, GlassCard } from '../components/ui';
import { WITHDRAWALS, USERS } from '../lib/adminData';
import type { Withdrawal } from '@temp/types';
import { formatETB, timeAgo } from '@temp/utils';

const FLOW = ['REQUESTED', 'UNDER_REVIEW', 'APPROVED', 'PROCESSING', 'COMPLETED'];

export default function WithdrawalsPage() {
  const [selected, setSelected] = useState<Withdrawal | null>(null);
  const [rows, setRows] = useState(WITHDRAWALS);

  const advance = (w: Withdrawal, state: string) => {
    setRows((rs) => rs.map((r) => (r.id === w.id ? { ...r, state: state as Withdrawal['state'] } : r)));
    setSelected(null);
  };

  const columns: Column<Withdrawal>[] = [
    { key: 'id', header: 'ID', render: (w) => <span className="font-mono text-xs text-bright">{w.id}</span> },
    {
      key: 'user', header: 'User', render: (w) => {
        const u = USERS.find((x) => x.id === w.user_id);
        return <span className="text-sm">{u?.first_name} {u?.last_name}</span>;
      },
    },
    { key: 'amount', header: 'Amount', render: (w) => <span className="font-bold">{formatETB(w.amount)}</span> },
    { key: 'method', header: 'Method', render: (w) => <span className="text-xs text-muted">{w.method}</span> },
    { key: 'account', header: 'Account', render: (w) => <span className="font-mono text-xs text-muted">{w.account}</span> },
    { key: 'state', header: 'State', render: (w) => <Pill state={w.state} /> },
    { key: 'created', header: 'Created', render: (w) => <span className="text-xs text-muted">{timeAgo(w.created_at)}</span> },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {FLOW.map((s) => (
          <GlassCard key={s} className="p-4">
            <div className="text-[11px] uppercase tracking-wider text-muted font-semibold">{s.replace(/_/g, ' ')}</div>
            <div className="text-2xl font-extrabold mt-1">{rows.filter((r) => r.state === s).length}</div>
          </GlassCard>
        ))}
      </div>

      <DataTable
        rows={rows}
        columns={columns}
        searchKeys={(w) => `${w.id} ${w.method} ${w.account}`}
        filters={[{ label: 'State', options: [...FLOW, 'REJECTED', 'CANCELLED'], get: (w) => w.state }]}
        actions={(w) => <Button variant="ghost" onClick={() => setSelected(w)}>Review</Button>}
      />

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Withdrawal Review">
        {selected && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Info label="ID" value={selected.id} />
              <Info label="Amount" value={formatETB(selected.amount)} />
              <Info label="Method" value={selected.method} />
              <Info label="Account" value={selected.account} />
            </div>
            <div>
              <div className="text-xs text-muted mb-2 font-semibold">State flow</div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {FLOW.map((s, i) => (
                  <span key={s} className="flex items-center gap-1.5">
                    <span className={`pill ${selected.state === s ? 'pill-processing' : 'pill-neutral'}`}>{s.replace(/_/g, ' ')}</span>
                    {i < FLOW.length - 1 && <span className="text-muted text-xs">→</span>}
                  </span>
                ))}
              </div>
            </div>
            <div className="flex gap-2 pt-2 flex-wrap">
              <Button variant="ghost" onClick={() => advance(selected, 'UNDER_REVIEW')}>Under Review</Button>
              <Button variant="success" onClick={() => advance(selected, 'APPROVED')}>Approve</Button>
              <Button variant="ghost" onClick={() => advance(selected, 'PROCESSING')}>Processing</Button>
              <Button variant="success" onClick={() => advance(selected, 'COMPLETED')}>Complete</Button>
              <Button variant="danger" onClick={() => advance(selected, 'REJECTED')}>Reject</Button>
            </div>
            <p className="text-[11px] text-muted">Amount is held (debited) on request; on REJECTED it is refunded idempotently (key: withdrawal_refund_&lt;id&gt;). Mock-only here.</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <GlassCard className="p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted font-semibold">{label}</div>
      <div className="text-sm font-semibold mt-0.5">{value}</div>
    </GlassCard>
  );
}
