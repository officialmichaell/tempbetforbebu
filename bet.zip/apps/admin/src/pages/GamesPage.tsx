import { DataTable, type Column } from '../components/DataTable';
import { GlassCard, StatTile, Button } from '../components/ui';
import { ADMIN_GAMES } from '../lib/adminData';
import type { Game } from '@temp/types';
import { IconGame } from '../components/Icons';

export default function GamesPage() {
  const columns: Column<Game>[] = [
    {
      key: 'title', header: 'Game', render: (g) => (
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg grid place-items-center text-lg" style={{ background: `linear-gradient(135deg, ${g.gradient[0]}, ${g.gradient[1]})` }}>
            {g.emoji}
          </div>
          <div>
            <div className="font-semibold">{g.title}</div>
            <div className="text-[11px] text-muted">{g.provider}</div>
          </div>
        </div>
      ),
    },
    { key: 'category', header: 'Category', render: (g) => <span className="text-xs">{g.category}</span> },
    { key: 'rtp', header: 'RTP', render: (g) => <span className="font-mono text-xs">{g.rtp}%</span> },
    { key: 'badge', header: 'Badge', render: (g) => g.badge ? <span className="pill pill-processing">{g.badge}</span> : <span className="text-muted text-xs">—</span> },
    { key: 'status', header: 'Status', render: (g) => <span className="pill pill-approved">Active</span> },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile label="Total Games" value={String(ADMIN_GAMES.length)} accent="#2196FF" icon={<IconGame width={18} height={18} />} />
        <StatTile label="Categories" value="9" accent="#8B5CF6" icon={<IconGame width={18} height={18} />} />
        <StatTile label="Avg RTP" value={`${Math.round(ADMIN_GAMES.reduce((s, g) => s + (g.rtp ?? 0), 0) / ADMIN_GAMES.length)}%`} accent="#22C55E" icon={<IconGame width={18} height={18} />} />
        <StatTile label="Coming Soon" value="10" accent="#F5C518" icon={<IconGame width={18} height={18} />} />
      </div>
      <DataTable
        rows={ADMIN_GAMES}
        columns={columns}
        searchKeys={(g) => `${g.title} ${g.provider} ${g.category}`}
        filters={[{ label: 'Category', options: ['Sports', 'Live', 'Casino', 'Crash', 'Slots', 'Table Games', 'Lottery', 'Popular', 'New'], get: (g) => g.category }]}
        actions={() => <Button variant="ghost">Edit</Button>}
      />
      <GlassCard className="p-4 text-xs text-muted">
        Games are launched through the CasinoProvider interface. In production, licensed providers supply launch URLs; the app never embeds proprietary assets.
      </GlassCard>
    </div>
  );
}
