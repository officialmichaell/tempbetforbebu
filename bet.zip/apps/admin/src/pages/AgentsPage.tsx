import { DataTable, type Column } from '../components/DataTable';
import { Pill, GlassCard, StatTile } from '../components/ui';
import { AGENTS, DEPOSITS } from '../lib/adminData';
import type { Agent } from '@temp/types';
import { formatETB, timeAgo } from '@temp/utils';
import { IconAgent, IconDeposit } from '../components/Icons';

export default function AgentsPage() {
  const columns: Column<Agent>[] = [
    { key: 'name', header: 'Agent', render: (a) => <span className="font-semibold">{a.name}</span> },
    { key: 'tg', header: 'Telegram', render: (a) => <span className="text-xs text-muted">@{a.telegram_username}</span> },
    { key: 'phone', header: 'Phone', render: (a) => <span className="font-mono text-xs">{a.phone}</span> },
    {
      key: 'deposits', header: 'Deposits', render: (a) => {
        const ds = DEPOSITS.filter((d) => d.agent_id === a.id);
        return <span className="text-sm">{ds.length} · {formatETB(ds.reduce((s, d) => s + d.amount, 0))}</span>;
      },
    },
    { key: 'status', header: 'Status', render: (a) => <Pill state={a.status} /> },
    { key: 'created', header: 'Since', render: (a) => <span className="text-xs text-muted">{timeAgo(a.created_at)}</span> },
  ];

  const totalConfirmed = DEPOSITS.filter((d) => d.agent_id).reduce((s, d) => s + d.amount, 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile label="Total Agents" value={String(AGENTS.length)} accent="#2196FF" icon={<IconAgent width={18} height={18} />} />
        <StatTile label="Active Agents" value={String(AGENTS.filter((a) => a.status === 'active').length)} accent="#22C55E" icon={<IconAgent width={18} height={18} />} />
        <StatTile label="Agent Deposits" value={formatETB(totalConfirmed)} accent="#8B5CF6" icon={<IconDeposit width={18} height={18} />} />
        <StatTile label="Commission (5%)" value={formatETB(totalConfirmed * 0.05)} accent="#F5C518" icon={<IconDeposit width={18} height={18} />} />
      </div>
      <DataTable
        rows={AGENTS}
        columns={columns}
        searchKeys={(a) => `${a.name} ${a.telegram_username} ${a.phone}`}
        filters={[{ label: 'Status', options: ['active', 'inactive'], get: (a) => a.status }]}
      />
      <GlassCard className="p-4 text-xs text-muted">
        Agents confirm cash deposits on behalf of users. Every agent action is recorded in agent_transactions and audit_logs.
      </GlassCard>
    </div>
  );
}
