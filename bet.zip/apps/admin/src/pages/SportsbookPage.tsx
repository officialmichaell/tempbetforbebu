import { GlassCard, SectionHeader, Button } from '../components/ui';
import { ADMIN_SPORTS, ADMIN_EVENTS } from '../lib/adminData';
import { formatOdds } from '@temp/utils';

export default function SportsbookPage() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {ADMIN_SPORTS.map((s) => (
          <GlassCard key={s.id} className="p-4 text-center">
            <div className="text-2xl">{s.icon}</div>
            <div className="text-sm font-semibold mt-1">{s.name}</div>
            <div className="text-[11px] text-muted">{s.event_count} events</div>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="p-5">
        <SectionHeader title="Events & Markets" subtitle="Provider-independent mock sportsbook feed" action={<Button variant="ghost">Add Event</Button>} />
        <div className="space-y-3">
          {ADMIN_EVENTS.slice(0, 12).map((e) => (
            <div key={e.id} className="glass p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {e.is_live && <span className="pill pill-rejected">LIVE</span>}
                  <span className="text-xs text-muted">{e.league_name}</span>
                </div>
                <span className="text-xs text-muted">{new Date(e.start_time).toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between gap-4">
                <div className="font-semibold text-sm">{e.home} <span className="text-muted">vs</span> {e.away}</div>
                <div className="flex gap-2">
                  {e.markets[0]?.selections.map((s) => (
                    <div key={s.id} className="text-center px-3 py-1.5 rounded-lg bg-white/5 border border-white/10">
                      <div className="text-[10px] text-muted">{s.name}</div>
                      <div className="text-sm font-bold text-bright">{formatOdds(s.odds)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-4 text-xs text-muted">
        Odds and events are served by the MockSportsbookProvider behind the SportsbookProvider interface. Swapping to a licensed provider requires no frontend changes.
      </GlassCard>
    </div>
  );
}
