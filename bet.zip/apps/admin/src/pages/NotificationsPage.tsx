import { useState } from 'react';
import { GlassCard, SectionHeader, Button } from '../components/ui';
import { USERS } from '../lib/adminData';
import { timeAgo } from '@temp/utils';

interface Broadcast {
  id: string;
  title: string;
  body: string;
  audience: string;
  sent_at: string;
}

const INITIAL: Broadcast[] = [
  { id: 'b1', title: 'Welcome Bonus Live', body: 'Get 100% on your first deposit up to 5,000 ETB.', audience: 'All users', sent_at: new Date(Date.now() - 3600e3).toISOString() },
  { id: 'b2', title: 'Weekly Tournament', body: '50,000 ETB prize pool starts now. Join!', audience: 'Active users', sent_at: new Date(Date.now() - 86400e3).toISOString() },
  { id: 'b3', title: 'Maintenance Notice', body: 'Scheduled maintenance tonight 02:00–03:00.', audience: 'All users', sent_at: new Date(Date.now() - 2 * 86400e3).toISOString() },
];

export default function NotificationsPage() {
  const [items, setItems] = useState(INITIAL);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [audience, setAudience] = useState('All users');

  const send = () => {
    if (!title.trim() || !body.trim()) return;
    setItems((s) => [{ id: `b_${Date.now()}`, title, body, audience, sent_at: new Date().toISOString() }, ...s]);
    setTitle('');
    setBody('');
  };

  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-3 gap-6">
        <GlassCard className="p-5 lg:col-span-1">
          <SectionHeader title="Send Notification" subtitle="Broadcast to users" />
          <div className="space-y-3">
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-electric/50" />
            <textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Message" rows={4} className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-electric/50 resize-none" />
            <select value={audience} onChange={(e) => setAudience(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none">
              <option>All users</option>
              <option>Active users</option>
              <option>New users</option>
              <option>VIP users</option>
            </select>
            <Button className="w-full" onClick={send}>Send Broadcast</Button>
          </div>
        </GlassCard>

        <GlassCard className="p-5 lg:col-span-2">
          <SectionHeader title="Sent Notifications" subtitle={`${items.length} broadcasts`} />
          <div className="space-y-3">
            {items.map((n) => (
              <div key={n.id} className="glass p-4">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-sm">{n.title}</span>
                  <span className="text-[11px] text-muted">{timeAgo(n.sent_at)}</span>
                </div>
                <p className="text-xs text-muted mt-1">{n.body}</p>
                <span className="pill pill-processing mt-2 inline-block">{n.audience}</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-4 text-xs text-muted">
        Notifications are delivered to the Mini App notification center and (optionally) via Telegram bot messages. {USERS.length} users in the current dataset.
      </GlassCard>
    </div>
  );
}
