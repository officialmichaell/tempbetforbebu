import { useState } from 'react';
import { GlassCard, SectionHeader, Button, Pill } from '../components/ui';
import { ADMIN_PROMOTIONS } from '../lib/adminData';

export default function PromotionsPage() {
  const [promos, setPromos] = useState(ADMIN_PROMOTIONS);

  const toggle = (id: string) => setPromos((ps) => ps.map((p) => (p.id === id ? { ...p, active: !p.active } : p)));

  return (
    <div className="space-y-6">
      <SectionHeader title="Promotions" subtitle="Manage bonuses, tournaments, missions and rewards" action={<Button>Create Promotion</Button>} />
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {promos.map((p) => (
          <GlassCard key={p.id} className="p-5">
            <div className="flex items-start justify-between">
              <div className="w-11 h-11 rounded-xl grid place-items-center text-lg font-bold" style={{ background: `linear-gradient(135deg, ${p.gradient[0]}, ${p.gradient[1]})` }}>
                🎁
              </div>
              <Pill state={p.active ? 'active' : 'inactive'} />
            </div>
            <h3 className="font-bold mt-3">{p.title}</h3>
            <p className="text-xs text-muted mt-1 leading-relaxed">{p.description}</p>
            <div className="flex items-center justify-between mt-4">
              <span className="text-[11px] uppercase tracking-wider text-muted font-semibold">{p.category}</span>
              <Button variant={p.active ? 'danger' : 'success'} onClick={() => toggle(p.id)}>
                {p.active ? 'Disable' : 'Enable'}
              </Button>
            </div>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="p-5">
        <SectionHeader title="Promo Codes" subtitle="Redeemable codes and their rewards" />
        <div className="space-y-2">
          {[
            { code: 'TEMP100', reward: 100, uses: 342, active: true },
            { code: 'WELCOME', reward: 250, uses: 128, active: true },
            { code: 'EXPIRED', reward: 0, uses: 89, active: false },
            { code: 'VIPONLY', reward: 500, uses: 12, active: true },
          ].map((c) => (
            <div key={c.code} className="flex items-center justify-between py-2.5 border-b border-white/5 last:border-0">
              <div className="flex items-center gap-3">
                <span className="font-mono font-bold text-bright">{c.code}</span>
                <span className="text-xs text-muted">{c.uses} uses</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold">{c.reward} ETB</span>
                <Pill state={c.active ? 'active' : 'inactive'} />
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}
