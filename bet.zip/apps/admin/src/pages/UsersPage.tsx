import { useState } from 'react';
import { DataTable, type Column } from '../components/DataTable';
import { Pill, Button, Modal, GlassCard } from '../components/ui';
import { USERS } from '../lib/adminData';
import type { User } from '@temp/types';
import { formatETB, timeAgo } from '@temp/utils';

export default function UsersPage() {
  const [selected, setSelected] = useState<User | null>(null);

  const columns: Column<User>[] = [
    {
      key: 'user', header: 'User', render: (u) => (
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full grid place-items-center bg-gradient-to-br from-electric to-purple font-bold text-xs">
            {u.first_name[0]}{u.last_name?.[0]}
          </div>
          <div>
            <div className="font-semibold">{u.first_name} {u.last_name}</div>
            <div className="text-[11px] text-muted">@{u.telegram_username}</div>
          </div>
        </div>
      ),
    },
    { key: 'tg', header: 'Telegram ID', render: (u) => <span className="font-mono text-xs text-muted">{u.telegram_id}</span> },
    { key: 'phone', header: 'Phone', render: (u) => <span className="text-xs">{u.phone ?? '—'}</span> },
    { key: 'status', header: 'Status', render: (u) => <Pill state={u.status} /> },
    { key: 'joined', header: 'Joined', render: (u) => <span className="text-xs text-muted">{timeAgo(u.created_at)}</span> },
  ];

  return (
    <div className="space-y-4">
      <DataTable
        rows={USERS}
        columns={columns}
        searchKeys={(u) => `${u.first_name} ${u.last_name} ${u.telegram_username} ${u.telegram_id}`}
        filters={[{ label: 'Status', options: ['active', 'restricted', 'suspended', 'self_excluded', 'pending'], get: (u) => u.status }]}
        actions={(u) => <Button variant="ghost" onClick={() => setSelected(u)}>View</Button>}
      />

      <Modal open={!!selected} onClose={() => setSelected(null)} title="User Details">
        {selected && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-full grid place-items-center bg-gradient-to-br from-electric to-purple font-bold text-lg">
                {selected.first_name[0]}{selected.last_name?.[0]}
              </div>
              <div>
                <div className="font-bold text-lg">{selected.first_name} {selected.last_name}</div>
                <div className="text-sm text-muted">@{selected.telegram_username}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Info label="Telegram ID" value={selected.telegram_id} />
              <Info label="Status" value={selected.status} />
              <Info label="Phone" value={selected.phone ?? '—'} />
              <Info label="Language" value={selected.language ?? 'en'} />
              <Info label="Joined" value={timeAgo(selected.created_at)} />
              <Info label="Balance (mock)" value={formatETB(1250)} />
            </div>
            <div className="flex gap-2 pt-2">
              <Button variant="success">Activate</Button>
              <Button variant="ghost">Restrict</Button>
              <Button variant="danger">Suspend</Button>
            </div>
            <p className="text-[11px] text-muted">Actions are mock-only in this prototype. In production they are RBAC-guarded and audited.</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <GlassCard className="p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted font-semibold">{label}</div>
      <div className="text-sm font-semibold mt-0.5">{value}</div>
    </GlassCard>
  );
}
