import { useState } from 'react';
import { GlassCard, SectionHeader } from '../components/ui';
import { adminLeaderboard } from '../lib/adminData';
import { formatETB } from '@temp/utils';

export default function LeaderboardPage() {
  const [period, setPeriod] = useState<'weekly' | 'monthly' | 'all'>('weekly');
  const rows = adminLeaderboard(period);

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Leaderboard"
        subtitle="Top players by points and winnings"
        action={
          <div className="flex gap-1 bg-white/5 rounded-xl p-1">
            {(['weekly', 'monthly', 'all'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize ${period === p ? 'bg-electric text-white' : 'text-muted'}`}
              >
                {p === 'all' ? 'All-time' : p}
              </button>
            ))}
          </div>
        }
      />

      <div className="grid grid-cols-3 gap-4">
        {rows.slice(0, 3).map((r, i) => (
          <GlassCard key={r.user_id} className="p-5 text-center">
            <div className="text-3xl mb-2">{['🥇', '🥈', '🥉'][i]}</div>
            <div className="font-bold">{r.username}</div>
            <div className="text-xs text-muted mt-1">{r.points.toLocaleString()} pts</div>
            <div className="text-sm font-semibold text-gold mt-1">{formatETB(r.winnings)}</div>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="overflow-hidden">
        <table className="admin-table">
          <thead>
            <tr><th>Rank</th><th>Player</th><th>Points</th><th>Winnings</th></tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.user_id}>
                <td className="font-bold">#{r.rank}</td>
                <td>{r.username}</td>
                <td className="font-mono text-xs">{r.points.toLocaleString()}</td>
                <td className="font-semibold text-gold">{formatETB(r.winnings)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </GlassCard>
    </div>
  );
}
