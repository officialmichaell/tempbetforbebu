import { DataTable, type Column } from '../components/DataTable';
import { Pill, StatTile } from '../components/ui';
import { BETS, USERS } from '../lib/adminData';
import type { Bet } from '@temp/types';
import { formatETB, formatOdds, timeAgo } from '@temp/utils';
import { IconBet, IconTrend } from '../components/Icons';

export default function BetsPage() {
  const columns: Column<Bet>[] = [
    { key: 'id', header: 'Bet ID', render: (b) => <span className="font-mono text-xs text-bright">{b.id}</span> },
    {
      key: 'user', header: 'User', render: (b) => {
        const u = USERS.find((x) => x.id === b.user_id);
        return <span className="text-sm">{u?.first_name} {u?.last_name}</span>;
      },
    },
    { key: 'type', header: 'Type', render: (b) => <span className="text-xs capitalize">{b.type}</span> },
    { key: 'stake', header: 'Stake', render: (b) => <span className="font-semibold">{formatETB(b.stake)}</span> },
    { key: 'odds', header: 'Odds', render: (b) => <span className="font-mono text-xs">{formatOdds(b.total_odds)}</span> },
    { key: 'win', header: 'Potential', render: (b) => <span className="text-xs">{formatETB(b.potential_win)}</span> },
    { key: 'state', header: 'State', render: (b) => <Pill state={b.state} /> },
    { key: 'created', header: 'Placed', render: (b) => <span className="text-xs text-muted">{timeAgo(b.created_at)}</span> },
  ];

  const totalStake = BETS.reduce((s, b) => s + b.stake, 0);
  const totalPayout = BETS.filter((b) => b.payout).reduce((s, b) => s + (b.payout ?? 0), 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile label="Total Bets" value={String(BETS.length)} accent="#2196FF" icon={<IconBet width={18} height={18} />} />
        <StatTile label="Total Staked" value={formatETB(totalStake)} accent="#8B5CF6" icon={<IconBet width={18} height={18} />} />
        <StatTile label="Total Payout" value={formatETB(totalPayout)} accent="#22C55E" icon={<IconTrend width={18} height={18} />} />
        <StatTile label="GGR (mock)" value={formatETB(totalStake - totalPayout)} accent="#F5C518" icon={<IconTrend width={18} height={18} />} />
      </div>
      <DataTable
        rows={BETS}
        columns={columns}
        searchKeys={(b) => `${b.id} ${b.type}`}
        filters={[
          { label: 'State', options: ['pending', 'won', 'lost', 'void', 'cashed_out'], get: (b) => b.state },
          { label: 'Type', options: ['single', 'accumulator'], get: (b) => b.type },
        ]}
      />
    </div>
  );
}
