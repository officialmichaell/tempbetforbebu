import { useState } from 'react';
import { DataTable, type Column } from '../components/DataTable';
import { Pill, Button, Modal, GlassCard } from '../components/ui';
import { TICKETS, USERS } from '../lib/adminData';
import type { SupportTicket } from '@temp/types';
import { timeAgo } from '@temp/utils';

export default function SupportPage() {
  const [selected, setSelected] = useState<SupportTicket | null>(null);
  const [rows, setRows] = useState(TICKETS);

  const setState = (t: SupportTicket, state: string) => {
    setRows((rs) => rs.map((r) => (r.id === t.id ? { ...r, state: state as SupportTicket['state'] } : r)));
    setSelected(null);
  };

  const columns: Column<SupportTicket>[] = [
    { key: 'id', header: 'Ticket', render: (t) => <span className="font-mono text-xs text-bright">{t.id}</span> },
    {
      key: 'user', header: 'User', render: (t) => {
        const u = USERS.find((x) => x.id === t.user_id);
        return <span className="text-sm">{u?.first_name} {u?.last_name}</span>;
      },
    },
    { key: 'subject', header: 'Subject', render: (t) => <span className="text-sm font-medium">{t.subject}</span> },
    { key: 'category', header: 'Category', render: (t) => <span className="text-xs text-muted">{t.category}</span> },
    { key: 'state', header: 'State', render: (t) => <Pill state={t.state} /> },
    { key: 'created', header: 'Created', render: (t) => <span className="text-xs text-muted">{timeAgo(t.created_at)}</span> },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {['open', 'pending', 'resolved', 'closed'].map((s) => (
          <GlassCard key={s} className="p-4">
            <div className="text-[11px] uppercase tracking-wider text-muted font-semibold">{s}</div>
            <div className="text-2xl font-extrabold mt-1">{rows.filter((r) => r.state === s).length}</div>
          </GlassCard>
        ))}
      </div>

      <DataTable
        rows={rows}
        columns={columns}
        searchKeys={(t) => `${t.id} ${t.subject} ${t.category}`}
        filters={[{ label: 'State', options: ['open', 'pending', 'resolved', 'closed'], get: (t) => t.state }]}
        actions={(t) => <Button variant="ghost" onClick={() => setSelected(t)}>Open</Button>}
      />

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Support Ticket">
        {selected && (
          <div className="space-y-4">
            <div>
              <div className="font-bold">{selected.subject}</div>
              <div className="text-xs text-muted mt-0.5">{selected.category} · {timeAgo(selected.created_at)}</div>
            </div>
            <GlassCard className="p-4 text-sm">{selected.message}</GlassCard>
            <div className="flex gap-2 flex-wrap">
              <Button variant="ghost" onClick={() => setState(selected, 'pending')}>Mark Pending</Button>
              <Button variant="success" onClick={() => setState(selected, 'resolved')}>Resolve</Button>
              <Button variant="danger" onClick={() => setState(selected, 'closed')}>Close</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
