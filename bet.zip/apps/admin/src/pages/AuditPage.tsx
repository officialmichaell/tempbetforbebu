import { DataTable, type Column } from '../components/DataTable';
import { GlassCard } from '../components/ui';
import { AUDIT_LOGS } from '../lib/adminData';
import type { AuditLog } from '@temp/types';
import { timeAgo } from '@temp/utils';

export default function AuditPage() {
  const columns: Column<AuditLog>[] = [
    { key: 'action', header: 'Action', render: (l) => <span className="font-mono text-xs text-bright">{l.action}</span> },
    { key: 'entity', header: 'Entity', render: (l) => <span className="text-sm">{l.entity}</span> },
    { key: 'entity_id', header: 'Entity ID', render: (l) => <span className="font-mono text-xs text-muted">{l.entity_id}</span> },
    { key: 'actor', header: 'Actor', render: (l) => <span className="text-xs">{l.actor}</span> },
    { key: 'ip', header: 'IP', render: (l) => <span className="font-mono text-xs text-muted">{String((l.meta as any)?.ip ?? '—')}</span> },
    { key: 'created', header: 'When', render: (l) => <span className="text-xs text-muted">{timeAgo(l.created_at)}</span> },
  ];

  return (
    <div className="space-y-4">
      <GlassCard className="p-4 text-xs text-muted">
        Every privileged action is written to an immutable audit log (actor, action, entity, IP, timestamp). This is a mock view.
      </GlassCard>
      <DataTable
        rows={AUDIT_LOGS}
        columns={columns}
        searchKeys={(l) => `${l.action} ${l.entity} ${l.actor}`}
        filters={[{ label: 'Entity', options: ['deposit', 'withdrawal', 'user', 'promotion', 'event', 'agent', 'settings'], get: (l) => l.entity }]}
      />
    </div>
  );
}
