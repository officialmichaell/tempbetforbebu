import { useState } from 'react';
import { DataTable, type Column } from '../components/DataTable';
import { Pill, Button, Modal, GlassCard } from '../components/ui';
import { DEPOSITS, USERS, AGENTS } from '../lib/adminData';
import type { Deposit } from '@temp/types';
import { formatETB, timeAgo } from '@temp/utils';

const FLOW = ['PENDING', 'AGENT_CONFIRMED', 'UNDER_REVIEW', 'APPROVED'];

export default function DepositsPage() {
  const [selected, setSelected] = useState<Deposit | null>(null);
  const [rows, setRows] = useState(DEPOSITS);

  const advance = (d: Deposit, state: string) => {
    setRows((rs) => rs.map((r) => (r.id === d.id ? { ...r, state: state as Deposit['state'] } : r)));
    setSelected(null);
  };

  const columns: Column<Deposit>[] = [
    { key: 'id', header: 'Reference', render: (d) => <span className="font-mono text-xs text-bright">{d.reference}</span> },
    {
      key: 'user', header: 'User', render: (d) => {
        const u = USERS.find((x) => x.id === d.user_id);
        return <span className="text-sm">{u?.first_name} {u?.last_name}</span>;
      },
    },
    { key: 'amount', header: 'Amount', render: (d) => <span className="font-bold">{formatETB(d.amount)}</span> },
    { key: 'method', header: 'Method', render: (d) => <span className="text-xs text-muted">{d.method}</span> },
    {
      key: 'agent', header: 'Agent', render: (d) => {
        const a = AGENTS.find((x) => x.id === d.agent_id);
        return <span className="text-xs text-muted">{a?.name ?? '—'}</span>;
      },
    },
    { key: 'state', header: 'State', render: (d) => <Pill state={d.state} /> },
    { key: 'created', header: 'Created', render: (d) => <span className="text-xs text-muted">{timeAgo(d.created_at)}</span> },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {['PENDING', 'AGENT_CONFIRMED', 'UNDER_REVIEW', 'APPROVED'].map((s) => (
          <GlassCard key={s} className="p-4">
            <div className="text-[11px] uppercase tracking-wider text-muted font-semibold">{s.replace(/_/g, ' ')}</div>
            <div className="text-2xl font-extrabold mt-1">{rows.filter((r) => r.state === s).length}</div>
          </GlassCard>
        ))}
      </div>

      <DataTable
        rows={rows}
        columns={columns}
        searchKeys={(d) => `${d.reference} ${d.method}`}
        filters={[{ label: 'State', options: ['PENDING', 'AGENT_CONFIRMED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'CANCELLED'], get: (d) => d.state }]}
        actions={(d) => <Button variant="ghost" onClick={() => setSelected(d)}>Review</Button>}
      />

      <Modal open={!!selected} onClose={() => setSelected(null)} title="Deposit Review">
        {selected && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Info label="Reference" value={selected.reference ?? '—'} />
              <Info label="Amount" value={formatETB(selected.amount)} />
              <Info label="Method" value={selected.method} />
              <Info label="State" value={selected.state} />
            </div>
            <div>
              <div className="text-xs text-muted mb-2 font-semibold">State flow</div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {FLOW.map((s, i) => (
                  <span key={s} className="flex items-center gap-1.5">
                    <span className={`pill ${selected.state === s ? 'pill-processing' : 'pill-neutral'}`}>{s.replace(/_/g, ' ')}</span>
                    {i < FLOW.length - 1 && <span className="text-muted text-xs">→</span>}
                  </span>
                ))}
              </div>
            </div>
            <div className="flex gap-2 pt-2 flex-wrap">
              <Button variant="success" onClick={() => advance(selected, 'APPROVED')}>Approve</Button>
              <Button variant="ghost" onClick={() => advance(selected, 'UNDER_REVIEW')}>Under Review</Button>
              <Button variant="danger" onClick={() => advance(selected, 'REJECTED')}>Reject</Button>
              <Button variant="ghost" onClick={() => advance(selected, 'CANCELLED')}>Cancel</Button>
            </div>
            <p className="text-[11px] text-muted">On APPROVED the wallet ledger is credited idempotently (key: deposit_&lt;id&gt;). Mock-only here.</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <GlassCard className="p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted font-semibold">{label}</div>
      <div className="text-sm font-semibold mt-0.5">{value}</div>
    </GlassCard>
  );
}
