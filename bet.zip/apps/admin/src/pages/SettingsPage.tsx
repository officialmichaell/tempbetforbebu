import { GlassCard, SectionHeader, Pill, Button } from '../components/ui';
import { ADMIN_USERS } from '../lib/adminData';
import { IconShield } from '../components/Icons';

const FLAGS = [
  { key: 'ENABLE_TELEGRAM_AUTH', value: true, desc: 'Verify Telegram initData server-side' },
  { key: 'ENABLE_MOCK_BETTING', value: true, desc: 'Allow mock betting (no real money)' },
  { key: 'ENABLE_MOCK_WALLET', value: true, desc: 'Ledger-based mock wallet' },
  { key: 'ENABLE_WITHDRAWALS', value: true, desc: 'Allow withdrawal requests' },
  { key: 'ENABLE_CASINO', value: true, desc: 'Casino games enabled' },
  { key: 'ENABLE_SPORTSBOOK', value: true, desc: 'Sportsbook enabled' },
  { key: 'ENABLE_REAL_BETTING', value: false, desc: 'Real-money betting (LEGAL CLEARANCE REQUIRED)' },
  { key: 'ENABLE_REAL_PAYMENTS', value: false, desc: 'Real payment rails (LEGAL CLEARANCE REQUIRED)' },
  { key: 'REAL_MONEY_ENABLED', value: false, desc: 'Master real-money switch' },
  { key: 'PRODUCTION_BETTING_ENABLED', value: false, desc: 'Production betting switch' },
  { key: 'PAYMENTS_ENABLED', value: false, desc: 'Production payments switch' },
];

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <GlassCard className="p-5">
        <SectionHeader title="Feature Flags" subtitle="Environment-driven. Real-money flags must remain false until legally cleared." />
        <div className="space-y-2">
          {FLAGS.map((f) => (
            <div key={f.key} className="flex items-center justify-between py-2.5 border-b border-white/5 last:border-0">
              <div>
                <div className="font-mono text-xs text-bright">{f.key}</div>
                <div className="text-[11px] text-muted mt-0.5">{f.desc}</div>
              </div>
              <Pill state={f.value ? 'active' : 'inactive'} />
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-5">
        <SectionHeader title="Admin Users & Roles" subtitle="RBAC — least privilege" action={<Button>Invite Admin</Button>} />
        <div className="space-y-2">
          {ADMIN_USERS.map((a) => (
            <div key={a.id} className="flex items-center justify-between py-2.5 border-b border-white/5 last:border-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full grid place-items-center bg-gradient-to-br from-electric to-purple font-bold text-xs">
                  {a.name[0]}
                </div>
                <div>
                  <div className="text-sm font-semibold">{a.name}</div>
                  <div className="text-[11px] text-muted">{a.email}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="pill pill-processing">{a.role.replace(/_/g, ' ')}</span>
                {a.two_factor_enabled && <span className="pill pill-approved"><IconShield width={11} height={11} /> 2FA</span>}
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-5">
        <SectionHeader title="Compliance & Safety" subtitle="Prototype safeguards" />
        <ul className="space-y-2 text-sm text-muted">
          <li>• Real-money betting and payments are disabled by default.</li>
          <li>• No licensed-provider claims are made anywhere in the product.</li>
          <li>• Responsible gaming tools (limits, self-exclusion) are available to users.</li>
          <li>• All financial operations are ledger-based, idempotent and audited.</li>
          <li>• Secrets are never exposed to the frontend.</li>
        </ul>
      </GlassCard>
    </div>
  );
}
