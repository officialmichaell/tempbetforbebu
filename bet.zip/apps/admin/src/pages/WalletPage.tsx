import { DataTable, type Column } from '../components/DataTable';
import { StatTile, GlassCard } from '../components/ui';
import { USERS } from '../lib/adminData';
import { formatETB, seededRandom } from '@temp/utils';
import { IconWallet, IconTrend } from '../components/Icons';

interface WalletRow {
  id: string;
  user: string;
  balance: number;
  bonus: number;
  pending: number;
  currency: string;
}

const rng = seededRandom(4242);
const WALLETS: WalletRow[] = USERS.map((u) => ({
  id: `w_${u.id}`,
  user: `${u.first_name} ${u.last_name}`,
  balance: Math.round(rng() * 12000 * 100) / 100,
  bonus: Math.round(rng() * 800 * 100) / 100,
  pending: Math.round(rng() * 400 * 100) / 100,
  currency: 'ETB',
}));

export default function WalletPage() {
  const total = WALLETS.reduce((s, w) => s + w.balance, 0);
  const bonus = WALLETS.reduce((s, w) => s + w.bonus, 0);
  const pending = WALLETS.reduce((s, w) => s + w.pending, 0);

  const columns: Column<WalletRow>[] = [
    { key: 'user', header: 'User', render: (w) => <span className="text-sm font-medium">{w.user}</span> },
    { key: 'balance', header: 'Balance', render: (w) => <span className="font-bold">{formatETB(w.balance)}</span> },
    { key: 'bonus', header: 'Bonus', render: (w) => <span className="text-sm text-gold">{formatETB(w.bonus)}</span> },
    { key: 'pending', header: 'Pending', render: (w) => <span className="text-sm text-muted">{formatETB(w.pending)}</span> },
    { key: 'currency', header: 'Currency', render: (w) => <span className="text-xs">{w.currency}</span> },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatTile label="Total Liability" value={formatETB(total)} accent="#2196FF" icon={<IconWallet width={18} height={18} />} />
        <StatTile label="Bonus Liability" value={formatETB(bonus)} accent="#F5C518" icon={<IconWallet width={18} height={18} />} />
        <StatTile label="Pending Holds" value={formatETB(pending)} accent="#8B5CF6" icon={<IconTrend width={18} height={18} />} />
        <StatTile label="Wallets" value={String(WALLETS.length)} accent="#22C55E" icon={<IconWallet width={18} height={18} />} />
      </div>
      <DataTable rows={WALLETS} columns={columns} searchKeys={(w) => w.user} />
      <GlassCard className="p-4 text-xs text-muted">
        Balances are derived from the immutable wallet_transactions ledger. The wallet row is a cached projection; the ledger is the source of truth.
      </GlassCard>
    </div>
  );
}
