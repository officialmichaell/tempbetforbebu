/**
 * Admin mock data — DEMO ONLY.
 * In production these come from the API (apps/api) with RBAC enforced server-side.
 */
import type {
  User, Deposit, Withdrawal, Agent, Bet, Game, Promotion, SupportTicket,
  AuditLog, AdminUser, LeaderboardEntry, Sport, Event,
} from '@temp/types';
import { seededRandom } from '@temp/utils';

const rng = seededRandom(777001);

const FIRST = ['Abebe', 'Dawit', 'Selam', 'Yonas', 'Hanna', 'Bekele', 'Marta', 'Tesfaye', 'Liya', 'Kalkidan', 'Nahom', 'Sara', 'Abel', 'Meron', 'Robel', 'Eden', 'Fikru', 'Genet', 'Hailu', 'Iman'];
const LAST = ['Kebede', 'Tesfaye', 'Alemu', 'Girma', 'Haile', 'Bekele', 'Mekonnen', 'Assefa', 'Desta', 'Wolde'];

export const ADMIN_USERS: AdminUser[] = [
  { id: 'a1', email: 'owner@temp.et', name: 'Owner', role: 'super_admin', two_factor_enabled: true, created_at: new Date(Date.now() - 120 * 86400e3).toISOString() },
  { id: 'a2', email: 'finance@temp.et', name: 'Finance Lead', role: 'finance', two_factor_enabled: true, created_at: new Date(Date.now() - 90 * 86400e3).toISOString() },
  { id: 'a3', email: 'support@temp.et', name: 'Support Agent', role: 'support', two_factor_enabled: false, created_at: new Date(Date.now() - 60 * 86400e3).toISOString() },
  { id: 'a4', email: 'agents@temp.et', name: 'Agent Manager', role: 'agent_manager', two_factor_enabled: true, created_at: new Date(Date.now() - 45 * 86400e3).toISOString() },
];

export const CURRENT_ADMIN = ADMIN_USERS[0];

export const USERS: User[] = Array.from({ length: 48 }).map((_, i) => {
  const first = FIRST[i % FIRST.length];
  const last = LAST[i % LAST.length];
  const statuses: User['status'][] = ['active', 'active', 'active', 'active', 'restricted', 'suspended', 'self_excluded', 'pending'];
  return {
    id: `u_${1000 + i}`,
    telegram_id: String(700000000 + i * 137),
    telegram_username: `${first.toLowerCase()}_${last.toLowerCase()}`,
    first_name: first,
    last_name: last,
    phone: i % 3 === 0 ? `+2519${String(10000000 + i * 111).slice(0, 8)}` : null,
    avatar_url: null,
    status: statuses[i % statuses.length],
    language: 'en',
    created_at: new Date(Date.now() - (i + 1) * 2.3 * 86400e3).toISOString(),
    updated_at: new Date(Date.now() - i * 3600e3).toISOString(),
  };
});

export const DEPOSITS: Deposit[] = Array.from({ length: 36 }).map((_, i) => {
  const states: Deposit['state'][] = ['PENDING', 'AGENT_CONFIRMED', 'UNDER_REVIEW', 'APPROVED', 'APPROVED', 'REJECTED', 'CANCELLED'];
  const methods = ['Telebirr', 'CBE Birr', 'Agent Cash', 'Bank Transfer'];
  return {
    id: `dep_${5000 + i}`,
    user_id: USERS[i % USERS.length].id,
    agent_id: i % 2 === 0 ? `ag_${i % 6}` : null,
    amount: Math.round((100 + rng() * 4900) / 10) * 10,
    method: methods[i % methods.length],
    state: states[i % states.length],
    reference: `MOCKDEP_${1700000000 + i * 999}`,
    note: null,
    created_at: new Date(Date.now() - i * 5.4 * 3600e3).toISOString(),
    updated_at: new Date(Date.now() - i * 5.4 * 3600e3).toISOString(),
  };
});

export const WITHDRAWALS: Withdrawal[] = Array.from({ length: 28 }).map((_, i) => {
  const states: Withdrawal['state'][] = ['REQUESTED', 'UNDER_REVIEW', 'APPROVED', 'PROCESSING', 'COMPLETED', 'COMPLETED', 'REJECTED', 'CANCELLED'];
  const methods = ['Telebirr', 'CBE Birr', 'Bank Transfer'];
  return {
    id: `wd_${6000 + i}`,
    user_id: USERS[(i + 3) % USERS.length].id,
    amount: Math.round((200 + rng() * 7800) / 10) * 10,
    method: methods[i % methods.length],
    account: `+2519${String(20000000 + i * 321).slice(0, 8)}`,
    state: states[i % states.length],
    note: null,
    created_at: new Date(Date.now() - i * 7.1 * 3600e3).toISOString(),
    updated_at: new Date(Date.now() - i * 7.1 * 3600e3).toISOString(),
  };
});

export const AGENTS: Agent[] = Array.from({ length: 6 }).map((_, i) => ({
  id: `ag_${i}`,
  name: ['Addis Central', 'Bole Hub', 'Merkato Point', 'Kazanchis Agent', 'Piassa Corner', 'Hawassa Branch'][i],
  telegram_username: ['addis_agent', 'bole_agent', 'merkato_agent', 'kazanchis_agent', 'piassa_agent', 'hawassa_agent'][i],
  phone: `+2519${String(30000000 + i * 777).slice(0, 8)}`,
  status: i === 5 ? 'inactive' : 'active',
  created_at: new Date(Date.now() - (i + 1) * 20 * 86400e3).toISOString(),
}));

export const BETS: Bet[] = Array.from({ length: 40 }).map((_, i) => {
  const states: Bet['state'][] = ['pending', 'won', 'lost', 'won', 'lost', 'void', 'cashed_out'];
  const stake = Math.round((20 + rng() * 480) / 10) * 10;
  const odds = Math.round((1.4 + rng() * 4) * 100) / 100;
  const state = states[i % states.length];
  return {
    id: `bet_${7000 + i}`,
    user_id: USERS[i % USERS.length].id,
    type: i % 3 === 0 ? 'accumulator' : 'single',
    stake,
    total_odds: odds,
    potential_win: Math.round(stake * odds * 100) / 100,
    state,
    payout: state === 'won' ? Math.round(stake * odds * 100) / 100 : state === 'cashed_out' ? Math.round(stake * 0.8 * 100) / 100 : null,
    selections: [
      {
        event_id: `evt_${i}`,
        event_label: ['Man Utd vs Arsenal', 'Lakers vs Celtics', 'Djokovic vs Alcaraz', 'NAVI vs FaZe'][i % 4],
        market_name: 'Match Result',
        selection_name: ['Home', 'Away', 'Draw'][i % 3],
        odds,
      },
    ],
    created_at: new Date(Date.now() - i * 3.2 * 3600e3).toISOString(),
  };
});

export const ADMIN_GAMES: Game[] = Array.from({ length: 40 }).map((_, i) => ({
  id: `game_${i + 1}`,
  slug: `game-${i + 1}`,
  title: ['Football', 'Roulette', 'Crash', 'Golden Fortune', 'Mines', 'Plinko', 'Blackjack', 'Dice', 'Keno', 'Wheel'][i % 10] + (i >= 10 ? ` ${Math.floor(i / 10) + 1}` : ''),
  category: (['Sports', 'Table Games', 'Crash', 'Slots', 'Casino', 'Crash', 'Table Games', 'Casino', 'Lottery', 'Casino'] as Game['category'][])[i % 10],
  provider: ['Sportsbook', 'TemP Originals', 'TemP Originals', 'TemP Slots', 'TemP Originals', 'TemP Originals', 'TemP Originals', 'TemP Originals', 'TemP Originals', 'TemP Originals'][i % 10],
  badge: (['HOT', 'TOP', 'HOT', 'TOP', null, null, null, null, null, null] as Game['badge'][])[i % 10],
  coming_soon: false,
  gradient: ['#2196FF', '#8B5CF6'],
  emoji: '🎮',
  rtp: 92 + Math.round(rng() * 6),
}));

export const ADMIN_PROMOTIONS: Promotion[] = [
  { id: 'p1', title: 'Welcome Bonus', description: '100% first deposit bonus up to 5,000 ETB.', category: 'welcome', badge: 'NEW', cta: 'Claim', gradient: ['#2196FF', '#8B5CF6'], active: true },
  { id: 'p2', title: 'Daily Free Bet', description: '50 ETB free bet on any bet today.', category: 'freebet', badge: 'DAILY', cta: 'Get', gradient: ['#22C55E', '#16A34A'], active: true },
  { id: 'p3', title: 'Deposit Bonus', description: 'Deposit 1,000 ETB get 200 ETB bonus.', category: 'deposit', badge: 'HOT', cta: 'Deposit', gradient: ['#F5C518', '#FF8A00'], active: true },
  { id: 'p4', title: 'Weekly Tournament', description: '50,000 ETB prize pool weekly.', category: 'tournament', badge: 'POOL', cta: 'Join', gradient: ['#8B5CF6', '#4C1D95'], active: true },
  { id: 'p5', title: 'Daily Missions', description: 'Complete missions for points.', category: 'mission', badge: 'MISSIONS', cta: 'View', gradient: ['#22D3EE', '#0E7490'], active: false },
  { id: 'p6', title: 'Loyalty Rewards', description: 'Earn rewards every time you play.', category: 'reward', badge: 'REWARDS', cta: 'Explore', gradient: ['#F43F5E', '#881337'], active: true },
];

export const TICKETS: SupportTicket[] = Array.from({ length: 18 }).map((_, i) => {
  const states: SupportTicket['state'][] = ['open', 'pending', 'resolved', 'closed'];
  const subjects = ['Deposit not credited', 'Withdrawal delay', 'Bonus not applied', 'Account verification', 'Game issue', 'Promo code invalid'];
  return {
    id: `tk_${8000 + i}`,
    user_id: USERS[i % USERS.length].id,
    subject: subjects[i % subjects.length],
    category: ['Payments', 'Withdrawals', 'Bonuses', 'Account', 'Technical', 'Promotions'][i % 6],
    message: 'Customer reported an issue requiring review by the support team.',
    state: states[i % states.length],
    created_at: new Date(Date.now() - i * 4.5 * 3600e3).toISOString(),
    updated_at: new Date(Date.now() - i * 4.5 * 3600e3).toISOString(),
  };
});

export const AUDIT_LOGS: AuditLog[] = Array.from({ length: 30 }).map((_, i) => {
  const actions = ['deposit.approve', 'withdrawal.approve', 'user.suspend', 'promo.create', 'odds.update', 'agent.create', 'settings.update', 'user.restrict'];
  const entities = ['deposit', 'withdrawal', 'user', 'promotion', 'event', 'agent', 'settings', 'user'];
  return {
    id: `log_${9000 + i}`,
    actor: ADMIN_USERS[i % ADMIN_USERS.length].email,
    action: actions[i % actions.length],
    entity: entities[i % entities.length],
    entity_id: `ent_${1000 + i}`,
    meta: { ip: `196.188.${i % 255}.${(i * 7) % 255}` },
    created_at: new Date(Date.now() - i * 1.7 * 3600e3).toISOString(),
  };
});

export function adminLeaderboard(period: 'weekly' | 'monthly' | 'all'): LeaderboardEntry[] {
  const r = seededRandom(period === 'weekly' ? 101 : period === 'monthly' ? 202 : 303);
  return Array.from({ length: 15 }).map((_, i) => ({
    rank: i + 1,
    user_id: USERS[i].id,
    username: `${USERS[i].first_name} ${USERS[i].last_name}`,
    avatar_url: null,
    points: Math.floor(5000 - i * 280 + r() * 200),
    winnings: Math.floor(120000 - i * 6500 + r() * 4000),
  }));
}

// --- Dashboard KPIs -------------------------------------------------------
export const DASHBOARD = {
  totalUsers: USERS.length * 137,
  activeUsers24h: 1842,
  newUsersToday: 96,
  totalDeposits: DEPOSITS.filter((d) => d.state === 'APPROVED').reduce((s, d) => s + d.amount, 0) * 41,
  totalWithdrawals: WITHDRAWALS.filter((w) => w.state === 'COMPLETED').reduce((s, w) => s + w.amount, 0) * 33,
  pendingDeposits: DEPOSITS.filter((d) => d.state === 'PENDING' || d.state === 'AGENT_CONFIRMED').length,
  pendingWithdrawals: WITHDRAWALS.filter((w) => w.state === 'REQUESTED' || w.state === 'UNDER_REVIEW').length,
  openTickets: TICKETS.filter((t) => t.state === 'open').length,
  ggr: 1284500,
  totalBets: BETS.length * 219,
  activeAgents: AGENTS.filter((a) => a.status === 'active').length,
};

export const REVENUE_SERIES = Array.from({ length: 14 }).map((_, i) => ({
  day: `D${i + 1}`,
  deposits: Math.round(40000 + rng() * 60000),
  withdrawals: Math.round(20000 + rng() * 40000),
  ggr: Math.round(15000 + rng() * 30000),
}));

// --- Sportsbook (mock feed for admin view) --------------------------------
export const ADMIN_SPORTS: Sport[] = [
  { id: 's1', key: 'football', name: 'Football', icon: '⚽', event_count: 24 },
  { id: 's2', key: 'basketball', name: 'Basketball', icon: '🏀', event_count: 14 },
  { id: 's3', key: 'tennis', name: 'Tennis', icon: '🎾', event_count: 11 },
  { id: 's4', key: 'volleyball', name: 'Volleyball', icon: '🏐', event_count: 6 },
  { id: 's5', key: 'esports', name: 'Esports', icon: '🎮', event_count: 9 },
  { id: 's6', key: 'horse', name: 'Horse Racing', icon: '🐎', event_count: 8 },
];

const ADMIN_TEAMS: Record<string, string[]> = {
  football: ['Manchester United', 'Arsenal', 'Chelsea', 'Liverpool', 'Real Madrid', 'Barcelona', 'Saint George SC', 'Fasil Kenema'],
  basketball: ['Lakers', 'Celtics', 'Warriors', 'Bulls', 'Heat', 'Nuggets'],
  tennis: ['Djokovic', 'Alcaraz', 'Sinner', 'Medvedev'],
  volleyball: ['Italy', 'Brazil', 'Poland', 'France'],
  esports: ['NAVI', 'FaZe', 'G2', 'Vitality'],
  horse: ['Thunder Bolt', 'Silver Arrow', 'Desert King', 'Night Fury'],
};

const ADMIN_LEAGUES: Record<string, string> = {
  football: 'Premier League', basketball: 'NBA', tennis: 'ATP Masters',
  volleyball: 'Nations League', esports: 'CS2 Major', horse: 'Addis Derby',
};

export const ADMIN_EVENTS: Event[] = (() => {
  const out: Event[] = [];
  let idx = 0;
  for (const sport of ADMIN_SPORTS) {
    const teams = ADMIN_TEAMS[sport.key];
    const count = sport.key === 'football' ? 6 : 3;
    for (let i = 0; i < count; i++) {
      idx++;
      const id = `evt_${idx}`;
      const home = teams[(i * 2) % teams.length];
      let away = teams[(i * 2 + 1) % teams.length];
      if (away === home) away = teams[(i * 2 + 2) % teams.length];
      const isLive = i % 3 === 0;
      const base = Math.round((1.4 + rng() * 2.6) * 100) / 100;
      const draw = Math.round((2.8 + rng() * 1.6) * 100) / 100;
      const awayOdds = Math.round((1.6 + rng() * 3.2) * 100) / 100;
      out.push({
        id,
        sport_id: sport.id,
        league_id: `lg_${sport.key}`,
        league_name: ADMIN_LEAGUES[sport.key],
        home,
        away,
        start_time: new Date(Date.now() + (isLive ? -1 : 1) * (i + 1) * 3600e3).toISOString(),
        is_live: isLive,
        live_score: isLive ? { home: Math.floor(rng() * 4), away: Math.floor(rng() * 4), minute: 10 + Math.floor(rng() * 80) } : null,
        markets: [
          {
            id: `${id}_m1`, event_id: id, name: 'Match Result',
            selections: [
              { id: `${id}_s1`, market_id: `${id}_m1`, name: 'Home', odds: base, active: true },
              { id: `${id}_s2`, market_id: `${id}_m1`, name: 'Draw', odds: draw, active: true },
              { id: `${id}_s3`, market_id: `${id}_m1`, name: 'Away', odds: awayOdds, active: true },
            ],
          },
        ],
      });
    }
  }
  return out;
})();
