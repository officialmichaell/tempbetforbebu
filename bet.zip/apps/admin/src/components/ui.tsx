import type { ReactNode } from 'react';

export function GlassCard({ children, className = '', strong = false }: { children: ReactNode; className?: string; strong?: boolean }) {
  return <div className={`${strong ? 'glass-strong' : 'glass'} ${className}`}>{children}</div>;
}

export function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-end justify-between mb-4">
      <div>
        <h2 className="text-lg font-bold tracking-tight">{title}</h2>
        {subtitle && <p className="text-xs text-muted mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function StatTile({ label, value, delta, accent = '#2196FF', icon }: { label: string; value: string; delta?: string; accent?: string; icon?: ReactNode }) {
  return (
    <GlassCard className="p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-wider text-muted font-semibold">{label}</p>
          <p className="text-2xl font-extrabold mt-1.5">{value}</p>
          {delta && <p className="text-xs mt-1" style={{ color: accent }}>{delta}</p>}
        </div>
        {icon && (
          <div className="w-10 h-10 rounded-xl grid place-items-center" style={{ background: `${accent}22`, color: accent }}>
            {icon}
          </div>
        )}
      </div>
    </GlassCard>
  );
}

export function Pill({ state }: { state: string }) {
  const map: Record<string, string> = {
    PENDING: 'pill-pending', AGENT_CONFIRMED: 'pill-processing', UNDER_REVIEW: 'pill-review',
    APPROVED: 'pill-approved', REJECTED: 'pill-rejected', CANCELLED: 'pill-neutral',
    REQUESTED: 'pill-pending', PROCESSING: 'pill-processing', COMPLETED: 'pill-approved',
    active: 'pill-approved', inactive: 'pill-neutral', restricted: 'pill-pending',
    suspended: 'pill-rejected', self_excluded: 'pill-review', pending: 'pill-pending',
    open: 'pill-pending', resolved: 'pill-approved', closed: 'pill-neutral',
    won: 'pill-approved', lost: 'pill-rejected', void: 'pill-neutral', cashed_out: 'pill-processing',
  };
  return <span className={`pill ${map[state] ?? 'pill-neutral'}`}>{state.replace(/_/g, ' ')}</span>;
}

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton rounded-xl ${className}`} />;
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="text-center py-16">
      <div className="text-4xl mb-3">🗂️</div>
      <p className="font-semibold">{title}</p>
      {hint && <p className="text-sm text-muted mt-1">{hint}</p>}
    </div>
  );
}

export function Button({ children, onClick, variant = 'primary', className = '', type = 'button' }: {
  children: ReactNode; onClick?: () => void; variant?: 'primary' | 'ghost' | 'danger' | 'success'; className?: string; type?: 'button' | 'submit';
}) {
  const styles: Record<string, string> = {
    primary: 'bg-gradient-to-r from-electric to-purple text-white hover:opacity-90',
    ghost: 'bg-white/5 border border-white/10 text-white hover:bg-white/10',
    danger: 'bg-danger/15 text-danger border border-danger/30 hover:bg-danger/25',
    success: 'bg-success/15 text-success border border-success/30 hover:bg-success/25',
  };
  return (
    <button type={type} onClick={onClick} className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${styles[variant]} ${className}`}>
      {children}
    </button>
  );
}

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4" style={{ background: 'rgba(0,0,0,0.6)' }} onClick={onClose}>
      <div className="glass-strong w-full max-w-lg p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg">{title}</h3>
          <button onClick={onClose} className="text-muted hover:text-white text-xl leading-none">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}
