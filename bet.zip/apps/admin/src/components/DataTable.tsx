import { useMemo, useState, type ReactNode } from 'react';
import { GlassCard, EmptyState } from './ui';
import { IconSearch } from './Icons';

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  className?: string;
}

export function DataTable<T extends { id: string }>({
  rows, columns, searchKeys, filters, actions, pageSize = 12, emptyTitle = 'No records',
}: {
  rows: T[];
  columns: Column<T>[];
  searchKeys?: (row: T) => string;
  filters?: { label: string; options: string[]; get: (row: T) => string }[];
  actions?: (row: T) => ReactNode;
  pageSize?: number;
  emptyTitle?: string;
}) {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>({});

  const filtered = useMemo(() => {
    let out = rows;
    if (q && searchKeys) {
      const needle = q.toLowerCase();
      out = out.filter((r) => searchKeys(r).toLowerCase().includes(needle));
    }
    for (const [label, val] of Object.entries(activeFilters)) {
      if (!val || val === 'All') continue;
      const f = filters?.find((x) => x.label === label);
      if (f) out = out.filter((r) => f.get(r) === val);
    }
    return out;
  }, [rows, q, activeFilters, searchKeys, filters]);

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, pages);
  const slice = filtered.slice((current - 1) * pageSize, current * pageSize);

  return (
    <GlassCard className="overflow-hidden">
      <div className="p-4 flex flex-wrap items-center gap-3 border-b border-white/5">
        {searchKeys && (
          <div className="relative flex-1 min-w-[200px]">
            <IconSearch width={16} height={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); setPage(1); }}
              placeholder="Search…"
              className="w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-sm outline-none focus:border-electric/50"
            />
          </div>
        )}
        {filters?.map((f) => (
          <select
            key={f.label}
            value={activeFilters[f.label] ?? 'All'}
            onChange={(e) => { setActiveFilters((s) => ({ ...s, [f.label]: e.target.value })); setPage(1); }}
            className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-electric/50"
          >
            <option value="All">All {f.label}</option>
            {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        ))}
        <span className="text-xs text-muted ml-auto">{filtered.length} records</span>
      </div>

      {slice.length === 0 ? (
        <EmptyState title={emptyTitle} hint="Try adjusting your search or filters." />
      ) : (
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                {columns.map((c) => <th key={c.key} className={c.className}>{c.header}</th>)}
                {actions && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {slice.map((row) => (
                <tr key={row.id}>
                  {columns.map((c) => <td key={c.key} className={c.className}>{c.render(row)}</td>)}
                  {actions && <td>{actions(row)}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <div className="flex items-center justify-between p-4 border-t border-white/5">
          <button disabled={current === 1} onClick={() => setPage(current - 1)} className="px-3 py-1.5 rounded-lg text-sm bg-white/5 disabled:opacity-40">Prev</button>
          <span className="text-xs text-muted">Page {current} of {pages}</span>
          <button disabled={current === pages} onClick={() => setPage(current + 1)} className="px-3 py-1.5 rounded-lg text-sm bg-white/5 disabled:opacity-40">Next</button>
        </div>
      )}
    </GlassCard>
  );
}
