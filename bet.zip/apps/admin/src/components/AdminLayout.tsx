import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CURRENT_ADMIN } from '../lib/adminData';
import {
  IconDashboard, IconUsers, IconWallet, IconDeposit, IconWithdraw, IconAgent,
  IconBet, IconGame, IconPromo, IconSupport, IconSettings, IconAudit, IconTrophy, IconBell, IconShield,
} from './Icons';

const NAV = [
  { to: '/', label: 'Dashboard', icon: IconDashboard, end: true },
  { to: '/users', label: 'Users', icon: IconUsers },
  { to: '/wallet', label: 'Wallet', icon: IconWallet },
  { to: '/deposits', label: 'Deposits', icon: IconDeposit },
  { to: '/withdrawals', label: 'Withdrawals', icon: IconWithdraw },
  { to: '/agents', label: 'Agents', icon: IconAgent },
  { to: '/bets', label: 'Bets', icon: IconBet },
  { to: '/sportsbook', label: 'Sportsbook', icon: IconTrophy },
  { to: '/games', label: 'Games', icon: IconGame },
  { to: '/promotions', label: 'Promotions', icon: IconPromo },
  { to: '/leaderboard', label: 'Leaderboard', icon: IconTrophy },
  { to: '/notifications', label: 'Notifications', icon: IconBell },
  { to: '/support', label: 'Support', icon: IconSupport },
  { to: '/settings', label: 'Settings', icon: IconSettings },
  { to: '/audit', label: 'Audit Logs', icon: IconAudit },
];

export function Logo({ size = 34 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className="grid place-items-center rounded-xl font-black"
        style={{ width: size, height: size, background: 'linear-gradient(135deg,#2196FF,#8B5CF6)', fontSize: size * 0.5 }}
      >
        P
      </div>
      <div className="leading-none">
        <div className="font-extrabold tracking-tight text-[15px]">TemP</div>
        <div className="text-[10px] text-muted font-semibold tracking-wider">ADMIN</div>
      </div>
    </div>
  );
}

export default function AdminLayout() {
  const loc = useLocation();
  const current = NAV.find((n) => (n.end ? loc.pathname === n.to : loc.pathname.startsWith(n.to)));

  return (
    <div className="min-h-screen flex">
      <div className="app-bg" />
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-white/5 p-4 sticky top-0 h-screen">
        <div className="px-2 py-3">
          <Logo />
        </div>
        <nav className="mt-4 flex-1 overflow-y-auto no-scrollbar space-y-1">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                  isActive ? 'bg-white/10 text-white' : 'text-muted hover:text-white hover:bg-white/5'
                }`
              }
            >
              <item.icon width={18} height={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="glass p-3 mt-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full grid place-items-center bg-gradient-to-br from-electric to-purple font-bold text-sm">
              {CURRENT_ADMIN.name[0]}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-semibold truncate">{CURRENT_ADMIN.name}</div>
              <div className="text-[10px] text-muted truncate">{CURRENT_ADMIN.role.replace(/_/g, ' ')}</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 glass-nav border-b border-white/5 px-4 lg:px-8 py-3 flex items-center justify-between">
          <div className="lg:hidden"><Logo size={30} /></div>
          <div className="hidden lg:block">
            <h1 className="text-lg font-bold">{current?.label ?? 'Dashboard'}</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline-flex items-center gap-1.5 text-[11px] font-semibold text-gold bg-gold/10 px-2.5 py-1 rounded-full">
              <IconShield width={12} height={12} /> PROTOTYPE · MOCK DATA
            </span>
            <div className="w-9 h-9 rounded-full grid place-items-center bg-gradient-to-br from-electric to-purple font-bold text-sm">
              {CURRENT_ADMIN.name[0]}
            </div>
          </div>
        </header>

        {/* Mobile nav */}
        <div className="lg:hidden overflow-x-auto no-scrollbar px-4 py-2 border-b border-white/5">
          <div className="flex gap-2">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold ${isActive ? 'bg-electric text-white' : 'bg-white/5 text-muted'}`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </div>
        </div>

        <motion.main
          key={loc.pathname}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
          className="flex-1 p-4 lg:p-8 max-w-[1400px] w-full mx-auto"
        >
          <Outlet />
        </motion.main>
      </div>
    </div>
  );
}
