import { Routes, Route } from 'react-router-dom';
import AdminLayout from './components/AdminLayout';
import DashboardPage from './pages/DashboardPage';
import UsersPage from './pages/UsersPage';
import WalletPage from './pages/WalletPage';
import DepositsPage from './pages/DepositsPage';
import WithdrawalsPage from './pages/WithdrawalsPage';
import AgentsPage from './pages/AgentsPage';
import BetsPage from './pages/BetsPage';
import SportsbookPage from './pages/SportsbookPage';
import GamesPage from './pages/GamesPage';
import PromotionsPage from './pages/PromotionsPage';
import LeaderboardPage from './pages/LeaderboardPage';
import NotificationsPage from './pages/NotificationsPage';
import SupportPage from './pages/SupportPage';
import SettingsPage from './pages/SettingsPage';
import AuditPage from './pages/AuditPage';

export default function App() {
  return (
    <Routes>
      <Route element={<AdminLayout />}>
        <Route index element={<DashboardPage />} />
        <Route path="users" element={<UsersPage />} />
        <Route path="wallet" element={<WalletPage />} />
        <Route path="deposits" element={<DepositsPage />} />
        <Route path="withdrawals" element={<WithdrawalsPage />} />
        <Route path="agents" element={<AgentsPage />} />
        <Route path="bets" element={<BetsPage />} />
        <Route path="sportsbook" element={<SportsbookPage />} />
        <Route path="games" element={<GamesPage />} />
        <Route path="promotions" element={<PromotionsPage />} />
        <Route path="leaderboard" element={<LeaderboardPage />} />
        <Route path="notifications" element={<NotificationsPage />} />
        <Route path="support" element={<SupportPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="audit" element={<AuditPage />} />
      </Route>
    </Routes>
  );
}
