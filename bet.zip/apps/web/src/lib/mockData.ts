/**
 * Deterministic mock data for the TemP prototype.
 * All odds, balances and results are DEMO ONLY — never authoritative.
 */
import type {
  Game,
  Sport,
  Event,
  Promotion,
  LeaderboardEntry,
  AppNotification,
  WalletTransaction,
  Streak,
  Cashback,
} from '@temp/types';
import { seededRandom } from '@temp/utils';

const rng = seededRandom(20240907);

// ---------------------------------------------------------------------------
// GAMES — 40 launch + 10 coming soon
// ---------------------------------------------------------------------------
const GAME_DEFS: Array<[string, Game['category'], string, string, [string, string], Game['badge']]> = [
  // Sports (1-10)
  ['Football', 'Sports', '⚽', 'Sportsbook', ['#0ea5e9', '#1e3a8a'], 'HOT'],
  ['Basketball', 'Sports', '🏀', 'Sportsbook', ['#f97316', '#7c2d12'], null],
  ['Tennis', 'Sports', '🎾', 'Sportsbook', ['#84cc16', '#14532d'], null],
  ['Volleyball', 'Sports', '🏐', 'Sportsbook', ['#facc15', '#78350f'], null],
  ['Baseball', 'Sports', '⚾', 'Sportsbook', ['#ef4444', '#7f1d1d'], null],
  ['Ice Hockey', 'Sports', '🏒', 'Sportsbook', ['#38bdf8', '#0c4a6e'], null],
  ['Handball', 'Sports', '🤾', 'Sportsbook', ['#a855f7', '#4c1d95'], null],
  ['Rugby', 'Sports', '🏉', 'Sportsbook', ['#22c55e', '#14532d'], null],
  ['Boxing', 'Sports', '🥊', 'Sportsbook', ['#f43f5e', '#881337'], 'LIVE'],
  ['Esports', 'Sports', '🎮', 'Sportsbook', ['#8b5cf6', '#312e81'], 'NEW'],
  // Casino / Instant (11-20)
  ['Roulette', 'Table Games', '🎡', 'TemP Originals', ['#ef4444', '#7f1d1d'], 'TOP'],
  ['Blackjack', 'Table Games', '🃏', 'TemP Originals', ['#22c55e', '#14532d'], null],
  ['Baccarat', 'Table Games', '🎴', 'TemP Originals', ['#f5c518', '#78350f'], null],
  ['Dice', 'Casino', '🎲', 'TemP Originals', ['#2196ff', '#1e3a8a'], null],
  ['Keno', 'Lottery', '🔢', 'TemP Originals', ['#22d3ee', '#0e7490'], null],
  ['Mines', 'Casino', '💎', 'TemP Originals', ['#8b5cf6', '#4c1d95'], 'HOT'],
  ['Plinko', 'Crash', '🔻', 'TemP Originals', ['#f472b6', '#831843'], null],
  ['Crash', 'Crash', '🚀', 'TemP Originals', ['#f97316', '#7c2d12'], 'HOT'],
  ['Wheel', 'Casino', '🎯', 'TemP Originals', ['#facc15', '#78350f'], null],
  ['Sic Bo', 'Table Games', '🎰', 'TemP Originals', ['#ef4444', '#7f1d1d'], null],
  // Slots (21-30)
  ['Golden Fortune', 'Slots', '🪙', 'TemP Slots', ['#f5c518', '#b45309'], 'TOP'],
  ['Royal Gems', 'Slots', '💠', 'TemP Slots', ['#8b5cf6', '#4c1d95'], null],
  ['Lucky Pharaoh', 'Slots', '🏺', 'TemP Slots', ['#f59e0b', '#78350f'], null],
  ['Dragon Treasure', 'Slots', '🐉', 'TemP Slots', ['#ef4444', '#7f1d1d'], 'HOT'],
  ['Ocean Riches', 'Slots', '🐚', 'TemP Slots', ['#22d3ee', '#0e7490'], null],
  ['Mystic Fruits', 'Slots', '🍒', 'TemP Slots', ['#f43f5e', '#881337'], null],
  ['Diamond Vault', 'Slots', '💎', 'TemP Slots', ['#38bdf8', '#0c4a6e'], null],
  ['Fire Coins', 'Slots', '🔥', 'TemP Slots', ['#f97316', '#7c2d12'], null],
  ['Golden Chicken', 'Slots', '🐔', 'TemP Slots', ['#facc15', '#78350f'], 'NEW'],
  ['Star Fortune', 'Slots', '⭐', 'TemP Slots', ['#a855f7', '#4c1d95'], null],
  // Virtual / Instant (31-40)
  ['Virtual Horse Racing', 'Live', '🐎', 'TemP Virtuals', ['#22c55e', '#14532d'], null],
  ['Virtual Greyhound Racing', 'Live', '🐕', 'TemP Virtuals', ['#84cc16', '#14532d'], null],
  ['Virtual Football', 'Live', '⚽', 'TemP Virtuals', ['#0ea5e9', '#1e3a8a'], null],
  ['Virtual Basketball', 'Live', '🏀', 'TemP Virtuals', ['#f97316', '#7c2d12'], null],
  ['Penalty Shootout', 'Sports', '🥅', 'TemP Virtuals', ['#22d3ee', '#0e7490'], null],
  ['Lucky Numbers', 'Lottery', '🍀', 'TemP Virtuals', ['#22c55e', '#14532d'], null],
  ['Tower', 'Crash', '🗼', 'TemP Originals', ['#8b5cf6', '#312e81'], null],
  ['Coin Flip', 'Casino', '🪙', 'TemP Originals', ['#f5c518', '#78350f'], null],
  ['Hi-Lo', 'Casino', '📈', 'TemP Originals', ['#2196ff', '#1e3a8a'], null],
  ['Jackpot', 'Popular', '🎉', 'TemP Originals', ['#f43f5e', '#881337'], 'HOT'],
];

export const GAMES: Game[] = GAME_DEFS.map(([title, category, emoji, provider, gradient, badge], i) => ({
  id: `game_${i + 1}`,
  slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
  title,
  category,
  provider,
  badge,
  coming_soon: false,
  gradient,
  emoji,
  rtp: 92 + Math.round(rng() * 6),
}));

export const COMING_SOON_GAMES: Game[] = Array.from({ length: 10 }).map((_, i) => ({
  id: `game_${41 + i}`,
  slug: `coming-soon-${i + 1}`,
  title: `Coming Soon`,
  category: 'New' as Game['category'],
  provider: 'TemP',
  badge: 'NEW' as const,
  coming_soon: true,
  gradient: ['#1e293b', '#0f172a'] as [string, string],
  emoji: '🔒',
}));

export const ALL_GAMES = [...GAMES, ...COMING_SOON_GAMES];

export const GAME_CATEGORIES: Game['category'][] = [
  'Sports',
  'Live',
  'Casino',
  'Crash',
  'Slots',
  'Table Games',
  'Lottery',
  'Popular',
  'New',
];

// ---------------------------------------------------------------------------
// SPORTSBOOK
// ---------------------------------------------------------------------------
export const SPORTS: Sport[] = [
  { id: 's1', key: 'football', name: 'Football', icon: '⚽', event_count: 24 },
  { id: 's2', key: 'basketball', name: 'Basketball', icon: '🏀', event_count: 14 },
  { id: 's3', key: 'tennis', name: 'Tennis', icon: '🎾', event_count: 11 },
  { id: 's4', key: 'volleyball', name: 'Volleyball', icon: '🏐', event_count: 6 },
  { id: 's5', key: 'esports', name: 'Esports', icon: '🎮', event_count: 9 },
  { id: 's6', key: 'horse', name: 'Horse Racing', icon: '🐎', event_count: 8 },
];

const TEAMS: Record<string, string[]> = {
  football: ['Manchester United', 'Arsenal', 'Chelsea', 'Liverpool', 'Manchester City', 'Tottenham', 'Real Madrid', 'Barcelona', 'Juventus', 'Inter Milan', 'Saint George SC', 'Fasil Kenema'],
  basketball: ['Lakers', 'Celtics', 'Warriors', 'Bulls', 'Heat', 'Nuggets', 'Bucks', 'Suns'],
  tennis: ['Djokovic', 'Alcaraz', 'Sinner', 'Medvedev', 'Zverev', 'Rune'],
  volleyball: ['Italy', 'Brazil', 'Poland', 'France', 'Japan', 'USA'],
  esports: ['NAVI', 'FaZe', 'G2', 'Vitality', 'Team Spirit', 'Astralis'],
  horse: ['Thunder Bolt', 'Silver Arrow', 'Desert King', 'Night Fury', 'Golden Hoof', 'Storm Chaser'],
};

const LEAGUES: Record<string, string[]> = {
  football: ['Premier League', 'La Liga', 'Serie A', 'Ethiopian Premier League'],
  basketball: ['NBA', 'EuroLeague'],
  tennis: ['ATP Masters', 'Grand Slam'],
  volleyball: ['Nations League'],
  esports: ['CS2 Major', 'LoL Worlds'],
  horse: ['Addis Derby'],
};

function makeMarkets(eventId: string, isLive: boolean) {
  const base = 1.4 + rng() * 2.6;
  const draw = 2.8 + rng() * 1.6;
  const away = 1.6 + rng() * 3.2;
  return [
    {
      id: `${eventId}_m1`,
      event_id: eventId,
      name: 'Match Result',
      selections: [
        { id: `${eventId}_s1`, market_id: `${eventId}_m1`, name: 'Home', odds: round2(base), active: true },
        { id: `${eventId}_s2`, market_id: `${eventId}_m1`, name: 'Draw', odds: round2(draw), active: true },
        { id: `${eventId}_s3`, market_id: `${eventId}_m1`, name: 'Away', odds: round2(away), active: true },
      ],
    },
    {
      id: `${eventId}_m2`,
      event_id: eventId,
      name: 'Over / Under 2.5',
      selections: [
        { id: `${eventId}_s4`, market_id: `${eventId}_m2`, name: 'Over 2.5', odds: round2(1.7 + rng()), active: true },
        { id: `${eventId}_s5`, market_id: `${eventId}_m2`, name: 'Under 2.5', odds: round2(1.7 + rng()), active: true },
      ],
    },
    {
      id: `${eventId}_m3`,
      event_id: eventId,
      name: 'Both Teams To Score',
      selections: [
        { id: `${eventId}_s6`, market_id: `${eventId}_m3`, name: 'Yes', odds: round2(1.6 + rng() * 0.6), active: true },
        { id: `${eventId}_s7`, market_id: `${eventId}_m3`, name: 'No', odds: round2(1.8 + rng() * 0.6), active: true },
      ],
    },
  ];
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

function buildEvents(): Event[] {
  const events: Event[] = [];
  let idx = 0;
  for (const sport of SPORTS) {
    const teams = TEAMS[sport.key];
    const leagues = LEAGUES[sport.key];
    const count = sport.key === 'football' ? 8 : 4;
    for (let i = 0; i < count; i++) {
      idx++;
      const id = `evt_${idx}`;
      const home = teams[(i * 2) % teams.length];
      let away = teams[(i * 2 + 1) % teams.length];
      if (away === home) away = teams[(i * 2 + 2) % teams.length];
      const isLive = i % 3 === 0;
      const start = new Date(Date.now() + (isLive ? -1 : 1) * (i + 1) * 3600 * 1000);
      events.push({
        id,
        sport_id: sport.id,
        league_id: `lg_${sport.key}_${i % leagues.length}`,
        league_name: leagues[i % leagues.length],
        home,
        away,
        start_time: start.toISOString(),
        is_live: isLive,
        live_score: isLive
          ? { home: Math.floor(rng() * 4), away: Math.floor(rng() * 4), minute: 10 + Math.floor(rng() * 80) }
          : null,
        markets: makeMarkets(id, isLive),
      });
    }
  }
  return events;
}

export const EVENTS: Event[] = buildEvents();

// ---------------------------------------------------------------------------
// PROMOTIONS
// ---------------------------------------------------------------------------
export const PROMOTIONS: Promotion[] = [
  { id: 'p1', title: 'Welcome Bonus', description: 'Get a 100% bonus on your first deposit up to 5,000 ETB.', category: 'welcome', badge: 'NEW PLAYERS', cta: 'Claim', gradient: ['#2196FF', '#8B5CF6'], active: true },
  { id: 'p2', title: 'Daily Free Bet', description: 'Place any bet today and receive a 50 ETB free bet.', category: 'freebet', badge: 'DAILY', cta: 'Get Free Bet', gradient: ['#22C55E', '#16A34A'], active: true },
  { id: 'p3', title: 'Deposit Bonus', description: 'Deposit 1,000 ETB and get 200 ETB bonus instantly.', category: 'deposit', badge: 'HOT', cta: 'Deposit', gradient: ['#F5C518', '#FF8A00'], active: true },
  { id: 'p4', title: 'Weekly Tournament', description: 'Compete for a 50,000 ETB prize pool every week.', category: 'tournament', badge: 'PRIZE POOL', cta: 'Join', gradient: ['#8B5CF6', '#4C1D95'], active: true },
  { id: 'p5', title: 'Daily Missions', description: 'Complete missions to earn points and rewards.', category: 'mission', badge: 'MISSIONS', cta: 'View', gradient: ['#22D3EE', '#0E7490'], active: true },
  { id: 'p6', title: 'Loyalty Rewards', description: 'Earn rewards every time you play. Level up for more.', category: 'reward', badge: 'REWARDS', cta: 'Explore', gradient: ['#F43F5E', '#881337'], active: true },
];

export const PROMO_CODES: Record<string, { reward: number; state: 'success' | 'expired' | 'already_used' | 'not_eligible' }> = {
  TEMP100: { reward: 100, state: 'success' },
  WELCOME: { reward: 250, state: 'success' },
  EXPIRED: { reward: 0, state: 'expired' },
  USED: { reward: 0, state: 'already_used' },
  VIPONLY: { reward: 0, state: 'not_eligible' },
};

// ---------------------------------------------------------------------------
// LEADERBOARD
// ---------------------------------------------------------------------------
const LB_NAMES = ['Dawit', 'Selam', 'Yonas', 'Hanna', 'Bekele', 'Marta', 'Tesfaye', 'Liya', 'Kalkidan', 'Nahom', 'Sara', 'Abel', 'Meron', 'Robel', 'Eden'];

export function buildLeaderboard(period: 'weekly' | 'monthly' | 'all'): LeaderboardEntry[] {
  const r = seededRandom(period === 'weekly' ? 11 : period === 'monthly' ? 22 : 33);
  return LB_NAMES.map((name, i) => ({
    rank: i + 1,
    user_id: `u_${i}`,
    username: name,
    avatar_url: null,
    points: Math.floor(5000 - i * 280 + r() * 200),
    winnings: Math.floor(120000 - i * 6500 + r() * 4000),
    is_current_user: name === 'Abebe' || i === 4,
  })).sort((a, b) => b.points - a.points).map((e, i) => ({ ...e, rank: i + 1 }));
}

// ---------------------------------------------------------------------------
// NOTIFICATIONS
// ---------------------------------------------------------------------------
export const NOTIFICATIONS: AppNotification[] = [
  { id: 'n1', type: 'deposit', title: 'Deposit Approved', body: 'Your deposit of 500 ETB has been approved.', read: false, created_at: new Date(Date.now() - 3600e3).toISOString() },
  { id: 'n2', type: 'bet_result', title: 'Bet Won 🎉', body: 'Your accumulator won 1,240 ETB.', read: false, created_at: new Date(Date.now() - 7200e3).toISOString() },
  { id: 'n3', type: 'promotion', title: 'New Promotion', body: 'Weekly tournament with 50,000 ETB prize pool is live.', read: false, created_at: new Date(Date.now() - 86400e3).toISOString() },
  { id: 'n4', type: 'cashback', title: 'Cashback Ready', body: 'You have 45 ETB cashback available to claim.', read: true, created_at: new Date(Date.now() - 2 * 86400e3).toISOString() },
  { id: 'n5', type: 'streak', title: 'Streak Milestone', body: 'You reached a 5-day streak! Keep going.', read: true, created_at: new Date(Date.now() - 3 * 86400e3).toISOString() },
  { id: 'n6', type: 'system', title: 'Welcome to TemP', body: 'Your account is ready. Explore games and promotions.', read: true, created_at: new Date(Date.now() - 5 * 86400e3).toISOString() },
];

// ---------------------------------------------------------------------------
// WALLET LEDGER (demo)
// ---------------------------------------------------------------------------
export const LEDGER: WalletTransaction[] = [
  { id: 't1', wallet_id: 'w1', user_id: 'u1', type: 'deposit', amount: 500, balance_after: 500, description: 'Agent deposit', created_at: new Date(Date.now() - 6 * 86400e3).toISOString() },
  { id: 't2', wallet_id: 'w1', user_id: 'u1', type: 'bet_stake', amount: -100, balance_after: 400, description: 'Bet on Man Utd vs Arsenal', created_at: new Date(Date.now() - 5 * 86400e3).toISOString() },
  { id: 't3', wallet_id: 'w1', user_id: 'u1', type: 'bet_win', amount: 180, balance_after: 580, description: 'Bet won', created_at: new Date(Date.now() - 5 * 86400e3 + 3600e3).toISOString() },
  { id: 't4', wallet_id: 'w1', user_id: 'u1', type: 'withdrawal', amount: -200, balance_after: 380, description: 'Withdrawal to Telebirr', created_at: new Date(Date.now() - 2 * 86400e3).toISOString() },
  { id: 't5', wallet_id: 'w1', user_id: 'u1', type: 'cashback', amount: 45, balance_after: 425, description: 'Daily cashback', created_at: new Date(Date.now() - 86400e3).toISOString() },
];

// ---------------------------------------------------------------------------
// STREAK & CASHBACK
// ---------------------------------------------------------------------------
export function buildStreak(): Streak {
  const days = ['7 Sep', '8 Sep', '9 Sep', '10 Sep', '11 Sep', '12 Sep', '13 Sep'];
  const current = 5;
  return {
    current,
    best: 12,
    next_reward: 150,
    days: days.map((label, i) => ({
      date: label,
      label,
      state: i < current ? 'completed' : i === current ? 'current' : 'locked',
      reward: [20, 30, 40, 60, 80, 120, 150][i],
    })),
  };
}

export function buildCashback(): Cashback {
  return {
    percentage: 5,
    accumulated: 45,
    claimable: true,
    next_claim_at: new Date(Date.now() + 21 * 3600e3 + 56 * 60e3 + 39e3).toISOString(),
    history: [
      { id: 'c1', amount: 45, claimed_at: new Date(Date.now() - 86400e3).toISOString() },
      { id: 'c2', amount: 32, claimed_at: new Date(Date.now() - 2 * 86400e3).toISOString() },
      { id: 'c3', amount: 28, claimed_at: new Date(Date.now() - 3 * 86400e3).toISOString() },
    ],
  };
}

// ---------------------------------------------------------------------------
// HERO BANNERS
// ---------------------------------------------------------------------------
export const BANNERS = [
  { id: 'b1', title: 'Welcome to TemP', subtitle: 'Play. Win. Repeat.', badge: 'NEW', cta: 'Get Started', gradient: ['#2196FF', '#8B5CF6'] },
  { id: 'b2', title: '100% Deposit Bonus', subtitle: 'Up to 5,000 ETB on your first deposit', badge: 'BONUS', cta: 'Deposit Now', gradient: ['#F5C518', '#FF8A00'] },
  { id: 'b3', title: 'Weekly Tournament', subtitle: 'Compete for 50,000 ETB prize pool', badge: 'LIVE', cta: 'Join Now', gradient: ['#22C55E', '#0E7490'] },
  { id: 'b4', title: 'Crash & Win Big', subtitle: 'Cash out before the rocket crashes', badge: 'HOT', cta: 'Play Crash', gradient: ['#F43F5E', '#7C2D12'] },
];
