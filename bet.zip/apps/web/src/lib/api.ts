/**
 * Mock API client for the TemP prototype.
 *
 * In production this file is replaced by real HTTP calls to the NestJS API
 * (see apps/api). The interface is intentionally identical so the frontend
 * does not need to be rewritten when switching to the live backend.
 *
 * IMPORTANT: All financial values returned here are DEMO ONLY. The client
 * never treats them as authoritative — the real backend owns the ledger.
 */
import type {
  User,
  Wallet,
  WalletTransaction,
  Deposit,
  Withdrawal,
  Bet,
  BetSelection,
  Game,
  Event,
  Promotion,
  LeaderboardEntry,
  AppNotification,
  Streak,
  Cashback,
  SupportTicket,
} from '@temp/types';
import { calcAccumulatorOdds, calcPotentialWin, uid } from '@temp/utils';
import {
  ALL_GAMES,
  EVENTS,
  PROMOTIONS,
  buildLeaderboard,
  NOTIFICATIONS,
  LEDGER,
  buildStreak,
  buildCashback,
  PROMO_CODES,
} from './mockData';
import { getTelegramUser, getInitData, isTelegramEnvironment } from './telegram';

const LATENCY = 320;
const delay = (ms = LATENCY) => new Promise((r) => setTimeout(r, ms));

// In-memory demo state (resets on reload)
const state = {
  user: null as User | null,
  wallet: {
    id: 'w1',
    user_id: 'u1',
    balance: 425,
    bonus_balance: 120,
    pending_balance: 0,
    currency: 'ETB' as const,
    updated_at: new Date().toISOString(),
  } as Wallet,
  ledger: [...LEDGER],
  deposits: [] as Deposit[],
  withdrawals: [] as Withdrawal[],
  bets: [] as Bet[],
  notifications: [...NOTIFICATIONS],
  tickets: [] as SupportTicket[],
  redeemedCodes: new Set<string>(),
  streak: buildStreak(),
  cashback: buildCashback(),
};

function recomputeBalance() {
  const last = state.ledger[state.ledger.length - 1];
  state.wallet.balance = last ? last.balance_after : 0;
  state.wallet.updated_at = new Date().toISOString();
}

function pushTx(type: WalletTransaction['type'], amount: number, description: string, idempotencyKey?: string) {
  if (idempotencyKey) {
    const existing = state.ledger.find((t) => t.idempotency_key === idempotencyKey);
    if (existing) return existing; // idempotent
  }
  const balance_after = Math.round((state.wallet.balance + amount) * 100) / 100;
  const tx: WalletTransaction = {
    id: uid('tx'),
    wallet_id: state.wallet.id,
    user_id: state.user?.id ?? 'u1',
    type,
    amount,
    balance_after,
    description,
    idempotency_key: idempotencyKey ?? null,
    created_at: new Date().toISOString(),
  };
  state.ledger.push(tx);
  recomputeBalance();
  return tx;
}

export const api = {
  // --- AUTH ---------------------------------------------------------------
  async authTelegram(): Promise<{ user: User; token: string; isTelegram: boolean }> {
    await delay();
    const tg = getTelegramUser();
    const isTelegram = isTelegramEnvironment();
    const user: User = {
      id: 'u1',
      telegram_id: String(tg.id),
      telegram_username: tg.username ?? null,
      first_name: tg.first_name,
      last_name: tg.last_name ?? null,
      phone: null,
      avatar_url: tg.photo_url ?? null,
      status: 'active',
      language: tg.language_code ?? 'en',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.user = user;
    // In production: POST /auth/telegram with initData; server verifies HMAC.
    return { user, token: 'demo.jwt.token', isTelegram };
  },

  async me(): Promise<User> {
    await delay(120);
    if (!state.user) throw new Error('Not authenticated');
    return state.user;
  },

  async updateMe(patch: Partial<User>): Promise<User> {
    await delay();
    if (!state.user) throw new Error('Not authenticated');
    state.user = { ...state.user, ...patch, updated_at: new Date().toISOString() };
    return state.user;
  },

  // --- WALLET -------------------------------------------------------------
  async getWallet(): Promise<Wallet> {
    await delay(200);
    return { ...state.wallet };
  },

  async getTransactions(): Promise<WalletTransaction[]> {
    await delay(240);
    return [...state.ledger].reverse();
  },

  // --- DEPOSITS -----------------------------------------------------------
  async createDeposit(amount: number, method: string): Promise<Deposit> {
    await delay();
    const deposit: Deposit = {
      id: uid('dep'),
      user_id: state.user?.id ?? 'u1',
      agent_id: 'agent_1',
      amount,
      method,
      state: 'PENDING',
      reference: uid('ref').toUpperCase(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.deposits.unshift(deposit);
    // Simulate agent confirmation + approval after a short delay
    setTimeout(() => {
      deposit.state = 'AGENT_CONFIRMED';
      setTimeout(() => {
        deposit.state = 'APPROVED';
        pushTx('deposit', amount, `Deposit via ${method}`, `dep_${deposit.id}`);
      }, 2500);
    }, 1500);
    return deposit;
  },

  async getDeposits(): Promise<Deposit[]> {
    await delay(200);
    return [...state.deposits];
  },

  // --- WITHDRAWALS --------------------------------------------------------
  async createWithdrawal(amount: number, method: string, account: string): Promise<Withdrawal> {
    await delay();
    if (amount > state.wallet.balance) throw new Error('Insufficient balance');
    const w: Withdrawal = {
      id: uid('wd'),
      user_id: state.user?.id ?? 'u1',
      amount,
      method,
      account,
      state: 'REQUESTED',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.withdrawals.unshift(w);
    pushTx('withdrawal', -amount, `Withdrawal to ${method}`, `wd_${w.id}`);
    setTimeout(() => (w.state = 'UNDER_REVIEW'), 1500);
    setTimeout(() => (w.state = 'APPROVED'), 3500);
    setTimeout(() => (w.state = 'PROCESSING'), 5000);
    setTimeout(() => (w.state = 'COMPLETED'), 7000);
    return w;
  },

  async getWithdrawals(): Promise<Withdrawal[]> {
    await delay(200);
    return [...state.withdrawals];
  },

  // --- SPORTSBOOK ---------------------------------------------------------
  async getEvents(filter?: { sport?: string; live?: boolean }): Promise<Event[]> {
    await delay(260);
    let list = [...EVENTS];
    if (filter?.sport) list = list.filter((e) => e.sport_id === filter.sport);
    if (filter?.live) list = list.filter((e) => e.is_live);
    return list;
  },

  async getEvent(id: string): Promise<Event | undefined> {
    await delay(180);
    return EVENTS.find((e) => e.id === id);
  },

  // --- BETS ---------------------------------------------------------------
  async placeBet(selections: BetSelection[], stake: number, type: 'single' | 'accumulator'): Promise<Bet> {
    await delay(420);
    if (stake <= 0) throw new Error('Stake must be greater than zero');
    if (stake > state.wallet.balance) throw new Error('Insufficient balance');
    if (selections.length === 0) throw new Error('No selections');
    const total_odds = type === 'accumulator' ? calcAccumulatorOdds(selections.map((s) => s.odds)) : selections[0].odds;
    const potential_win = calcPotentialWin(stake, total_odds);
    const bet: Bet = {
      id: uid('bet'),
      user_id: state.user?.id ?? 'u1',
      type,
      stake,
      total_odds: Math.round(total_odds * 100) / 100,
      potential_win,
      state: 'pending',
      payout: null,
      selections,
      created_at: new Date().toISOString(),
    };
    state.bets.unshift(bet);
    pushTx('bet_stake', -stake, `Bet ${bet.id}`, `bet_${bet.id}`);
    // Simulate settlement after a delay (demo)
    setTimeout(() => {
      const won = Math.random() > 0.45;
      bet.state = won ? 'won' : 'lost';
      if (won) {
        bet.payout = potential_win;
        pushTx('bet_win', potential_win, `Bet ${bet.id} won`, `win_${bet.id}`);
      }
    }, 6000);
    return bet;
  },

  async getBets(): Promise<Bet[]> {
    await delay(200);
    return [...state.bets];
  },

  // --- GAMES --------------------------------------------------------------
  async getGames(): Promise<Game[]> {
    await delay(220);
    return [...ALL_GAMES];
  },

  // --- PROMOTIONS ---------------------------------------------------------
  async getPromotions(): Promise<Promotion[]> {
    await delay(200);
    return [...PROMOTIONS];
  },

  async redeemPromoCode(code: string): Promise<{ state: string; reward: number; message: string }> {
    await delay(500);
    const key = code.trim().toUpperCase();
    if (state.redeemedCodes.has(key)) {
      return { state: 'already_used', reward: 0, message: 'This code has already been used.' };
    }
    const entry = PROMO_CODES[key];
    if (!entry) return { state: 'invalid', reward: 0, message: 'Invalid promo code.' };
    if (entry.state !== 'success') {
      const messages: Record<string, string> = {
        expired: 'This promo code has expired.',
        already_used: 'This code has already been used.',
        not_eligible: 'You are not eligible for this promo code.',
      };
      return { state: entry.state, reward: 0, message: messages[entry.state] };
    }
    state.redeemedCodes.add(key);
    pushTx('promo_credit', entry.reward, `Promo code ${key}`, `promo_${key}`);
    return { state: 'success', reward: entry.reward, message: `Success! ${entry.reward} ETB credited.` };
  },

  // --- CASHBACK -----------------------------------------------------------
  async getCashback(): Promise<Cashback> {
    await delay(180);
    return { ...state.cashback };
  },

  async claimCashback(): Promise<{ amount: number }> {
    await delay(500);
    if (!state.cashback.claimable) throw new Error('Cashback not claimable yet');
    const amount = state.cashback.accumulated;
    pushTx('cashback', amount, 'Daily cashback claim', `cb_${Date.now()}`);
    state.cashback.history.unshift({ id: uid('cb'), amount, claimed_at: new Date().toISOString() });
    state.cashback.accumulated = 0;
    state.cashback.claimable = false;
    state.cashback.next_claim_at = new Date(Date.now() + 24 * 3600e3).toISOString();
    return { amount };
  },

  // --- STREAK -------------------------------------------------------------
  async getStreak(): Promise<Streak> {
    await delay(180);
    return { ...state.streak };
  },

  async claimStreak(): Promise<{ reward: number }> {
    await delay(400);
    const reward = state.streak.next_reward;
    pushTx('streak_reward', reward, 'Daily streak reward', `streak_${Date.now()}`);
    return { reward };
  },

  // --- LEADERBOARD --------------------------------------------------------
  async getLeaderboard(period: 'weekly' | 'monthly' | 'all'): Promise<LeaderboardEntry[]> {
    await delay(240);
    return buildLeaderboard(period);
  },

  // --- NOTIFICATIONS ------------------------------------------------------
  async getNotifications(): Promise<AppNotification[]> {
    await delay(180);
    return [...state.notifications];
  },

  async markNotificationRead(id: string): Promise<void> {
    await delay(120);
    const n = state.notifications.find((x) => x.id === id);
    if (n) n.read = true;
  },

  async markAllRead(): Promise<void> {
    await delay(150);
    state.notifications.forEach((n) => (n.read = true));
  },

  // --- SUPPORT ------------------------------------------------------------
  async createTicket(subject: string, category: string, message: string): Promise<SupportTicket> {
    await delay(500);
    const t: SupportTicket = {
      id: uid('tkt'),
      user_id: state.user?.id ?? 'u1',
      subject,
      category,
      message,
      state: 'open',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    state.tickets.unshift(t);
    return t;
  },

  async getTickets(): Promise<SupportTicket[]> {
    await delay(200);
    return [...state.tickets];
  },
};

export type Api = typeof api;
