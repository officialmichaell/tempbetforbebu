import { describe, it, expect } from 'vitest';
import { GAMES, COMING_SOON_GAMES, ALL_GAMES, GAME_CATEGORIES, SPORTS, EVENTS, PROMOTIONS, buildLeaderboard, buildStreak, buildCashback } from './mockData';

describe('mock data integrity', () => {
  it('has exactly 40 launch games', () => {
    expect(GAMES.length).toBe(40);
  });

  it('has exactly 10 coming-soon games', () => {
    expect(COMING_SOON_GAMES.length).toBe(10);
    expect(COMING_SOON_GAMES.every((g) => g.coming_soon)).toBe(true);
  });

  it('has 50 total games', () => {
    expect(ALL_GAMES.length).toBe(50);
  });

  it('exposes all 9 required categories', () => {
    expect(GAME_CATEGORIES).toEqual([
      'Sports', 'Live', 'Casino', 'Crash', 'Slots', 'Table Games', 'Lottery', 'Popular', 'New',
    ]);
  });

  it('every game has a unique id and slug', () => {
    const ids = new Set(ALL_GAMES.map((g) => g.id));
    const slugs = new Set(ALL_GAMES.map((g) => g.slug));
    expect(ids.size).toBe(ALL_GAMES.length);
    expect(slugs.size).toBe(ALL_GAMES.length);
  });

  it('has 6 sports with events', () => {
    expect(SPORTS.length).toBe(6);
    expect(EVENTS.length).toBeGreaterThan(0);
  });

  it('every event has markets with Home/Draw/Away odds > 1', () => {
    for (const e of EVENTS) {
      expect(e.markets.length).toBeGreaterThan(0);
      const mr = e.markets[0];
      expect(mr.selections.length).toBe(3);
      for (const s of mr.selections) expect(s.odds).toBeGreaterThan(1);
    }
  });

  it('has 6 promotions', () => {
    expect(PROMOTIONS.length).toBe(6);
  });

  it('leaderboard is sorted by points descending', () => {
    const lb = buildLeaderboard('weekly');
    for (let i = 1; i < lb.length; i++) {
      expect(lb[i - 1].points).toBeGreaterThanOrEqual(lb[i].points);
    }
  });

  it('streak has 7 days with exactly one current', () => {
    const s = buildStreak();
    expect(s.days.length).toBe(7);
    expect(s.days.filter((d) => d.state === 'current').length).toBe(1);
  });

  it('cashback is claimable with history', () => {
    const c = buildCashback();
    expect(c.claimable).toBe(true);
    expect(c.history.length).toBeGreaterThan(0);
  });
});
