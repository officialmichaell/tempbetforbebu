import { describe, it, expect } from 'vitest';
import {
  formatETB, formatSignedETB, formatOdds, calcAccumulatorOdds,
  calcPotentialWin, seededRandom, clamp, countdownParts,
} from '@temp/utils';

describe('formatETB', () => {
  it('formats with the ETB currency', () => {
    expect(formatETB(1500)).toContain('1,500');
  });
  it('supports compact notation', () => {
    expect(formatETB(1500000, { compact: true })).toMatch(/M|K/);
  });
});

describe('formatSignedETB', () => {
  it('prefixes credits with +', () => {
    expect(formatSignedETB(100)).toMatch(/^\+/);
  });
  it('keeps the minus for debits', () => {
    expect(formatSignedETB(-100)).toMatch(/^-/);
  });
});

describe('formatOdds', () => {
  it('renders two decimals', () => {
    expect(formatOdds(2)).toBe('2.00');
    expect(formatOdds(1.5)).toBe('1.50');
  });
});

describe('calcAccumulatorOdds', () => {
  it('multiplies odds and rounds to 2dp', () => {
    expect(calcAccumulatorOdds([2, 1.5])).toBe(3);
    expect(calcAccumulatorOdds([1.33, 1.33])).toBeCloseTo(1.77, 2);
  });
  it('returns 0 for an empty list', () => {
    expect(calcAccumulatorOdds([])).toBe(0);
  });
});

describe('calcPotentialWin', () => {
  it('multiplies stake by odds', () => {
    expect(calcPotentialWin(100, 2.5)).toBe(250);
  });
});

describe('seededRandom', () => {
  it('is deterministic for the same seed', () => {
    const a = seededRandom(42);
    const b = seededRandom(42);
    expect(a()).toBe(b());
    expect(a()).toBe(b());
  });
  it('produces values in [0,1)', () => {
    const r = seededRandom(7);
    for (let i = 0; i < 100; i++) {
      const v = r();
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThan(1);
    }
  });
});

describe('clamp', () => {
  it('clamps within bounds', () => {
    expect(clamp(5, 0, 10)).toBe(5);
    expect(clamp(-1, 0, 10)).toBe(0);
    expect(clamp(99, 0, 10)).toBe(10);
  });
});

describe('countdownParts', () => {
  it('returns zero-padded h/m/s', () => {
    const parts = countdownParts(Date.now() + 3661 * 1000);
    expect(parts.h).toMatch(/^\d{2}$/);
    expect(parts.m).toMatch(/^\d{2}$/);
    expect(parts.s).toMatch(/^\d{2}$/);
  });
});
