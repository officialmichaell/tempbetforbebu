/**
 * Telegram Mini App SDK wrapper.
 * Falls back to a deterministic mock user when running outside Telegram
 * (e.g. local browser development) so the app is always testable.
 */

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
  is_premium?: boolean;
}

interface TelegramWebApp {
  initData: string;
  initDataUnsafe: { user?: TelegramUser; start_param?: string };
  colorScheme: 'light' | 'dark';
  themeParams: Record<string, string>;
  isExpanded: boolean;
  viewportHeight: number;
  viewportStableHeight: number;
  ready: () => void;
  expand: () => void;
  close: () => void;
  setHeaderColor: (c: string) => void;
  setBackgroundColor: (c: string) => void;
  enableClosingConfirmation: () => void;
  HapticFeedback?: {
    impactOccurred: (s: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
    notificationOccurred: (t: 'error' | 'success' | 'warning') => void;
    selectionChanged: () => void;
  };
  MainButton?: {
    setText: (t: string) => void;
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
    showProgress: (leaveActive?: boolean) => void;
    hideProgress: () => void;
  };
  BackButton?: {
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
}

declare global {
  interface Window {
    Telegram?: { WebApp?: TelegramWebApp };
  }
}

export const MOCK_TELEGRAM_USER: TelegramUser = {
  id: 700000001,
  first_name: 'Abebe',
  last_name: 'Kebede',
  username: 'abebe_demo',
  language_code: 'en',
  photo_url: undefined,
};

export function getWebApp(): TelegramWebApp | null {
  return window.Telegram?.WebApp ?? null;
}

export function isTelegramEnvironment(): boolean {
  const wa = getWebApp();
  return Boolean(wa && wa.initData && wa.initData.length > 0);
}

export function initTelegram(): void {
  const wa = getWebApp();
  if (!wa) return;
  try {
    wa.ready();
    wa.expand();
    wa.setHeaderColor('#080B10');
    wa.setBackgroundColor('#080B10');
    wa.enableClosingConfirmation();
  } catch {
    /* noop */
  }
}

export function getTelegramUser(): TelegramUser {
  const wa = getWebApp();
  return wa?.initDataUnsafe?.user ?? MOCK_TELEGRAM_USER;
}

export function getInitData(): string {
  const wa = getWebApp();
  return wa?.initData ?? '';
}

export function haptic(type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'warning' | 'select' = 'light'): void {
  const wa = getWebApp();
  if (!wa?.HapticFeedback) return;
  try {
    if (type === 'success' || type === 'error' || type === 'warning') {
      wa.HapticFeedback.notificationOccurred(type);
    } else if (type === 'select') {
      wa.HapticFeedback.selectionChanged();
    } else {
      wa.HapticFeedback.impactOccurred(type);
    }
  } catch {
    /* noop */
  }
}

export function getSafeAreaInsets(): { top: number; bottom: number } {
  const wa = getWebApp();
  if (!wa) return { top: 0, bottom: 0 };
  return { top: 0, bottom: 0 };
}
