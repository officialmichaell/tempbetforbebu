import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassCard, SectionHeader, Badge } from '@/components/ui';
import { IconContact, IconTicket, IconInfo, IconChevronRight } from '@/components/Icons';
import { haptic } from '@/lib/telegram';

const FAQ = [
  { q: 'How do I deposit?', a: 'Go to Wallet → Deposit, choose a method, and an agent will assist you. Deposits are verified before crediting.' },
  { q: 'How long do withdrawals take?', a: 'Withdrawals go through review and processing. In this demo, the workflow is simulated.' },
  { q: 'Is this real money?', a: 'No. TemP is a prototype. All balances, odds and results are demo data. Real-money features are disabled.' },
  { q: 'How do promo codes work?', a: 'Enter a code in the Promo tab and tap Redeem. Valid codes credit your wallet instantly.' },
  { q: 'How is my account created?', a: 'Your Telegram identity creates your account automatically. No email or password is needed.' },
];

const HELP_TOPICS = [
  { label: 'Deposit Help', icon: '💰' },
  { label: 'Withdrawal Help', icon: '🏧' },
  { label: 'Betting Help', icon: '🎯' },
  { label: 'Account Help', icon: '👤' },
  { label: 'Report a Problem', icon: '⚠️' },
];

export function ContactPage() {
  const navigate = useNavigate();
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="page">
      <h1 className="text-[22px] font-black mt-4">Support Center</h1>
      <p className="text-[12px] text-muted mt-1">We're here to help</p>

      <GlassCard className="mt-4 !p-5">
        <div className="flex items-center gap-3">
          <span className="w-11 h-11 rounded-full bg-electric/15 text-electric flex items-center justify-center">
            <IconContact size={22} />
          </span>
          <div className="flex-1">
            <p className="text-[15px] font-bold">Telegram Support</p>
            <p className="text-[12px] text-muted">Chat with our team on Telegram</p>
          </div>
          <button
            onClick={() => haptic('light')}
            className="btn btn-primary !py-2 !px-4 !text-[13px]"
          >
            Open
          </button>
        </div>
      </GlassCard>

      <div className="grid grid-cols-2 gap-3 mt-3">
        <button onClick={() => navigate('/support/ticket')} className="glass p-4 flex items-center gap-3">
          <span className="w-9 h-9 rounded-full bg-purple/15 text-purple flex items-center justify-center">
            <IconTicket size={18} />
          </span>
          <span className="text-[13px] font-semibold">New Ticket</span>
        </button>
        <button onClick={() => navigate('/support/ticket')} className="glass p-4 flex items-center gap-3">
          <span className="w-9 h-9 rounded-full bg-cyan/15 text-cyan flex items-center justify-center">
            <IconInfo size={18} />
          </span>
          <span className="text-[13px] font-semibold">My Tickets</span>
        </button>
      </div>

      <SectionHeader title="Help Topics" />
      <div className="space-y-2">
        {HELP_TOPICS.map((t) => (
          <button
            key={t.label}
            onClick={() => navigate('/support/ticket')}
            className="glass p-3.5 w-full flex items-center gap-3"
          >
            <span className="text-[18px]">{t.icon}</span>
            <span className="text-[13px] font-semibold flex-1 text-left">{t.label}</span>
            <IconChevronRight size={16} className="text-muted" />
          </button>
        ))}
      </div>

      <SectionHeader title="FAQ" />
      <div className="space-y-2">
        {FAQ.map((f, i) => (
          <div key={i} className="glass overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full p-3.5 flex items-center justify-between text-left"
            >
              <span className="text-[13px] font-semibold pr-2">{f.q}</span>
              <IconChevronRight
                size={16}
                className={`text-muted transition-transform ${open === i ? 'rotate-90' : ''}`}
              />
            </button>
            {open === i && (
              <p className="px-3.5 pb-3.5 text-[12px] text-muted leading-relaxed">{f.a}</p>
            )}
          </div>
        ))}
      </div>

      <div className="glass p-3 mt-5 text-[11px] text-muted text-center">
        <Badge color="muted">DEMO</Badge>
        <p className="mt-2">Support tickets are stored locally in this prototype.</p>
      </div>
      <div className="h-6" />
    </div>
  );
}
