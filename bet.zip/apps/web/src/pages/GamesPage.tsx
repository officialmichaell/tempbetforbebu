import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Game } from '@temp/types';
import { api } from '@/lib/api';
import { GAME_CATEGORIES } from '@/lib/mockData';
import { HeroCarousel } from '@/components/HeroCarousel';
import { GameCard } from '@/components/GameCard';
import { SectionHeader, LoadingState, EmptyState, ErrorState } from '@/components/ui';
import { SPORTS } from '@/lib/mockData';
import { haptic } from '@/lib/telegram';

export function GamesPage() {
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [category, setCategory] = useState<string>('Popular');
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  const load = () => {
    setLoading(true);
    setError(false);
    api
      .getGames()
      .then(setGames)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const filtered = useMemo(() => {
    let list = games;
    if (search.trim()) {
      const q = search.toLowerCase();
      return list.filter((g) => g.title.toLowerCase().includes(q));
    }
    if (category === 'Popular') return list.filter((g) => !g.coming_soon).slice(0, 12);
    if (category === 'New') return list.filter((g) => g.badge === 'NEW' || g.coming_soon);
    if (category === 'Live') return list.filter((g) => g.badge === 'LIVE' || g.category === 'Live');
    return list.filter((g) => g.category === category);
  }, [games, category, search]);

  const featured = useMemo(() => games.filter((g) => !g.coming_soon).slice(0, 6), [games]);
  const comingSoon = useMemo(() => games.filter((g) => g.coming_soon), [games]);

  return (
    <div className="page">
      <HeroCarousel onCta={(id) => (id === 'b4' ? navigate('/game/game_18') : navigate('/promo'))} />

      {/* Search */}
      <div className="mt-4">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search games…"
          className="input"
          aria-label="Search games"
        />
      </div>

      {/* Category bar */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mt-4 -mx-4 px-4">
        {GAME_CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => {
              haptic('select');
              setCategory(c);
            }}
            className={`chip ${category === c ? 'chip-active' : ''}`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Sports quick access */}
      <SectionHeader title="Sportsbook" action="View all" onAction={() => navigate('/sportsbook')} />
      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
        {SPORTS.map((s) => (
          <button
            key={s.id}
            onClick={() => navigate('/sportsbook')}
            className="glass px-4 py-3 flex flex-col items-center gap-1 min-w-[76px]"
          >
            <span className="text-[22px]">{s.icon}</span>
            <span className="text-[11px] font-semibold">{s.name}</span>
            <span className="text-[9px] text-muted">{s.event_count} events</span>
          </button>
        ))}
      </div>

      {/* Featured */}
      <SectionHeader title="Featured Games" action="See all" onAction={() => setCategory('Popular')} />
      {loading ? (
        <div className="grid grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-[180px] rounded-[18px]" />
          ))}
        </div>
      ) : error ? (
        <ErrorState onRetry={load} />
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {featured.map((g, i) => (
            <GameCard key={g.id} game={g} index={i} />
          ))}
        </div>
      )}

      {/* Category grid */}
      <SectionHeader title={search ? 'Search Results' : category} />
      {loading ? (
        <LoadingState />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon="🎮"
          title="No games available"
          message="Try a different category or search term."
        />
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {filtered.map((g, i) => (
            <GameCard key={g.id} game={g} index={i} />
          ))}
        </div>
      )}

      {/* Coming soon */}
      <SectionHeader title="Coming Soon" />
      <div className="grid grid-cols-3 gap-3">
        {comingSoon.map((g, i) => (
          <GameCard key={g.id} game={g} index={i} />
        ))}
      </div>

      <div className="h-6" />
    </div>
  );
}
