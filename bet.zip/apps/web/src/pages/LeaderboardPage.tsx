import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { LeaderboardEntry } from '@temp/types';
import { api } from '@/lib/api';
import { formatETB } from '@temp/utils';
import { LoadingState, EmptyState } from '@/components/ui';
import { IconChevronLeft, IconTrophy } from '@/components/Icons';

export function LeaderboardPage() {
  const navigate = useNavigate();
  const [period, setPeriod] = useState<'weekly' | 'monthly' | 'all'>('weekly');
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.getLeaderboard(period).then(setEntries).finally(() => setLoading(false));
  }, [period]);

  const top3 = entries.slice(0, 3);

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Leaderboard</h1>

      <div className="flex gap-2 mt-3">
        {(['weekly', 'monthly', 'all'] as const).map((p) => (
          <button key={p} onClick={() => setPeriod(p)} className={`chip flex-1 text-center ${period === p ? 'chip-active' : ''}`}>
            {p === 'all' ? 'All-Time' : p.charAt(0).toUpperCase() + p.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <LoadingState />
      ) : entries.length === 0 ? (
        <EmptyState icon="🏆" title="No rankings yet" />
      ) : (
        <>
          {/* Podium */}
          <div className="flex items-end justify-center gap-3 mt-6">
            {[top3[1], top3[0], top3[2]].map((e, i) => {
              if (!e) return null;
              const heights = ['h-20', 'h-28', 'h-16'];
              const colors = ['from-slate-400 to-slate-600', 'from-gold to-amber-600', 'from-amber-700 to-amber-900'];
              return (
                <div key={e.user_id} className="flex flex-col items-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-electric to-purple flex items-center justify-center font-bold">
                    {e.username[0]}
                  </div>
                  <span className="text-[11px] font-semibold">{e.username}</span>
                  <div className={`w-16 ${heights[i]} rounded-t-xl bg-gradient-to-b ${colors[i]} flex items-start justify-center pt-2`}>
                    <span className="text-[16px] font-black">#{e.rank}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* List */}
          <div className="space-y-2 mt-4">
            {entries.map((e) => (
              <div
                key={e.user_id}
                className={`glass p-3 flex items-center gap-3 ${e.is_current_user ? '!border-electric/50 !bg-electric/10' : ''}`}
              >
                <span className="w-7 text-center text-[14px] font-black text-muted">{e.rank}</span>
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-electric to-purple flex items-center justify-center text-[13px] font-bold">
                  {e.username[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-semibold truncate">
                    {e.username} {e.is_current_user && <span className="text-electric text-[10px]">(You)</span>}
                  </p>
                  <p className="text-[11px] text-muted">{e.points.toLocaleString()} pts</p>
                </div>
                <span className="text-[13px] font-bold text-success">{formatETB(e.winnings, { compact: true })}</span>
              </div>
            ))}
          </div>
        </>
      )}
      <div className="h-6" />
    </div>
  );
}
