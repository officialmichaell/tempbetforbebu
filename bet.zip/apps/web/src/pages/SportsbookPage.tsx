import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Event } from '@temp/types';
import { api } from '@/lib/api';
import { SPORTS } from '@/lib/mockData';
import { LoadingState, EmptyState, ErrorState, Badge } from '@/components/ui';
import { IconHeart } from '@/components/Icons';
import { useApp } from '@/store/AppContext';
import { haptic } from '@/lib/telegram';

export function SportsbookPage() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [sport, setSport] = useState<string>('all');
  const [tab, setTab] = useState<'live' | 'upcoming'>('live');
  const navigate = useNavigate();
  const { favorites, toggleFavorite } = useApp();

  const load = () => {
    setLoading(true);
    setError(false);
    api
      .getEvents()
      .then(setEvents)
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const filtered = useMemo(() => {
    let list = events;
    if (sport !== 'all') list = list.filter((e) => e.sport_id === sport);
    list = list.filter((e) => (tab === 'live' ? e.is_live : !e.is_live));
    return list;
  }, [events, sport, tab]);

  return (
    <div className="page">
      <div className="flex items-center justify-between mt-4">
        <h1 className="text-[22px] font-black">Sportsbook</h1>
        <Badge color="muted">DEMO ODDS</Badge>
      </div>

      {/* Sport filter */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mt-3 -mx-4 px-4">
        <button onClick={() => setSport('all')} className={`chip ${sport === 'all' ? 'chip-active' : ''}`}>
          All
        </button>
        {SPORTS.map((s) => (
          <button
            key={s.id}
            onClick={() => setSport(s.id)}
            className={`chip ${sport === s.id ? 'chip-active' : ''}`}
          >
            {s.icon} {s.name}
          </button>
        ))}
      </div>

      {/* Live / Upcoming */}
      <div className="flex gap-2 mt-3">
        <button
          onClick={() => setTab('live')}
          className={`chip flex-1 text-center ${tab === 'live' ? 'chip-active' : ''}`}
        >
          <span className="inline-flex items-center gap-1.5">
            <span className="live-dot" /> Live
          </span>
        </button>
        <button
          onClick={() => setTab('upcoming')}
          className={`chip flex-1 text-center ${tab === 'upcoming' ? 'chip-active' : ''}`}
        >
          Upcoming
        </button>
      </div>

      <div className="mt-4 space-y-3">
        {loading ? (
          <LoadingState />
        ) : error ? (
          <ErrorState onRetry={load} />
        ) : filtered.length === 0 ? (
          <EmptyState icon="🏟️" title="No events" message="No events in this category right now." />
        ) : (
          filtered.map((e) => (
            <div key={e.id} className="glass p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 min-w-0">
                  {e.is_live && <span className="live-dot" />}
                  <span className="text-[11px] text-muted truncate">{e.league_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  {e.is_live && e.live_score && (
                    <span className="text-[12px] font-bold text-danger">
                      {e.live_score.home}-{e.live_score.away}
                      {e.live_score.minute ? ` · ${e.live_score.minute}'` : ''}
                    </span>
                  )}
                  <button
                    onClick={() => toggleFavorite(e.id)}
                    aria-label="Favorite event"
                    className="text-muted"
                  >
                    <IconHeart size={14} filled={favorites.has(e.id)} className={favorites.has(e.id) ? 'text-danger' : ''} />
                  </button>
                </div>
              </div>

              <button
                onClick={() => navigate(`/event/${e.id}`)}
                className="w-full text-left"
              >
                <p className="text-[14px] font-bold">{e.home}</p>
                <p className="text-[14px] font-bold">{e.away}</p>
                {!e.is_live && (
                  <p className="text-[11px] text-muted mt-1">
                    {new Date(e.start_time).toLocaleString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                )}
              </button>

              <div className="flex gap-2 mt-3">
                {e.markets[0].selections.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      haptic('light');
                      navigate(`/event/${e.id}`);
                    }}
                    className="odds-btn"
                  >
                    <span className="text-[10px] text-muted">{s.name}</span>
                    <span className="text-[14px] font-bold">{s.odds.toFixed(2)}</span>
                  </button>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
      <div className="h-6" />
    </div>
  );
}
