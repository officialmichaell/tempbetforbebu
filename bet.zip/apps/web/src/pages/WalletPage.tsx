import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { WalletTransaction } from '@temp/types';
import { api } from '@/lib/api';
import { useApp } from '@/store/AppContext';
import { formatETB, formatSignedETB, timeAgo } from '@temp/utils';
import { GlassCard, SectionHeader, LoadingState, EmptyState } from '@/components/ui';
import { IconArrowDown, IconArrowUp, IconHistory } from '@/components/Icons';

export function WalletPage() {
  const { wallet } = useApp();
  const navigate = useNavigate();
  const [txs, setTxs] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getTransactions().then(setTxs).finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <h1 className="text-[22px] font-black mt-4">Wallet</h1>

      <GlassCard className="mt-4 !p-5">
        <p className="text-[12px] text-muted">Available Balance</p>
        <p className="text-[32px] font-black mt-1">{formatETB(wallet?.balance ?? 0)}</p>
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div>
            <p className="text-[10px] text-muted uppercase">Bonus</p>
            <p className="text-[14px] font-bold text-gold">{formatETB(wallet?.bonus_balance ?? 0)}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted uppercase">Pending</p>
            <p className="text-[14px] font-bold text-cyan">{formatETB(wallet?.pending_balance ?? 0)}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted uppercase">Currency</p>
            <p className="text-[14px] font-bold">ETB</p>
          </div>
        </div>
      </GlassCard>

      <div className="grid grid-cols-3 gap-3 mt-4">
        <button onClick={() => navigate('/deposit')} className="glass p-3 flex flex-col items-center gap-1.5">
          <span className="w-9 h-9 rounded-full bg-success/15 text-success flex items-center justify-center">
            <IconArrowDown size={18} />
          </span>
          <span className="text-[12px] font-semibold">Deposit</span>
        </button>
        <button onClick={() => navigate('/withdraw')} className="glass p-3 flex flex-col items-center gap-1.5">
          <span className="w-9 h-9 rounded-full bg-danger/15 text-danger flex items-center justify-center">
            <IconArrowUp size={18} />
          </span>
          <span className="text-[12px] font-semibold">Withdraw</span>
        </button>
        <button onClick={() => navigate('/transactions')} className="glass p-3 flex flex-col items-center gap-1.5">
          <span className="w-9 h-9 rounded-full bg-electric/15 text-electric flex items-center justify-center">
            <IconHistory size={18} />
          </span>
          <span className="text-[12px] font-semibold">History</span>
        </button>
      </div>

      <SectionHeader title="Recent Transactions" action="View all" onAction={() => navigate('/transactions')} />
      {loading ? (
        <LoadingState />
      ) : txs.length === 0 ? (
        <EmptyState icon="🧾" title="No transactions" message="Your transaction history will appear here." />
      ) : (
        <div className="space-y-2">
          {txs.slice(0, 6).map((t) => (
            <div key={t.id} className="glass p-3 flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-[13px] font-semibold truncate">{t.description ?? t.type}</p>
                <p className="text-[11px] text-muted">{timeAgo(t.created_at)}</p>
              </div>
              <span className={`text-[14px] font-bold ${t.amount >= 0 ? 'text-success' : 'text-danger'}`}>
                {formatSignedETB(t.amount)}
              </span>
            </div>
          ))}
        </div>
      )}
      <div className="h-6" />
    </div>
  );
}
