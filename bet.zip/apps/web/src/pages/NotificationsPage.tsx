import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/store/AppContext';
import { timeAgo } from '@temp/utils';
import { LoadingState, EmptyState, Badge } from '@/components/ui';
import { IconChevronLeft, IconBell } from '@/components/Icons';

const TYPE_COLOR: Record<string, string> = {
  deposit: 'text-success',
  withdrawal: 'text-danger',
  bet_result: 'text-electric',
  promotion: 'text-purple',
  bonus: 'text-gold',
  cashback: 'text-gold',
  streak: 'text-danger',
  system: 'text-cyan',
};

export function NotificationsPage() {
  const navigate = useNavigate();
  const { notifications, markRead, markAllRead, unreadCount } = useApp();

  return (
    <div className="page">
      <div className="flex items-center justify-between mt-4 mb-2">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted">
          <IconChevronLeft size={18} /> Back
        </button>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="text-[12px] text-electric font-semibold">
            Mark all read
          </button>
        )}
      </div>
      <h1 className="text-[22px] font-black">Notifications</h1>

      <div className="mt-4 space-y-2">
        {notifications.length === 0 ? (
          <EmptyState icon="🔔" title="No notifications" message="You're all caught up." />
        ) : (
          notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => markRead(n.id)}
              className={`glass p-3.5 w-full flex items-start gap-3 text-left ${
                !n.read ? '!border-electric/30' : ''
              }`}
            >
              <span className={`w-9 h-9 rounded-full bg-white/6 flex items-center justify-center shrink-0 ${TYPE_COLOR[n.type]}`}>
                <IconBell size={17} />
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-[13px] font-bold">{n.title}</p>
                  {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-electric" />}
                </div>
                <p className="text-[12px] text-muted mt-0.5">{n.body}</p>
                <p className="text-[10px] text-muted mt-1">{timeAgo(n.created_at)}</p>
              </div>
            </button>
          ))
        )}
      </div>
      <div className="h-6" />
    </div>
  );
}
