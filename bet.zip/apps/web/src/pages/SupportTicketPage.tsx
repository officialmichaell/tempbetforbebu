import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { SupportTicket } from '@temp/types';
import { api } from '@/lib/api';
import { GlassCard, Badge, Toast, EmptyState } from '@/components/ui';
import { IconChevronLeft, IconTicket } from '@/components/Icons';
import { timeAgo } from '@temp/utils';
import { haptic } from '@/lib/telegram';

const CATEGORIES = ['Deposit', 'Withdrawal', 'Betting', 'Account', 'Other'];

export function SupportTicketPage() {
  const navigate = useNavigate();
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('Deposit');
  const [message, setMessage] = useState('');
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = () => api.getTickets().then(setTickets);
  useEffect(() => {
    load();
  }, []);

  const submit = async () => {
    if (!subject.trim() || !message.trim()) {
      setToast({ msg: 'Please fill in all fields', type: 'error' });
      return;
    }
    haptic('medium');
    setSubmitting(true);
    try {
      await api.createTicket(subject, category, message);
      await load();
      setSubject('');
      setMessage('');
      haptic('success');
      setToast({ msg: 'Ticket submitted!', type: 'success' });
    } finally {
      setSubmitting(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Support Tickets</h1>

      <GlassCard className="mt-4">
        <label className="text-[12px] text-muted font-medium">Subject</label>
        <input value={subject} onChange={(e) => setSubject(e.target.value)} className="input mt-1.5" placeholder="Brief summary" />

        <label className="text-[12px] text-muted font-medium mt-3 block">Category</label>
        <div className="flex gap-2 flex-wrap mt-1.5">
          {CATEGORIES.map((c) => (
            <button key={c} onClick={() => setCategory(c)} className={`chip ${category === c ? 'chip-active' : ''}`}>
              {c}
            </button>
          ))}
        </div>

        <label className="text-[12px] text-muted font-medium mt-3 block">Message</label>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={4}
          className="input mt-1.5 resize-none"
          placeholder="Describe your issue…"
        />

        <button onClick={submit} disabled={submitting} className="btn btn-primary w-full mt-3">
          {submitting ? 'Submitting…' : 'Submit Ticket'}
        </button>
      </GlassCard>

      <h2 className="text-[15px] font-bold mt-5 mb-2">My Tickets</h2>
      {tickets.length === 0 ? (
        <EmptyState icon="🎫" title="No tickets" message="Your support tickets will appear here." />
      ) : (
        <div className="space-y-2">
          {tickets.map((t) => (
            <div key={t.id} className="glass p-3.5">
              <div className="flex items-center justify-between">
                <p className="text-[13px] font-bold">{t.subject}</p>
                <Badge color={t.state === 'open' ? 'gold' : 'green'}>{t.state.toUpperCase()}</Badge>
              </div>
              <p className="text-[12px] text-muted mt-1">{t.message}</p>
              <p className="text-[10px] text-muted mt-1.5">
                {t.category} · {timeAgo(t.created_at)}
              </p>
            </div>
          ))}
        </div>
      )}

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      <div className="h-6" />
    </div>
  );
}
