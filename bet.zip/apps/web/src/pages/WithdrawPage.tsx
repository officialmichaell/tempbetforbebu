import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/lib/api';
import { useApp } from '@/store/AppContext';
import { formatETB } from '@temp/utils';
import { GlassCard, Badge, Toast } from '@/components/ui';
import { IconChevronLeft, IconCheck } from '@/components/Icons';
import { haptic } from '@/lib/telegram';
import type { Withdrawal } from '@temp/types';

const METHODS = [
  { id: 'telebirr', name: 'Telebirr' },
  { id: 'cbe', name: 'CBE Birr' },
  { id: 'bank', name: 'Bank Transfer' },
];

const STEPS = ['REQUESTED', 'UNDER_REVIEW', 'APPROVED', 'PROCESSING', 'COMPLETED'];

export function WithdrawPage() {
  const navigate = useNavigate();
  const { wallet, refreshWallet } = useApp();
  const [amount, setAmount] = useState('200');
  const [method, setMethod] = useState('telebirr');
  const [account, setAccount] = useState('');
  const [confirm, setConfirm] = useState(false);
  const [withdrawal, setWithdrawal] = useState<Withdrawal | null>(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const submit = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return setToast('Enter a valid amount');
    if (amt > (wallet?.balance ?? 0)) return setToast('Insufficient balance');
    if (!account.trim()) return setToast('Enter your account/phone number');
    if (!confirm) return setToast('Please confirm the withdrawal');
    haptic('medium');
    setLoading(true);
    try {
      const w = await api.createWithdrawal(amt, METHODS.find((m) => m.id === method)!.name, account);
      setWithdrawal(w);
      await refreshWallet();
      haptic('success');
      const poll = setInterval(async () => {
        const list = await api.getWithdrawals();
        const updated = list.find((x) => x.id === w.id);
        if (updated) {
          setWithdrawal({ ...updated });
          if (updated.state === 'COMPLETED') clearInterval(poll);
        }
      }, 1200);
    } catch (e) {
      setToast(e instanceof Error ? e.message : 'Withdrawal failed');
    } finally {
      setLoading(false);
    }
  };

  const stepIndex = withdrawal ? STEPS.indexOf(withdrawal.state) : -1;

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Withdraw</h1>
      <p className="text-[12px] text-muted mt-1">Available: {formatETB(wallet?.balance ?? 0)}</p>

      {!withdrawal ? (
        <>
          <GlassCard className="mt-4">
            <label className="text-[12px] text-muted font-medium">Amount (ETB)</label>
            <input
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="input mt-1.5 !text-[22px] !font-bold"
            />
            <button
              onClick={() => setAmount(String(wallet?.balance ?? 0))}
              className="text-[12px] text-electric font-semibold mt-2"
            >
              Withdraw all
            </button>
          </GlassCard>

          <h2 className="text-[15px] font-bold mt-5 mb-2">Withdrawal Method</h2>
          <div className="flex gap-2">
            {METHODS.map((m) => (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`chip flex-1 text-center ${method === m.id ? 'chip-active' : ''}`}
              >
                {m.name}
              </button>
            ))}
          </div>

          <h2 className="text-[15px] font-bold mt-5 mb-2">Account / Phone</h2>
          <input
            value={account}
            onChange={(e) => setAccount(e.target.value)}
            placeholder="e.g. 09XX XXX XXX"
            className="input"
          />

          <label className="flex items-start gap-2 mt-4 text-[12px] text-muted">
            <input
              type="checkbox"
              checked={confirm}
              onChange={(e) => setConfirm(e.target.checked)}
              className="mt-0.5 accent-electric"
            />
            I confirm the withdrawal details are correct and understand this is a demo workflow.
          </label>

          <button onClick={submit} disabled={loading} className="btn btn-primary w-full mt-4 !py-3.5">
            {loading ? 'Submitting…' : 'Request Withdrawal'}
          </button>
        </>
      ) : (
        <GlassCard className="mt-4 !p-5">
          <div className="flex items-center justify-between">
            <span className="text-[13px] text-muted">Withdrawal</span>
            <Badge color={withdrawal.state === 'COMPLETED' ? 'green' : 'gold'}>
              {withdrawal.state.replace('_', ' ')}
            </Badge>
          </div>
          <p className="text-[28px] font-black mt-2">{formatETB(withdrawal.amount)}</p>
          <p className="text-[12px] text-muted">
            {withdrawal.method} · {withdrawal.account}
          </p>

          <div className="mt-5 space-y-3">
            {STEPS.map((s, i) => {
              const done = i <= stepIndex;
              return (
                <div key={s} className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-[12px] font-bold ${
                      done ? 'bg-success text-white' : 'bg-white/8 text-muted'
                    }`}
                  >
                    {done ? <IconCheck size={14} /> : i + 1}
                  </div>
                  <span className={`text-[13px] ${done ? 'font-semibold' : 'text-muted'}`}>
                    {s.replace('_', ' ')}
                  </span>
                </div>
              );
            })}
          </div>

          <button onClick={() => navigate('/wallet')} className="btn btn-ghost w-full mt-4">
            Go to Wallet
          </button>
        </GlassCard>
      )}

      {toast && <Toast message={toast} type="error" onClose={() => setToast(null)} />}
      <div className="h-6" />
    </div>
  );
}
