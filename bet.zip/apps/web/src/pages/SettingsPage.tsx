import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/store/AppContext';
import { GlassCard, Badge } from '@/components/ui';
import { IconChevronLeft, IconGlobe, IconBell, IconShield, IconLogout } from '@/components/Icons';

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      role="switch"
      aria-checked={on}
      className={`w-11 h-6 rounded-full transition-colors relative ${on ? 'bg-electric' : 'bg-white/15'}`}
    >
      <span
        className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${on ? 'translate-x-[22px]' : 'translate-x-0.5'}`}
      />
    </button>
  );
}

export function SettingsPage() {
  const navigate = useNavigate();
  const { user } = useApp();
  const [lang, setLang] = useState(user?.language ?? 'en');
  const [notif, setNotif] = useState(true);
  const [promoNotif, setPromoNotif] = useState(true);
  const [oddsFormat, setOddsFormat] = useState('decimal');

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Settings</h1>

      <GlassCard className="mt-4">
        <div className="flex items-center gap-3">
          <IconGlobe size={20} className="text-electric" />
          <span className="text-[14px] font-semibold flex-1">Language</span>
          <select
            value={lang}
            onChange={(e) => setLang(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-[13px] outline-none"
          >
            <option value="en">English</option>
            <option value="am">አማርኛ (Amharic)</option>
            <option value="om">Afaan Oromoo</option>
          </select>
        </div>
      </GlassCard>

      <GlassCard className="mt-3 space-y-4">
        <div className="flex items-center gap-3">
          <IconBell size={20} className="text-purple" />
          <span className="text-[14px] font-semibold flex-1">Push Notifications</span>
          <Toggle on={notif} onChange={setNotif} />
        </div>
        <div className="flex items-center gap-3">
          <IconBell size={20} className="text-gold" />
          <span className="text-[14px] font-semibold flex-1">Promotional Alerts</span>
          <Toggle on={promoNotif} onChange={setPromoNotif} />
        </div>
      </GlassCard>

      <GlassCard className="mt-3">
        <div className="flex items-center gap-3">
          <span className="text-[14px] font-semibold flex-1">Odds Format</span>
          <div className="flex gap-1.5">
            {['decimal', 'fractional'].map((f) => (
              <button
                key={f}
                onClick={() => setOddsFormat(f)}
                className={`chip !py-1.5 !px-3 !text-[12px] ${oddsFormat === f ? 'chip-active' : ''}`}
              >
                {f === 'decimal' ? '1.85' : '17/20'}
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      <button
        onClick={() => navigate('/responsible-gaming')}
        className="glass p-4 mt-3 w-full flex items-center gap-3"
      >
        <IconShield size={20} className="text-success" />
        <span className="text-[14px] font-semibold flex-1 text-left">Responsible Gaming</span>
      </button>

      <GlassCard className="mt-3">
        <div className="flex items-center justify-between">
          <span className="text-[13px] text-muted">Account ID</span>
          <span className="text-[12px] font-mono">{user?.telegram_id}</span>
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-[13px] text-muted">Status</span>
          <Badge color="green">{user?.status?.toUpperCase()}</Badge>
        </div>
      </GlassCard>

      <button className="btn btn-ghost w-full mt-4 !text-danger">
        <IconLogout size={16} /> Sign Out
      </button>

      <p className="text-[10px] text-muted text-center mt-4">
        TemP v0.1.0 · Prototype build · Real-money disabled
      </p>
      <div className="h-6" />
    </div>
  );
}
