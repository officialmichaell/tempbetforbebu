import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/lib/api';
import { useApp } from '@/store/AppContext';
import { formatETB } from '@temp/utils';
import { GlassCard, Badge, Toast } from '@/components/ui';
import { IconChevronLeft, IconCheck } from '@/components/Icons';
import { haptic } from '@/lib/telegram';
import type { Deposit } from '@temp/types';

const METHODS = [
  { id: 'telebirr', name: 'Telebirr', icon: '📱' },
  { id: 'cbe', name: 'CBE Birr', icon: '🏦' },
  { id: 'agent', name: 'Agent Cash', icon: '🤝' },
  { id: 'bank', name: 'Bank Transfer', icon: '💳' },
];

const STEPS = ['PENDING', 'AGENT_CONFIRMED', 'UNDER_REVIEW', 'APPROVED'];

export function DepositPage() {
  const navigate = useNavigate();
  const { refreshWallet } = useApp();
  const [amount, setAmount] = useState('500');
  const [method, setMethod] = useState('telebirr');
  const [deposit, setDeposit] = useState<Deposit | null>(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const submit = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) {
      setToast('Enter a valid amount');
      return;
    }
    haptic('medium');
    setLoading(true);
    try {
      const d = await api.createDeposit(amt, METHODS.find((m) => m.id === method)!.name);
      setDeposit(d);
      haptic('success');
      // Poll for state changes
      const poll = setInterval(async () => {
        const list = await api.getDeposits();
        const updated = list.find((x) => x.id === d.id);
        if (updated) {
          setDeposit({ ...updated });
          if (updated.state === 'APPROVED') {
            clearInterval(poll);
            await refreshWallet();
          }
        }
      }, 1200);
    } catch (e) {
      setToast(e instanceof Error ? e.message : 'Deposit failed');
    } finally {
      setLoading(false);
    }
  };

  const stepIndex = deposit ? STEPS.indexOf(deposit.state) : -1;

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Deposit</h1>
      <p className="text-[12px] text-muted mt-1">Agent-assisted deposit · Demo only</p>

      {!deposit ? (
        <>
          <GlassCard className="mt-4">
            <label className="text-[12px] text-muted font-medium">Amount (ETB)</label>
            <input
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="input mt-1.5 !text-[22px] !font-bold"
            />
            <div className="flex gap-2 mt-2">
              {[100, 500, 1000, 5000].map((v) => (
                <button key={v} onClick={() => setAmount(String(v))} className="chip flex-1 text-center">
                  {v}
                </button>
              ))}
            </div>
          </GlassCard>

          <h2 className="text-[15px] font-bold mt-5 mb-2">Payment Method</h2>
          <div className="grid grid-cols-2 gap-3">
            {METHODS.map((m) => (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`glass p-3 flex items-center gap-2 ${
                  method === m.id ? '!border-electric/60 !bg-electric/10' : ''
                }`}
              >
                <span className="text-[20px]">{m.icon}</span>
                <span className="text-[13px] font-semibold">{m.name}</span>
              </button>
            ))}
          </div>

          <div className="glass p-3 mt-4 text-[11px] text-muted leading-relaxed">
            Your deposit request will be assigned to an agent. The agent confirms the payment,
            then it goes through admin verification before your wallet is credited. This is a
            simulated workflow — no real money is involved.
          </div>

          <button onClick={submit} disabled={loading} className="btn btn-primary w-full mt-4 !py-3.5">
            {loading ? 'Submitting…' : `Deposit ${formatETB(parseFloat(amount) || 0)}`}
          </button>
        </>
      ) : (
        <GlassCard className="mt-4 !p-5">
          <div className="flex items-center justify-between">
            <span className="text-[13px] text-muted">Deposit Request</span>
            <Badge color={deposit.state === 'APPROVED' ? 'green' : 'gold'}>{deposit.state.replace('_', ' ')}</Badge>
          </div>
          <p className="text-[28px] font-black mt-2">{formatETB(deposit.amount)}</p>
          <p className="text-[12px] text-muted">Ref: {deposit.reference}</p>

          <div className="mt-5 space-y-3">
            {STEPS.map((s, i) => {
              const done = i <= stepIndex;
              const active = i === stepIndex;
              return (
                <div key={s} className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-[12px] font-bold ${
                      done ? 'bg-success text-white' : 'bg-white/8 text-muted'
                    } ${active ? 'ring-2 ring-success/40' : ''}`}
                  >
                    {done ? <IconCheck size={14} /> : i + 1}
                  </div>
                  <span className={`text-[13px] ${done ? 'font-semibold' : 'text-muted'}`}>
                    {s.replace('_', ' ')}
                  </span>
                </div>
              );
            })}
          </div>

          {deposit.state === 'APPROVED' && (
            <div className="mt-5 p-3 rounded-xl bg-success/10 border border-success/30 text-success text-[13px] font-semibold text-center">
              Deposit approved! Balance updated.
            </div>
          )}

          <button onClick={() => navigate('/wallet')} className="btn btn-ghost w-full mt-4">
            Go to Wallet
          </button>
        </GlassCard>
      )}

      {toast && <Toast message={toast} type="error" onClose={() => setToast(null)} />}
      <div className="h-6" />
    </div>
  );
}
