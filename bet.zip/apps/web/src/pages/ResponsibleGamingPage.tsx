import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassCard, Badge } from '@/components/ui';
import { IconChevronLeft, IconShield, IconInfo } from '@/components/Icons';

export function ResponsibleGamingPage() {
  const navigate = useNavigate();
  const [depositLimit, setDepositLimit] = useState('2000');
  const [betLimit, setBetLimit] = useState('500');
  const [lossLimit, setLossLimit] = useState('1000');
  const [selfExcluded, setSelfExcluded] = useState(false);

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Responsible Gaming</h1>
      <p className="text-[12px] text-muted mt-1">Stay in control of your play</p>

      <GlassCard className="mt-4 !p-4">
        <div className="flex items-start gap-3">
          <IconShield size={20} className="text-success mt-0.5" />
          <p className="text-[12px] text-muted leading-relaxed">
            Gambling should be fun, never a way to make money. Set limits, take breaks, and seek
            help if it stops being fun. You must be 18+ to play. This prototype does not accept
            real-money wagers.
          </p>
        </div>
      </GlassCard>

      <h2 className="text-[15px] font-bold mt-5 mb-2">Set Your Limits</h2>
      <GlassCard className="space-y-4">
        <LimitRow label="Daily Deposit Limit" value={depositLimit} onChange={setDepositLimit} />
        <LimitRow label="Max Bet Limit" value={betLimit} onChange={setBetLimit} />
        <LimitRow label="Daily Loss Limit" value={lossLimit} onChange={setLossLimit} />
      </GlassCard>

      <GlassCard className="mt-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[14px] font-semibold">Self-Exclusion</p>
            <p className="text-[11px] text-muted">Temporarily block your account</p>
          </div>
          <button
            onClick={() => setSelfExcluded((v) => !v)}
            className={`btn ${selfExcluded ? 'btn-success' : 'btn-ghost'} !py-2 !px-4 !text-[13px]`}
          >
            {selfExcluded ? 'Active' : 'Enable'}
          </button>
        </div>
      </GlassCard>

      <GlassCard className="mt-3">
        <div className="flex items-center gap-2">
          <IconInfo size={16} className="text-cyan" />
          <span className="text-[13px] font-semibold">Need help?</span>
        </div>
        <p className="text-[12px] text-muted mt-2">
          Contact our support team via the Contact tab. If you feel you may have a gambling
          problem, please seek professional support.
        </p>
      </GlassCard>

      <div className="glass p-3 mt-4 text-center">
        <Badge color="muted">ARCHITECTURE ONLY</Badge>
        <p className="text-[11px] text-muted mt-2">
          Limit enforcement must be server-side in production.
        </p>
      </div>
      <div className="h-6" />
    </div>
  );
}

function LimitRow({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-[12px] text-muted font-medium">{label} (ETB)</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="input mt-1.5"
      />
    </div>
  );
}
