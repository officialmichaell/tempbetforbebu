import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Bet } from '@temp/types';
import { api } from '@/lib/api';
import { formatETB, formatOdds, timeAgo } from '@temp/utils';
import { LoadingState, EmptyState, Badge } from '@/components/ui';
import { IconChevronLeft } from '@/components/Icons';

const STATE_COLOR: Record<string, 'green' | 'red' | 'gold' | 'muted'> = {
  won: 'green',
  lost: 'red',
  pending: 'gold',
  void: 'muted',
  cashed_out: 'muted',
};

export function BetHistoryPage() {
  const navigate = useNavigate();
  const [bets, setBets] = useState<Bet[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getBets().then(setBets).finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Betting History</h1>

      <div className="mt-4 space-y-3">
        {loading ? (
          <LoadingState />
        ) : bets.length === 0 ? (
          <EmptyState
            icon="🎯"
            title="No bets yet"
            message="Place your first demo bet from the sportsbook."
            action="Go to Sportsbook"
            onAction={() => navigate('/sportsbook')}
          />
        ) : (
          bets.map((b) => (
            <div key={b.id} className="glass p-3.5">
              <div className="flex items-center justify-between">
                <Badge color={STATE_COLOR[b.state]}>{b.state.toUpperCase()}</Badge>
                <span className="text-[11px] text-muted">{timeAgo(b.created_at)}</span>
              </div>
              <div className="mt-2 space-y-1.5">
                {b.selections.map((s, i) => (
                  <div key={i} className="flex items-center justify-between text-[12px]">
                    <span className="truncate pr-2">{s.event_label}</span>
                    <span className="text-bright font-semibold shrink-0">{formatOdds(s.odds)}</span>
                  </div>
                ))}
              </div>
              <div className="h-px bg-white/8 my-2.5" />
              <div className="flex items-center justify-between text-[12px]">
                <span className="text-muted">
                  {b.type === 'accumulator' ? 'Accumulator' : 'Single'} · Stake {formatETB(b.stake)}
                </span>
                <span className={`font-bold ${b.state === 'won' ? 'text-success' : ''}`}>
                  {b.state === 'won' ? `+${formatETB(b.payout ?? 0)}` : `Win ${formatETB(b.potential_win)}`}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
      <div className="h-6" />
    </div>
  );
}
