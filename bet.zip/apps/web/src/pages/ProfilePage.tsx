import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/store/AppContext';
import { formatETB } from '@temp/utils';
import { GlassCard, Badge } from '@/components/ui';
import {
  IconWallet, IconHistory, IconGift, IconTrophy, IconSettings, IconShield,
  IconContact, IconBell, IconArrowDown, IconArrowUp, IconFire, IconUsers, IconChevronRight,
} from '@/components/Icons';

const DASHBOARD = [
  { label: 'Daily Streak', icon: IconFire, to: '/promo', color: 'text-danger' },
  { label: 'Daily Cashback', icon: IconGift, to: '/promo', color: 'text-gold' },
  { label: 'Leaderboard', icon: IconTrophy, to: '/leaderboard', color: 'text-gold' },
  { label: 'Rewards', icon: IconGift, to: '/promo', color: 'text-purple' },
  { label: 'Bonuses', icon: IconGift, to: '/promo', color: 'text-success' },
  { label: 'Affiliate', icon: IconUsers, to: '/profile', color: 'text-cyan' },
  { label: 'Betting History', icon: IconHistory, to: '/bets', color: 'text-electric' },
  { label: 'Casino History', icon: IconHistory, to: '/bets', color: 'text-purple' },
  { label: 'Transactions', icon: IconWallet, to: '/transactions', color: 'text-electric' },
  { label: 'Deposits', icon: IconArrowDown, to: '/deposit', color: 'text-success' },
  { label: 'Withdrawals', icon: IconArrowUp, to: '/withdraw', color: 'text-danger' },
  { label: 'Notifications', icon: IconBell, to: '/notifications', color: 'text-electric' },
  { label: 'Settings', icon: IconSettings, to: '/settings', color: 'text-muted' },
  { label: 'Responsible Gaming', icon: IconShield, to: '/responsible-gaming', color: 'text-success' },
  { label: 'Support', icon: IconContact, to: '/contact', color: 'text-cyan' },
];

export function ProfilePage() {
  const { user, wallet } = useApp();
  const navigate = useNavigate();

  return (
    <div className="page">
      {/* Header */}
      <GlassCard className="mt-4 !p-5">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/15 flex items-center justify-center bg-gradient-to-br from-electric to-purple text-[24px] font-black">
            {user?.avatar_url ? (
              <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
            ) : (
              (user?.first_name?.[0] ?? 'U').toUpperCase()
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-[19px] font-black truncate">
              {user?.first_name} {user?.last_name}
            </h1>
            <p className="text-[12px] text-muted truncate">
              {user?.telegram_username ? `@${user.telegram_username}` : 'Telegram user'}
            </p>
            <div className="mt-1.5">
              <Badge color="green">{user?.status?.toUpperCase() ?? 'ACTIVE'}</Badge>
            </div>
          </div>
          <button
            onClick={() => navigate('/')}
            aria-label="Home"
            className="w-9 h-9 rounded-full glass flex items-center justify-center"
          >
            <IconChevronRight size={18} />
          </button>
        </div>
      </GlassCard>

      {/* Balance cards */}
      <div className="grid grid-cols-2 gap-3 mt-4">
        <GlassCard className="!p-4">
          <p className="text-[11px] text-muted uppercase">Balance</p>
          <p className="text-[20px] font-black mt-1">{formatETB(wallet?.balance ?? 0)}</p>
        </GlassCard>
        <GlassCard className="!p-4">
          <p className="text-[11px] text-muted uppercase">Credit / Bonus</p>
          <p className="text-[20px] font-black mt-1 text-gold">{formatETB(wallet?.bonus_balance ?? 0)}</p>
        </GlassCard>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-3">
        <button onClick={() => navigate('/withdraw')} className="btn btn-ghost !py-3">
          <IconArrowUp size={16} /> Withdraw
        </button>
        <button onClick={() => navigate('/deposit')} className="btn btn-primary !py-3">
          <IconArrowDown size={16} /> Deposit
        </button>
      </div>

      {/* Dashboard */}
      <h2 className="text-[16px] font-bold mt-6 mb-3">Dashboard</h2>
      <div className="grid grid-cols-2 gap-3">
        {DASHBOARD.map((item) => (
          <button
            key={item.label}
            onClick={() => navigate(item.to)}
            className="glass p-3.5 flex items-center gap-3 text-left"
          >
            <span className={`w-9 h-9 rounded-full bg-white/6 flex items-center justify-center ${item.color}`}>
              <item.icon size={18} />
            </span>
            <span className="text-[12.5px] font-semibold leading-tight">{item.label}</span>
          </button>
        ))}
      </div>

      <div className="glass p-3 mt-5 text-[11px] text-muted text-center">
        TemP · Demo prototype · No real-money wagering
      </div>
      <div className="h-6" />
    </div>
  );
}
