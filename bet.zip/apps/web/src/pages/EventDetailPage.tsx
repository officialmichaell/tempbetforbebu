import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import type { Event } from '@temp/types';
import { api } from '@/lib/api';
import { useApp } from '@/store/AppContext';
import { LoadingState, ErrorState, Badge } from '@/components/ui';
import { IconChevronLeft } from '@/components/Icons';
import { haptic } from '@/lib/telegram';

export function EventDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addSelection, isSelected } = useApp();
  const [event, setEvent] = useState<Event | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    api
      .getEvent(id)
      .then((e) => setEvent(e ?? null))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="page"><LoadingState /></div>;
  if (!event) return <div className="page"><ErrorState title="Event not found" /></div>;

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>

      <div className="glass p-4">
        <div className="flex items-center justify-between">
          <span className="text-[12px] text-muted">{event.league_name}</span>
          {event.is_live ? (
            <span className="flex items-center gap-1.5 text-danger text-[12px] font-bold">
              <span className="live-dot" /> LIVE {event.live_score && `${event.live_score.home}-${event.live_score.away}`}
            </span>
          ) : (
            <Badge color="blue">
              {new Date(event.start_time).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
            </Badge>
          )}
        </div>
        <div className="mt-3 space-y-1">
          <p className="text-[18px] font-extrabold">{event.home}</p>
          <p className="text-[13px] text-muted">vs</p>
          <p className="text-[18px] font-extrabold">{event.away}</p>
        </div>
      </div>

      <h2 className="text-[16px] font-bold mt-5 mb-3">Markets</h2>
      <div className="space-y-3">
        {event.markets.map((m) => (
          <div key={m.id} className="glass p-3">
            <p className="text-[13px] font-semibold mb-2">{m.name}</p>
            <div className="flex gap-2">
              {m.selections.map((s) => {
                const selected = isSelected(event.id) && false;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      haptic('light');
                      addSelection({
                        event_id: event.id,
                        event_label: `${event.home} vs ${event.away}`,
                        market_name: m.name,
                        selection_name: s.name,
                        odds: s.odds,
                      });
                    }}
                    className="odds-btn"
                  >
                    <span className="text-[10px] text-muted">{s.name}</span>
                    <span className="text-[14px] font-bold">{s.odds.toFixed(2)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <div className="h-6" />
    </div>
  );
}
