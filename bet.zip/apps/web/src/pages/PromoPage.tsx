import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Promotion, Cashback, Streak } from '@temp/types';
import { api } from '@/lib/api';
import { useApp } from '@/store/AppContext';
import { formatETB, countdownParts } from '@temp/utils';
import { GlassCard, SectionHeader, LoadingState, EmptyState, Badge, Toast, ProgressBar } from '@/components/ui';
import { IconGift, IconTrophy, IconFire, IconCheck, IconTicket } from '@/components/Icons';
import { haptic } from '@/lib/telegram';

export function PromoPage() {
  const navigate = useNavigate();
  const { refreshWallet } = useApp();
  const [promos, setPromos] = useState<Promotion[]>([]);
  const [cashback, setCashback] = useState<Cashback | null>(null);
  const [streak, setStreak] = useState<Streak | null>(null);
  const [loading, setLoading] = useState(true);
  const [code, setCode] = useState('');
  const [redeeming, setRedeeming] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [cd, setCd] = useState({ h: '00', m: '00', s: '00' });

  useEffect(() => {
    Promise.all([api.getPromotions(), api.getCashback(), api.getStreak()])
      .then(([p, c, s]) => {
        setPromos(p);
        setCashback(c);
        setStreak(s);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!cashback) return;
    const tick = () => setCd(countdownParts(cashback.next_claim_at));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [cashback]);

  const redeem = async () => {
    if (!code.trim()) return;
    haptic('medium');
    setRedeeming(true);
    try {
      const res = await api.redeemPromoCode(code);
      if (res.state === 'success') {
        await refreshWallet();
        haptic('success');
        setToast({ msg: res.message, type: 'success' });
        setCode('');
      } else {
        haptic('error');
        setToast({ msg: res.message, type: 'error' });
      }
    } finally {
      setRedeeming(false);
      setTimeout(() => setToast(null), 3200);
    }
  };

  const claimCashback = async () => {
    haptic('medium');
    try {
      const { amount } = await api.claimCashback();
      await refreshWallet();
      haptic('success');
      setToast({ msg: `Claimed ${formatETB(amount)} cashback!`, type: 'success' });
      const c = await api.getCashback();
      setCashback(c);
    } catch (e) {
      setToast({ msg: e instanceof Error ? e.message : 'Failed', type: 'error' });
    }
    setTimeout(() => setToast(null), 3200);
  };

  const claimStreak = async () => {
    haptic('medium');
    try {
      const { reward } = await api.claimStreak();
      await refreshWallet();
      haptic('success');
      setToast({ msg: `Streak reward: ${formatETB(reward)}!`, type: 'success' });
    } catch {
      setToast({ msg: 'Failed to claim', type: 'error' });
    }
    setTimeout(() => setToast(null), 3200);
  };

  if (loading) return <div className="page"><LoadingState /></div>;

  return (
    <div className="page">
      <h1 className="text-[22px] font-black mt-4">Promotions</h1>
      <p className="text-[12px] text-muted mt-1">Bonuses, cashback, streaks & rewards</p>

      {/* Cashback card */}
      {cashback && (
        <GlassCard className="mt-4 !p-5 relative overflow-hidden">
          <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-gold/10 blur-2xl" />
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-gold/15 text-gold flex items-center justify-center">
                <IconFire size={16} />
              </span>
              <span className="text-[14px] font-bold">DAILY CASHBACK</span>
            </div>
            <Badge color="gold">{cashback.percentage}%</Badge>
          </div>

          <div className="flex items-center gap-2 mt-4 relative z-10">
            {[cd.h, cd.m, cd.s].map((v, i) => (
              <React.Fragment key={i}>
                <div className="glass px-3 py-2 text-center min-w-[54px]">
                  <p className="text-[22px] font-black tabular-nums">{v}</p>
                </div>
                {i < 2 && <span className="text-muted font-bold">:</span>}
              </React.Fragment>
            ))}
          </div>
          <div className="flex gap-3 mt-1 text-[10px] text-muted uppercase tracking-wide relative z-10">
            <span className="min-w-[54px] text-center">HRS</span>
            <span className="min-w-[54px] text-center">MIN</span>
            <span className="min-w-[54px] text-center">SEC</span>
          </div>

          <div className="flex items-center justify-between mt-4 relative z-10">
            <div>
              <p className="text-[11px] text-muted">Accumulated</p>
              <p className="text-[20px] font-black text-gold">{formatETB(cashback.accumulated)}</p>
            </div>
            <button
              onClick={claimCashback}
              disabled={!cashback.claimable}
              className="btn btn-gold !py-2.5 !px-5"
            >
              {cashback.claimable ? 'Claim' : 'Soon'}
            </button>
          </div>
        </GlassCard>
      )}

      {/* Streak */}
      {streak && (
        <GlassCard className="mt-4 !p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-danger/15 text-danger flex items-center justify-center">
                <IconFire size={16} />
              </span>
              <span className="text-[14px] font-bold">DAILY STREAK</span>
            </div>
            <Badge color="red">{streak.current} days</Badge>
          </div>

          <div className="flex gap-1.5 mt-4">
            {streak.days.map((d) => (
              <div key={d.date} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className={`w-full aspect-square rounded-xl flex items-center justify-center text-[11px] font-bold ${
                    d.state === 'completed'
                      ? 'bg-success/20 text-success border border-success/40'
                      : d.state === 'current'
                        ? 'bg-electric/20 text-electric border border-electric/50 animate-pulse'
                        : 'bg-white/5 text-muted border border-white/8'
                  }`}
                >
                  {d.state === 'completed' ? <IconCheck size={14} /> : d.reward}
                </div>
                <span className="text-[8px] text-muted">{d.label.split(' ')[0]}</span>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <div className="flex items-center justify-between text-[11px] text-muted mb-1.5">
              <span>Progress to next reward</span>
              <span className="text-gold font-bold">{formatETB(streak.next_reward)}</span>
            </div>
            <ProgressBar value={streak.current} max={7} />
          </div>

          <button onClick={claimStreak} className="btn btn-ghost w-full mt-4">
            Claim Today's Reward
          </button>
        </GlassCard>
      )}

      {/* Promo code */}
      <SectionHeader title="Have a Coupon?" />
      <GlassCard>
        <div className="flex gap-2">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="ENTER PROMO CODE"
            className="input flex-1 !uppercase"
          />
          <button onClick={redeem} disabled={redeeming} className="btn btn-primary !px-5">
            {redeeming ? '…' : 'Redeem'}
          </button>
        </div>
        <p className="text-[10px] text-muted mt-2">
          Try: TEMP100, WELCOME, EXPIRED, USED, VIPONLY
        </p>
      </GlassCard>

      {/* Promotions list */}
      <SectionHeader title="All Promotions" />
      {promos.length === 0 ? (
        <EmptyState icon="🎁" title="No promotions" message="Check back soon for new offers." />
      ) : (
        <div className="space-y-3">
          {promos.map((p) => (
            <div
              key={p.id}
              className="glass p-4 relative overflow-hidden"
              style={{ background: `linear-gradient(135deg, ${p.gradient[0]}22 0%, ${p.gradient[1]}11 100%)` }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-[15px] font-bold">{p.title}</h3>
                    {p.badge && <Badge color="gold">{p.badge}</Badge>}
                  </div>
                  <p className="text-[12px] text-muted mt-1">{p.description}</p>
                </div>
                <span
                  className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: `linear-gradient(135deg, ${p.gradient[0]}, ${p.gradient[1]})` }}
                >
                  <IconGift size={20} />
                </span>
              </div>
              <button
                onClick={() => {
                  haptic('light');
                  navigate('/');
                }}
                className="btn btn-ghost !py-2 !px-4 !text-[13px] mt-3"
              >
                {p.cta ?? 'View'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Quick links */}
      <SectionHeader title="More" />
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => navigate('/leaderboard')} className="glass p-4 flex items-center gap-3">
          <span className="w-9 h-9 rounded-full bg-gold/15 text-gold flex items-center justify-center">
            <IconTrophy size={18} />
          </span>
          <span className="text-[13px] font-semibold">Leaderboard</span>
        </button>
        <button onClick={() => navigate('/bets')} className="glass p-4 flex items-center gap-3">
          <span className="w-9 h-9 rounded-full bg-electric/15 text-electric flex items-center justify-center">
            <IconTicket size={18} />
          </span>
          <span className="text-[13px] font-semibold">My Bets</span>
        </button>
      </div>

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      <div className="h-6" />
    </div>
  );
}
