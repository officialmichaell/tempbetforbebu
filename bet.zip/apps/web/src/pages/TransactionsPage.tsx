import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { WalletTransaction } from '@temp/types';
import { api } from '@/lib/api';
import { formatSignedETB, timeAgo } from '@temp/utils';
import { LoadingState, EmptyState, Badge } from '@/components/ui';
import { IconChevronLeft } from '@/components/Icons';

const TYPE_LABEL: Record<string, string> = {
  deposit: 'Deposit',
  withdrawal: 'Withdrawal',
  bet_stake: 'Bet Stake',
  bet_win: 'Bet Win',
  bet_refund: 'Refund',
  bonus_credit: 'Bonus',
  cashback: 'Cashback',
  streak_reward: 'Streak',
  promo_credit: 'Promo',
  adjustment: 'Adjustment',
};

export function TransactionsPage() {
  const navigate = useNavigate();
  const [txs, setTxs] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    api.getTransactions().then(setTxs).finally(() => setLoading(false));
  }, []);

  const filtered = filter === 'all' ? txs : txs.filter((t) => t.type === filter);

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>
      <h1 className="text-[22px] font-black">Transactions</h1>

      <div className="flex gap-2 overflow-x-auto no-scrollbar mt-3 -mx-4 px-4">
        {['all', 'deposit', 'withdrawal', 'bet_stake', 'bet_win', 'cashback'].map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`chip ${filter === f ? 'chip-active' : ''}`}>
            {f === 'all' ? 'All' : TYPE_LABEL[f]}
          </button>
        ))}
      </div>

      <div className="mt-4 space-y-2">
        {loading ? (
          <LoadingState />
        ) : filtered.length === 0 ? (
          <EmptyState icon="🧾" title="No transactions" message="Nothing matches this filter." />
        ) : (
          filtered.map((t) => (
            <div key={t.id} className="glass p-3 flex items-center justify-between">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-[13px] font-semibold truncate">{t.description ?? TYPE_LABEL[t.type]}</p>
                  <Badge color="muted">{TYPE_LABEL[t.type]}</Badge>
                </div>
                <p className="text-[11px] text-muted mt-0.5">
                  {timeAgo(t.created_at)} · Balance {formatSignedETB(t.balance_after)}
                </p>
              </div>
              <span className={`text-[14px] font-bold ${t.amount >= 0 ? 'text-success' : 'text-danger'}`}>
                {formatSignedETB(t.amount)}
              </span>
            </div>
          ))
        )}
      </div>
      <div className="h-6" />
    </div>
  );
}
