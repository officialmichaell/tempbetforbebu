import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import type { Game } from '@temp/types';
import { api } from '@/lib/api';
import { useApp } from '@/store/AppContext';
import { formatETB } from '@temp/utils';
import { GlassCard, LoadingState, ErrorState, Badge, Toast } from '@/components/ui';
import { IconChevronLeft, IconPlay } from '@/components/Icons';
import { haptic } from '@/lib/telegram';

export function GamePlayPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { wallet, refreshWallet } = useApp();
  const [game, setGame] = useState<Game | null>(null);
  const [loading, setLoading] = useState(true);
  const [bet, setBet] = useState('50');
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    api.getGames().then((games) => {
      setGame(games.find((g) => g.id === id) ?? null);
    }).finally(() => setLoading(false));
  }, [id]);

  const play = async () => {
    const amt = parseFloat(bet);
    if (!amt || amt <= 0) return setToast({ msg: 'Enter a valid bet', type: 'error' });
    if (amt > (wallet?.balance ?? 0)) return setToast({ msg: 'Insufficient balance', type: 'error' });
    haptic('medium');
    setPlaying(true);
    // Demo outcome — server-authoritative in production
    setTimeout(async () => {
      const won = Math.random() > 0.5;
      const payout = won ? Math.round(amt * 1.9 * 100) / 100 : 0;
      setToast({
        msg: won ? `You won ${formatETB(payout)}! 🎉` : 'Better luck next time!',
        type: won ? 'success' : 'error',
      });
      haptic(won ? 'success' : 'error');
      setPlaying(false);
      setTimeout(() => setToast(null), 3000);
    }, 1400);
  };

  if (loading) return <div className="page"><LoadingState /></div>;
  if (!game) return <div className="page"><ErrorState title="Game not found" /></div>;

  return (
    <div className="page">
      <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-muted mt-4 mb-2">
        <IconChevronLeft size={18} /> Back
      </button>

      <div
        className="rounded-[22px] h-[220px] flex items-center justify-center relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${game.gradient[0]} 0%, ${game.gradient[1]} 100%)` }}
      >
        <div className="absolute inset-0 opacity-30" style={{ background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.4), transparent 60%)' }} />
        <span className="text-[80px] drop-shadow-2xl animate-float">{game.emoji}</span>
        {game.badge && <div className="absolute top-3 left-3"><Badge color="gold">{game.badge}</Badge></div>}
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-black">{game.title}</h1>
          <p className="text-[12px] text-muted">{game.provider} · RTP {game.rtp}%</p>
        </div>
        <Badge color="muted">DEMO</Badge>
      </div>

      <GlassCard className="mt-4">
        <label className="text-[12px] text-muted font-medium">Bet Amount (ETB)</label>
        <input
          type="number"
          inputMode="decimal"
          value={bet}
          onChange={(e) => setBet(e.target.value)}
          className="input mt-1.5 !text-[20px] !font-bold"
        />
        <div className="flex gap-2 mt-2">
          {[20, 50, 100, 500].map((v) => (
            <button key={v} onClick={() => setBet(String(v))} className="chip flex-1 text-center">
              {v}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between mt-3 text-[12px]">
          <span className="text-muted">Balance</span>
          <span className="font-bold">{formatETB(wallet?.balance ?? 0)}</span>
        </div>
      </GlassCard>

      <button onClick={play} disabled={playing} className="btn btn-primary w-full mt-4 !py-4 !text-[16px]">
        <IconPlay size={18} /> {playing ? 'Playing…' : 'PLAY DEMO'}
      </button>

      <p className="text-[10px] text-muted text-center mt-3">
        Demo game · Outcomes are simulated and not authoritative.
      </p>

      {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      <div className="h-6" />
    </div>
  );
}
