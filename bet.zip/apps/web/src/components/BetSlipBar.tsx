import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useApp } from '@/store/AppContext';
import { formatOdds, calcAccumulatorOdds, calcPotentialWin, formatETB } from '@temp/utils';
import { IconClose, IconChevronRight } from './Icons';
import { haptic } from '@/lib/telegram';
import { api } from '@/lib/api';
import { Toast } from './ui';

export function BetSlipBar() {
  const { betSlip, removeSelection, clearBetSlip, wallet, refreshWallet } = useApp();
  const [open, setOpen] = useState(false);
  const [stake, setStake] = useState('100');
  const [type, setType] = useState<'single' | 'accumulator'>('accumulator');
  const [placing, setPlacing] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  if (betSlip.length === 0) return null;

  const totalOdds =
    type === 'accumulator'
      ? calcAccumulatorOdds(betSlip.map((s) => s.odds))
      : betSlip[0].odds;
  const stakeNum = parseFloat(stake) || 0;
  const potential = calcPotentialWin(stakeNum, totalOdds);

  const place = async () => {
    haptic('medium');
    setPlacing(true);
    try {
      await api.placeBet(betSlip, stakeNum, type);
      await refreshWallet();
      haptic('success');
      setToast({ msg: 'Bet placed successfully!', type: 'success' });
      clearBetSlip();
      setOpen(false);
    } catch (e) {
      haptic('error');
      setToast({ msg: e instanceof Error ? e.message : 'Bet failed', type: 'error' });
    } finally {
      setPlacing(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  return (
    <>
      <AnimatePresence>
        {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
      </AnimatePresence>

      {/* Floating bar */}
      <AnimatePresence>
        {!open && (
          <motion.button
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            onClick={() => {
              haptic('light');
              setOpen(true);
            }}
            className="fixed left-1/2 -translate-x-1/2 z-[60] glass-strong px-4 py-3 flex items-center gap-3 w-[92%] max-w-[520px]"
            style={{ bottom: 'calc(72px + var(--safe-bottom))' }}
          >
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-electric to-purple flex items-center justify-center font-bold text-sm">
              {betSlip.length}
            </div>
            <div className="flex-1 text-left">
              <p className="text-[13px] font-bold">Bet Slip</p>
              <p className="text-[11px] text-muted">
                {betSlip.length} selection{betSlip.length > 1 ? 's' : ''} · Odds {formatOdds(totalOdds)}
              </p>
            </div>
            <IconChevronRight size={20} className="text-muted" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Bottom sheet */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 34 }}
              className="fixed bottom-0 left-0 right-0 z-[75] glass-strong rounded-t-[28px] max-h-[85vh] overflow-y-auto no-scrollbar"
              style={{ paddingBottom: 'calc(16px + var(--safe-bottom))' }}
            >
              <div className="sticky top-0 glass-strong px-5 pt-4 pb-3 rounded-t-[28px]">
                <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-3" />
                <div className="flex items-center justify-between">
                  <h3 className="text-[18px] font-extrabold">BET SLIP</h3>
                  <div className="flex items-center gap-2">
                    <button onClick={clearBetSlip} className="text-[12px] text-danger font-semibold">
                      Clear all
                    </button>
                    <button onClick={() => setOpen(false)} aria-label="Close" className="text-muted">
                      <IconClose size={20} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="px-5 space-y-3">
                {betSlip.map((s) => (
                  <div key={s.event_id} className="glass p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-[13px] font-semibold truncate">{s.event_label}</p>
                        <p className="text-[11px] text-muted">
                          {s.market_name} · <span className="text-bright">{s.selection_name}</span>
                        </p>
                      </div>
                      <button
                        onClick={() => removeSelection(s.event_id)}
                        aria-label="Remove selection"
                        className="text-muted hover:text-danger"
                      >
                        <IconClose size={16} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[11px] text-muted">Odds</span>
                      <span className="text-[15px] font-bold text-bright">{formatOdds(s.odds)}</span>
                    </div>
                  </div>
                ))}

                {/* Bet type */}
                <div className="flex gap-2">
                  <button
                    onClick={() => setType('single')}
                    className={`chip flex-1 text-center ${type === 'single' ? 'chip-active' : ''}`}
                  >
                    Single
                  </button>
                  <button
                    onClick={() => setType('accumulator')}
                    className={`chip flex-1 text-center ${type === 'accumulator' ? 'chip-active' : ''}`}
                  >
                    Accumulator
                  </button>
                </div>

                {/* Stake */}
                <div>
                  <label className="text-[12px] text-muted font-medium">Stake (ETB)</label>
                  <div className="flex gap-2 mt-1.5">
                    <input
                      type="number"
                      inputMode="decimal"
                      value={stake}
                      onChange={(e) => setStake(e.target.value)}
                      className="input flex-1"
                      placeholder="0.00"
                    />
                    {[50, 100, 500].map((v) => (
                      <button
                        key={v}
                        onClick={() => setStake(String(v))}
                        className="chip !px-3"
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Summary */}
                <div className="glass p-3 space-y-2">
                  <Row label="Total Odds" value={formatOdds(totalOdds)} />
                  <Row label="Stake" value={formatETB(stakeNum)} />
                  <div className="h-px bg-white/8" />
                  <Row label="Potential Win" value={formatETB(potential)} accent="text-success" big />
                  <Row label="Balance" value={formatETB(wallet?.balance ?? 0)} muted />
                </div>

                <button
                  onClick={place}
                  disabled={placing || stakeNum <= 0 || stakeNum > (wallet?.balance ?? 0)}
                  className="btn btn-primary w-full !py-3.5 !text-[16px]"
                >
                  {placing ? 'Placing…' : 'PLACE BET'}
                </button>
                <p className="text-[10px] text-muted text-center pb-2">
                  Demo mode · No real money is wagered. Odds are simulated.
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

function Row({
  label,
  value,
  accent,
  muted,
  big,
}: {
  label: string;
  value: string;
  accent?: string;
  muted?: boolean;
  big?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className={`text-[12px] ${muted ? 'text-muted' : 'text-muted'}`}>{label}</span>
      <span className={`${big ? 'text-[17px]' : 'text-[14px]'} font-bold ${accent ?? ''}`}>{value}</span>
    </div>
  );
}
