import React from 'react';
import { motion } from 'framer-motion';
import { useApp } from '@/store/AppContext';
import { formatETB } from '@temp/utils';
import { IconEye, IconEyeOff, IconPlus, IconBell } from './Icons';
import { useNavigate } from 'react-router-dom';

export function Logo({ size = 34 }: { size?: number }) {
  return (
    <div
      className="relative flex items-center justify-center rounded-[12px] font-black"
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(135deg, #2196FF 0%, #8B5CF6 100%)',
        boxShadow: '0 6px 20px rgba(33,150,255,0.4)',
        fontSize: size * 0.55,
      }}
      aria-label="TemP logo"
    >
      P
    </div>
  );
}

export function Header() {
  const { wallet, balanceHidden, toggleBalance, user, unreadCount } = useApp();
  const navigate = useNavigate();

  return (
    <header
      className="sticky top-0 z-40 glass-nav"
      style={{ paddingTop: 'var(--safe-top)' }}
    >
      <div className="page flex items-center gap-3 py-3">
        <Logo />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-muted uppercase tracking-wide">Balance</span>
          </div>
          <div className="flex items-center gap-2">
            <motion.span
              key={balanceHidden ? 'hidden' : wallet?.balance}
              initial={{ opacity: 0.4, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-[18px] font-extrabold tracking-tight"
            >
              {balanceHidden ? '••••••' : formatETB(wallet?.balance ?? 0)}
            </motion.span>
            <button
              onClick={toggleBalance}
              aria-label={balanceHidden ? 'Show balance' : 'Hide balance'}
              className="text-muted hover:text-white transition-colors"
            >
              {balanceHidden ? <IconEyeOff size={16} /> : <IconEye size={16} />}
            </button>
          </div>
        </div>

        <button
          onClick={() => navigate('/notifications')}
          className="relative w-9 h-9 rounded-full glass flex items-center justify-center"
          aria-label="Notifications"
        >
          <IconBell size={18} />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-danger text-[10px] font-bold flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>

        <button
          onClick={() => navigate('/deposit')}
          className="btn btn-primary !py-2 !px-3 !text-[13px] !rounded-xl"
        >
          <IconPlus size={15} /> Deposit
        </button>

        <button
          onClick={() => navigate('/profile')}
          className="w-9 h-9 rounded-full overflow-hidden border border-white/15 flex items-center justify-center bg-gradient-to-br from-electric to-purple text-[13px] font-bold"
          aria-label="Profile"
        >
          {user?.avatar_url ? (
            <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
          ) : (
            (user?.first_name?.[0] ?? 'U').toUpperCase()
          )}
        </button>
      </div>
    </header>
  );
}
