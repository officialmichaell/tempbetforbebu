import React from 'react';
import { motion } from 'framer-motion';
import type { Game } from '@temp/types';
import { useApp } from '@/store/AppContext';
import { IconHeart, IconPlay } from './Icons';
import { Badge } from './ui';
import { haptic } from '@/lib/telegram';
import { useNavigate } from 'react-router-dom';

export function GameCard({ game, index = 0 }: { game: Game; index?: number }) {
  const { favorites, toggleFavorite } = useApp();
  const navigate = useNavigate();
  const fav = favorites.has(game.id);

  const badgeColor =
    game.badge === 'HOT' ? 'red' : game.badge === 'NEW' ? 'green' : game.badge === 'TOP' ? 'gold' : 'blue';

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.3) }}
      whileTap={{ scale: 0.97 }}
      className="relative rounded-[18px] overflow-hidden glass group"
    >
      {/* Artwork */}
      <div
        className="relative h-[110px] flex items-center justify-center"
        style={{ background: `linear-gradient(135deg, ${game.gradient[0]} 0%, ${game.gradient[1]} 100%)` }}
      >
        <div className="absolute inset-0 opacity-30" style={{ background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.4), transparent 60%)' }} />
        <span className="text-[42px] drop-shadow-lg select-none">{game.emoji}</span>

        {game.badge && (
          <div className="absolute top-2 left-2">
            <Badge color={badgeColor as any}>{game.badge}</Badge>
          </div>
        )}

        <button
          onClick={(e) => {
            e.stopPropagation();
            haptic('light');
            toggleFavorite(game.id);
          }}
          aria-label={fav ? 'Remove from favorites' : 'Add to favorites'}
          className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/35 backdrop-blur flex items-center justify-center"
        >
          <IconHeart size={14} filled={fav} className={fav ? 'text-danger' : 'text-white'} />
        </button>

        {game.coming_soon && (
          <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px] flex items-center justify-center">
            <span className="text-[11px] font-black tracking-widest text-white/90 border border-white/30 px-3 py-1 rounded-full">
              COMING SOON
            </span>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-2.5">
        <p className="text-[13px] font-bold truncate">{game.title}</p>
        <p className="text-[10px] text-muted truncate">{game.provider}</p>
        <button
          disabled={game.coming_soon}
          onClick={() => {
            if (game.coming_soon) return;
            haptic('medium');
            navigate(`/game/${game.id}`);
          }}
          className={`mt-2 w-full flex items-center justify-center gap-1.5 text-[12px] font-bold py-1.5 rounded-lg transition-colors ${
            game.coming_soon
              ? 'bg-white/5 text-muted cursor-not-allowed'
              : 'bg-gradient-to-r from-electric to-purple text-white'
          }`}
        >
          {!game.coming_soon && <IconPlay size={12} />}
          {game.coming_soon ? 'Soon' : 'Play'}
        </button>
      </div>
    </motion.div>
  );
}
