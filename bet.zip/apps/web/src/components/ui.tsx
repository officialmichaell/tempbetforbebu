import React from 'react';
import { motion } from 'framer-motion';
import { classNames } from '@temp/utils';
import { IconAlert, IconInfo } from './Icons';

export function GlassCard({
  children,
  className,
  onClick,
  as = 'div',
}: {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  as?: 'div' | 'button';
}) {
  const Comp: any = as === 'button' ? motion.button : motion.div;
  return (
    <Comp
      onClick={onClick}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      className={classNames('glass p-4', className)}
    >
      {children}
    </Comp>
  );
}

export function SectionHeader({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex items-center justify-between mb-3 mt-6">
      <h2 className="text-[17px] font-bold tracking-tight">{title}</h2>
      {action && (
        <button onClick={onAction} className="text-[13px] font-semibold text-electric">
          {action}
        </button>
      )}
    </div>
  );
}

export function Badge({
  children,
  color = 'blue',
}: {
  children: React.ReactNode;
  color?: 'blue' | 'gold' | 'green' | 'red' | 'purple' | 'cyan' | 'muted';
}) {
  const map: Record<string, string> = {
    blue: 'bg-electric/20 text-bright',
    gold: 'bg-gold/20 text-gold',
    green: 'bg-success/20 text-success',
    red: 'bg-danger/20 text-danger',
    purple: 'bg-purple/20 text-purple',
    cyan: 'bg-cyan/20 text-cyan',
    muted: 'bg-white/10 text-muted',
  };
  return <span className={classNames('badge', map[color])}>{children}</span>;
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={classNames('skeleton rounded-xl', className)} />;
}

export function LoadingState({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3">
      <div className="w-9 h-9 rounded-full border-2 border-white/10 border-t-electric animate-spin" />
      <p className="text-sm text-muted">{label}</p>
    </div>
  );
}

export function EmptyState({
  icon = '📭',
  title,
  message,
  action,
  onAction,
}: {
  icon?: string;
  title: string;
  message?: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-14 px-6 text-center">
      <div className="text-4xl mb-3 opacity-80">{icon}</div>
      <h3 className="font-bold text-[16px]">{title}</h3>
      {message && <p className="text-sm text-muted mt-1 max-w-xs">{message}</p>}
      {action && (
        <button onClick={onAction} className="btn btn-primary mt-5">
          {action}
        </button>
      )}
    </div>
  );
}

export function ErrorState({
  title = 'Something went wrong',
  message = 'Please try again.',
  onRetry,
}: {
  title?: string;
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-14 px-6 text-center">
      <div className="w-12 h-12 rounded-full bg-danger/15 flex items-center justify-center text-danger mb-3">
        <IconAlert size={24} />
      </div>
      <h3 className="font-bold text-[16px]">{title}</h3>
      <p className="text-sm text-muted mt-1 max-w-xs">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn btn-ghost mt-5">
          Retry
        </button>
      )}
    </div>
  );
}

export function Toast({
  message,
  type = 'info',
  onClose,
}: {
  message: string;
  type?: 'info' | 'success' | 'error';
  onClose?: () => void;
}) {
  const colors = {
    info: 'border-electric/40 bg-electric/10',
    success: 'border-success/40 bg-success/10',
    error: 'border-danger/40 bg-danger/10',
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className={classNames(
        'fixed left-1/2 -translate-x-1/2 bottom-24 z-[80] glass-strong px-4 py-3 flex items-center gap-2 max-w-[90%]',
        colors[type],
      )}
      onClick={onClose}
    >
      <IconInfo size={18} />
      <span className="text-sm font-medium">{message}</span>
    </motion.div>
  );
}

export function ProgressBar({ value, max = 100 }: { value: number; max?: number }) {
  const pct = Math.min(100, (value / max) * 100);
  return (
    <div className="h-2 rounded-full bg-white/8 overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="h-full rounded-full bg-gradient-to-r from-electric to-purple"
      />
    </div>
  );
}

export function StatTile({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent?: string;
}) {
  return (
    <div className="glass p-3 flex-1 min-w-0">
      <p className="text-[11px] text-muted uppercase tracking-wide">{label}</p>
      <p className={classNames('text-[17px] font-bold mt-1 truncate', accent)}>{value}</p>
    </div>
  );
}
