import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useApp } from '@/store/AppContext';
import { classNames } from '@temp/utils';
import { IconGames, IconPromo, IconContact, IconProfile } from './Icons';
import { haptic } from '@/lib/telegram';

const TABS = [
  { to: '/', label: 'Games', Icon: IconGames, end: true },
  { to: '/promo', label: 'Promo', Icon: IconPromo, badge: true },
  { to: '/contact', label: 'Contact', Icon: IconContact },
  { to: '/profile', label: 'Profile', Icon: IconProfile },
];

export function BottomNav() {
  const { unreadCount } = useApp();
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 glass-nav"
      style={{ paddingBottom: 'var(--safe-bottom)' }}
      aria-label="Primary navigation"
    >
      <div className="page flex items-center justify-around py-2">
        {TABS.map(({ to, label, Icon, end, badge }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            onClick={() => haptic('select')}
            className="relative flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl"
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <motion.div
                    layoutId="nav-pill"
                    className="absolute inset-0 rounded-xl bg-white/8"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  />
                )}
                <span className={classNames('relative z-10', isActive ? 'text-electric' : 'text-muted')}>
                  <Icon size={22} />
                  {badge && unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1.5 min-w-[15px] h-[15px] px-1 rounded-full bg-danger text-[9px] font-bold flex items-center justify-center text-white">
                      {unreadCount}
                    </span>
                  )}
                </span>
                <span
                  className={classNames(
                    'relative z-10 text-[10px] font-semibold',
                    isActive ? 'text-white' : 'text-muted',
                  )}
                >
                  {label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
