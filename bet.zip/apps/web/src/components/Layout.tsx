import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Header } from './Header';
import { BottomNav } from './BottomNav';
import { BetSlipBar } from './BetSlipBar';

export function Layout() {
  const location = useLocation();
  return (
    <div className="min-h-screen flex flex-col">
      <div className="app-bg" />
      <Header />
      <main className="flex-1 pb-28">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
      <BetSlipBar />
      <BottomNav />
    </div>
  );
}
