import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BANNERS } from '@/lib/mockData';
import { IconChevronLeft, IconChevronRight } from './Icons';
import { haptic } from '@/lib/telegram';

export function HeroCarousel({ onCta }: { onCta?: (id: string) => void }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchX = useRef<number | null>(null);

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % BANNERS.length), 4500);
    return () => clearInterval(t);
  }, [paused]);

  const go = (dir: number) => {
    haptic('light');
    setIndex((i) => (i + dir + BANNERS.length) % BANNERS.length);
  };

  const banner = BANNERS[index];

  return (
    <div
      className="relative mt-4"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={(e) => (touchX.current = e.touches[0].clientX)}
      onTouchEnd={(e) => {
        if (touchX.current === null) return;
        const dx = e.changedTouches[0].clientX - touchX.current;
        if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
        touchX.current = null;
      }}
    >
      <div className="relative h-[168px] rounded-[22px] overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={banner.id}
            initial={{ opacity: 0, scale: 1.04 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.4 }}
            className="absolute inset-0 p-5 flex flex-col justify-between"
            style={{
              background: `linear-gradient(135deg, ${banner.gradient[0]} 0%, ${banner.gradient[1]} 100%)`,
            }}
          >
            {/* decorative artwork */}
            <div className="absolute -right-6 -top-8 w-40 h-40 rounded-full bg-white/10 blur-2xl" />
            <div className="absolute right-4 bottom-2 text-[80px] opacity-20 select-none">
              {banner.id === 'b1' ? '🎮' : banner.id === 'b2' ? '💰' : banner.id === 'b3' ? '🏆' : '🚀'}
            </div>

            <div className="relative z-10">
              <span className="badge bg-black/30 text-white backdrop-blur">{banner.badge}</span>
              <h2 className="text-[24px] font-black mt-2 leading-tight drop-shadow">{banner.title}</h2>
              <p className="text-[13px] text-white/85 mt-0.5">{banner.subtitle}</p>
            </div>
            <button
              onClick={() => {
                haptic('medium');
                onCta?.(banner.id);
              }}
              className="relative z-10 self-start bg-white text-black font-bold text-[13px] px-4 py-2 rounded-xl active:scale-95 transition-transform"
            >
              {banner.cta}
            </button>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Controls */}
      <button
        onClick={() => go(-1)}
        aria-label="Previous banner"
        className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white/90"
      >
        <IconChevronLeft size={18} />
      </button>
      <button
        onClick={() => go(1)}
        aria-label="Next banner"
        className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur flex items-center justify-center text-white/90"
      >
        <IconChevronRight size={18} />
      </button>

      {/* Pagination */}
      <div className="flex items-center justify-center gap-1.5 mt-3">
        {BANNERS.map((b, i) => (
          <button
            key={b.id}
            onClick={() => setIndex(i)}
            aria-label={`Go to banner ${i + 1}`}
            className={`h-1.5 rounded-full transition-all ${
              i === index ? 'w-6 bg-electric' : 'w-1.5 bg-white/25'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
