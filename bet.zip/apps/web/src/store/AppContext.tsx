import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import type { User, Wallet, BetSelection, AppNotification } from '@temp/types';
import { api } from '@/lib/api';
import { initTelegram } from '@/lib/telegram';

interface AppState {
  ready: boolean;
  authError: string | null;
  user: User | null;
  wallet: Wallet | null;
  balanceHidden: boolean;
  toggleBalance: () => void;
  refreshWallet: () => Promise<void>;
  // bet slip
  betSlip: BetSelection[];
  addSelection: (s: BetSelection) => void;
  removeSelection: (id: string) => void;
  clearBetSlip: () => void;
  isSelected: (id: string) => boolean;
  // favorites
  favorites: Set<string>;
  toggleFavorite: (id: string) => void;
  // notifications
  notifications: AppNotification[];
  unreadCount: number;
  refreshNotifications: () => Promise<void>;
  markRead: (id: string) => Promise<void>;
  markAllRead: () => Promise<void>;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [balanceHidden, setBalanceHidden] = useState(false);
  const [betSlip, setBetSlip] = useState<BetSelection[]>([]);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        initTelegram();
        const { user: u } = await api.authTelegram();
        const w = await api.getWallet();
        const n = await api.getNotifications();
        if (!mounted) return;
        setUser(u);
        setWallet(w);
        setNotifications(n);
      } catch (e) {
        if (mounted) setAuthError(e instanceof Error ? e.message : 'Authentication failed');
      } finally {
        if (mounted) setReady(true);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const refreshWallet = useCallback(async () => {
    const w = await api.getWallet();
    setWallet(w);
  }, []);

  const refreshNotifications = useCallback(async () => {
    const n = await api.getNotifications();
    setNotifications(n);
  }, []);

  const addSelection = useCallback((s: BetSelection) => {
    setBetSlip((prev) => {
      const filtered = prev.filter((x) => x.event_id !== s.event_id);
      return [...filtered, s];
    });
  }, []);

  const removeSelection = useCallback((id: string) => {
    setBetSlip((prev) => prev.filter((x) => x.event_id !== id));
  }, []);

  const clearBetSlip = useCallback(() => setBetSlip([]), []);

  const isSelected = useCallback(
    (id: string) => betSlip.some((s) => s.event_id === id),
    [betSlip],
  );

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const markRead = useCallback(async (id: string) => {
    await api.markNotificationRead(id);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const markAllRead = useCallback(async () => {
    await api.markAllRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const unreadCount = useMemo(() => notifications.filter((n) => !n.read).length, [notifications]);

  const value: AppState = {
    ready,
    authError,
    user,
    wallet,
    balanceHidden,
    toggleBalance: () => setBalanceHidden((v) => !v),
    refreshWallet,
    betSlip,
    addSelection,
    removeSelection,
    clearBetSlip,
    isSelected,
    favorites,
    toggleFavorite,
    notifications,
    unreadCount,
    refreshNotifications,
    markRead,
    markAllRead,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
