import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { useApp } from './store/AppContext';
import { Layout } from './components/Layout';
import { LoadingState, ErrorState } from './components/ui';
import { GamesPage } from './pages/GamesPage';
import { PromoPage } from './pages/PromoPage';
import { ContactPage } from './pages/ContactPage';
import { ProfilePage } from './pages/ProfilePage';
import { SportsbookPage } from './pages/SportsbookPage';
import { EventDetailPage } from './pages/EventDetailPage';
import { WalletPage } from './pages/WalletPage';
import { DepositPage } from './pages/DepositPage';
import { WithdrawPage } from './pages/WithdrawPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { BetHistoryPage } from './pages/BetHistoryPage';
import { SettingsPage } from './pages/SettingsPage';
import { ResponsibleGamingPage } from './pages/ResponsibleGamingPage';
import { GamePlayPage } from './pages/GamePlayPage';
import { SupportTicketPage } from './pages/SupportTicketPage';

export function App() {
  const { ready, authError } = useApp();

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="app-bg" />
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-electric to-purple flex items-center justify-center text-3xl font-black mx-auto mb-4 animate-float">
            P
          </div>
          <LoadingState label="Connecting to Telegram…" />
        </div>
      </div>
    );
  }

  if (authError) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="app-bg" />
        <ErrorState title="Authentication error" message={authError} onRetry={() => location.reload()} />
      </div>
    );
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<GamesPage />} />
        <Route path="/promo" element={<PromoPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/sportsbook" element={<SportsbookPage />} />
        <Route path="/event/:id" element={<EventDetailPage />} />
        <Route path="/wallet" element={<WalletPage />} />
        <Route path="/deposit" element={<DepositPage />} />
        <Route path="/withdraw" element={<WithdrawPage />} />
        <Route path="/transactions" element={<TransactionsPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/leaderboard" element={<LeaderboardPage />} />
        <Route path="/bets" element={<BetHistoryPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/responsible-gaming" element={<ResponsibleGamingPage />} />
        <Route path="/game/:id" element={<GamePlayPage />} />
        <Route path="/support/ticket" element={<SupportTicketPage />} />
      </Route>
    </Routes>
  );
}
