/**
 * @temp/config — Shared design tokens & feature flags.
 */

export const colors = {
  deepBlack: '#080B10',
  darkNavy: '#0D1420',
  darkSurface: '#111927',
  glass: 'rgba(255,255,255,0.05)',
  glassBorder: 'rgba(255,255,255,0.08)',
  electricBlue: '#2196FF',
  brightBlue: '#3B9CFF',
  purple: '#8B5CF6',
  cyan: '#22D3EE',
  success: '#22C55E',
  danger: '#EF4444',
  rewardGold: '#F5C518',
  white: '#FFFFFF',
  muted: '#94A3B8',
} as const;

export const glass = {
  background: 'rgba(255,255,255,0.05)',
  backdropFilter: 'blur(20px)',
  border: '1px solid rgba(255,255,255,0.08)',
  boxShadow: '0 10px 40px rgba(0,0,0,0.25)',
  borderRadius: '20px',
} as const;

export const radius = {
  sm: '10px',
  md: '14px',
  lg: '20px',
  xl: '28px',
  pill: '999px',
} as const;

export const spacing = {
  xs: '4px',
  sm: '8px',
  md: '12px',
  lg: '16px',
  xl: '24px',
  xxl: '32px',
} as const;

export const typography = {
  fontFamily:
    "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
  sizes: {
    xs: '11px',
    sm: '13px',
    md: '15px',
    lg: '18px',
    xl: '22px',
    xxl: '28px',
    display: '34px',
  },
} as const;

export const gradients = {
  brand: 'linear-gradient(135deg, #2196FF 0%, #8B5CF6 100%)',
  blueCyan: 'linear-gradient(135deg, #2196FF 0%, #22D3EE 100%)',
  gold: 'linear-gradient(135deg, #F5C518 0%, #FF8A00 100%)',
  success: 'linear-gradient(135deg, #22C55E 0%, #16A34A 100%)',
  danger: 'linear-gradient(135deg, #EF4444 0%, #B91C1C 100%)',
  surface: 'linear-gradient(180deg, #0D1420 0%, #080B10 100%)',
} as const;

export interface FeatureFlags {
  ENABLE_TELEGRAM_AUTH: boolean;
  ENABLE_MOCK_BETTING: boolean;
  ENABLE_MOCK_WALLET: boolean;
  ENABLE_REAL_BETTING: boolean;
  ENABLE_REAL_PAYMENTS: boolean;
  ENABLE_WITHDRAWALS: boolean;
  ENABLE_CASINO: boolean;
  ENABLE_SPORTSBOOK: boolean;
  REAL_MONEY_ENABLED: boolean;
  PRODUCTION_BETTING_ENABLED: boolean;
  PAYMENTS_ENABLED: boolean;
}

export const defaultFeatureFlags: FeatureFlags = {
  ENABLE_TELEGRAM_AUTH: true,
  ENABLE_MOCK_BETTING: true,
  ENABLE_MOCK_WALLET: true,
  ENABLE_REAL_BETTING: false,
  ENABLE_REAL_PAYMENTS: false,
  ENABLE_WITHDRAWALS: true,
  ENABLE_CASINO: true,
  ENABLE_SPORTSBOOK: true,
  REAL_MONEY_ENABLED: false,
  PRODUCTION_BETTING_ENABLED: false,
  PAYMENTS_ENABLED: false,
};

export const brand = {
  name: 'TemP',
  letter: 'P',
  currency: 'ETB',
  market: 'Ethiopia',
} as const;
