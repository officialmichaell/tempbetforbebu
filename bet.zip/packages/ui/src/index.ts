/**
 * @temp/ui — Shared design-system primitives for TemP.
 *
 * These are framework-light helpers and token re-exports shared between the
 * Mini App (apps/web) and the Admin panel (apps/admin). App-specific React
 * components live in each app; this package holds the cross-cutting pieces so
 * both surfaces stay visually consistent.
 */

export { colors, glass, radius, spacing, typography, gradients, brand } from '@temp/config';
export { classNames } from '@temp/utils';

/** Inline style object for a glass surface (used with React `style` prop). */
export const glassStyle = {
  background: 'rgba(255,255,255,0.05)',
  backdropFilter: 'blur(20px)',
  WebkitBackdropFilter: 'blur(20px)',
  border: '1px solid rgba(255,255,255,0.08)',
  boxShadow: '0 10px 40px rgba(0,0,0,0.25)',
  borderRadius: '20px',
} as const;

/** Semantic tone → color mapping used by pills, badges and stat tiles. */
export const toneColor = {
  neutral: '#94A3B8',
  info: '#2196FF',
  success: '#22C55E',
  warning: '#F5C518',
  danger: '#EF4444',
  reward: '#F5C518',
  purple: '#8B5CF6',
  cyan: '#22D3EE',
} as const;

export type Tone = keyof typeof toneColor;

/** Map a domain status string to a semantic tone. */
export function statusTone(status: string): Tone {
  const s = status.toUpperCase();
  if (['APPROVED', 'COMPLETED', 'WON', 'ACTIVE', 'PAID'].includes(s)) return 'success';
  if (['PENDING', 'REQUESTED', 'UNDER_REVIEW', 'PROCESSING', 'OPEN'].includes(s)) return 'warning';
  if (['REJECTED', 'CANCELLED', 'LOST', 'FAILED', 'SUSPENDED'].includes(s)) return 'danger';
  if (['AGENT_CONFIRMED', 'CONFIRMED'].includes(s)) return 'info';
  return 'neutral';
}

/** Human-friendly label for a snake/upper status string. */
export function statusLabel(status: string): string {
  return status
    .toLowerCase()
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/** Responsive breakpoints shared across apps. */
export const breakpoints = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
} as const;

/** Z-index scale to keep overlays predictable. */
export const zIndex = {
  base: 0,
  header: 40,
  bottomNav: 40,
  betSlipBar: 45,
  sheet: 60,
  modal: 70,
  toast: 80,
} as const;
