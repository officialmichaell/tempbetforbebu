/**
 * @temp/types — Shared domain types for the TemP platform.
 * These types are consumed by web, api and admin apps.
 */

export type ID = string;

export type UserStatus = 'active' | 'restricted' | 'suspended' | 'self_excluded' | 'pending';

export interface User {
  id: ID;
  telegram_id: string;
  telegram_username?: string | null;
  first_name: string;
  last_name?: string | null;
  phone?: string | null;
  avatar_url?: string | null;
  status: UserStatus;
  language?: string;
  created_at: string;
  updated_at: string;
}

export interface Wallet {
  id: ID;
  user_id: ID;
  balance: number;        // derived from ledger (available)
  bonus_balance: number;
  pending_balance: number;
  currency: 'ETB';
  updated_at: string;
}

export type TransactionType =
  | 'deposit'
  | 'withdrawal'
  | 'bet_stake'
  | 'bet_win'
  | 'bet_refund'
  | 'bonus_credit'
  | 'cashback'
  | 'streak_reward'
  | 'promo_credit'
  | 'adjustment';

export interface WalletTransaction {
  id: ID;
  wallet_id: ID;
  user_id: ID;
  type: TransactionType;
  amount: number;         // signed
  balance_after: number;
  reference?: string | null;
  idempotency_key?: string | null;
  description?: string;
  created_at: string;
}

export type DepositState =
  | 'PENDING'
  | 'AGENT_CONFIRMED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED';

export interface Deposit {
  id: ID;
  user_id: ID;
  agent_id?: ID | null;
  amount: number;
  method: string;
  state: DepositState;
  reference?: string | null;
  note?: string | null;
  created_at: string;
  updated_at: string;
}

export type WithdrawalState =
  | 'REQUESTED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'REJECTED'
  | 'CANCELLED';

export interface Withdrawal {
  id: ID;
  user_id: ID;
  amount: number;
  method: string;
  account: string;
  state: WithdrawalState;
  note?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Agent {
  id: ID;
  name: string;
  telegram_username?: string | null;
  phone?: string | null;
  status: 'active' | 'inactive';
  created_at: string;
}

export interface AgentTransaction {
  id: ID;
  agent_id: ID;
  deposit_id?: ID | null;
  amount: number;
  type: 'deposit_confirm' | 'commission' | 'adjustment';
  created_at: string;
}

// --- Sportsbook -----------------------------------------------------------

export interface Sport {
  id: ID;
  key: string;
  name: string;
  icon: string;
  event_count: number;
}

export interface League {
  id: ID;
  sport_id: ID;
  name: string;
  country?: string;
}

export interface Event {
  id: ID;
  sport_id: ID;
  league_id: ID;
  league_name: string;
  home: string;
  away: string;
  start_time: string;
  is_live: boolean;
  live_score?: { home: number; away: number; minute?: number } | null;
  markets: Market[];
}

export interface Market {
  id: ID;
  event_id: ID;
  name: string;
  selections: Selection[];
}

export interface Selection {
  id: ID;
  market_id: ID;
  name: string;
  odds: number;
  active: boolean;
}

export interface BetSelection {
  event_id: ID;
  event_label: string;
  market_name: string;
  selection_name: string;
  odds: number;
}

export type BetType = 'single' | 'accumulator';
export type BetState = 'pending' | 'won' | 'lost' | 'void' | 'cashed_out';

export interface Bet {
  id: ID;
  user_id: ID;
  type: BetType;
  stake: number;
  total_odds: number;
  potential_win: number;
  state: BetState;
  payout?: number | null;
  selections: BetSelection[];
  created_at: string;
}

// --- Games ----------------------------------------------------------------

export type GameCategory =
  | 'Sports'
  | 'Live'
  | 'Casino'
  | 'Crash'
  | 'Slots'
  | 'Table Games'
  | 'Lottery'
  | 'Popular'
  | 'New';

export interface Game {
  id: ID;
  slug: string;
  title: string;
  category: GameCategory;
  provider: string;
  badge?: 'NEW' | 'HOT' | 'TOP' | 'LIVE' | null;
  coming_soon: boolean;
  gradient: [string, string];
  emoji: string;
  rtp?: number;
}

export interface GameSession {
  id: ID;
  user_id: ID;
  game_id: ID;
  started_at: string;
  ended_at?: string | null;
  bet_total: number;
  win_total: number;
}

// --- Promotions -----------------------------------------------------------

export interface Promotion {
  id: ID;
  title: string;
  description: string;
  category: 'welcome' | 'daily' | 'cashback' | 'freebet' | 'deposit' | 'tournament' | 'mission' | 'reward';
  badge?: string;
  cta?: string;
  gradient: [string, string];
  active: boolean;
}

export type PromoCodeState = 'success' | 'invalid' | 'expired' | 'already_used' | 'not_eligible';

export interface PromoCode {
  id: ID;
  code: string;
  reward: number;
  state: PromoCodeState;
  expires_at?: string | null;
}

export interface Cashback {
  percentage: number;
  accumulated: number;
  claimable: boolean;
  next_claim_at: string;
  history: { id: ID; amount: number; claimed_at: string }[];
}

export interface StreakDay {
  date: string;
  label: string;
  state: 'completed' | 'current' | 'locked';
  reward: number;
}

export interface Streak {
  current: number;
  best: number;
  days: StreakDay[];
  next_reward: number;
}

export interface LeaderboardEntry {
  rank: number;
  user_id: ID;
  username: string;
  avatar_url?: string | null;
  points: number;
  winnings: number;
  is_current_user?: boolean;
}

// --- Notifications & Support ---------------------------------------------

export type NotificationType =
  | 'deposit' | 'withdrawal' | 'bet_result' | 'promotion'
  | 'bonus' | 'cashback' | 'streak' | 'system';

export interface AppNotification {
  id: ID;
  type: NotificationType;
  title: string;
  body: string;
  read: boolean;
  created_at: string;
}

export type TicketState = 'open' | 'pending' | 'resolved' | 'closed';

export interface SupportTicket {
  id: ID;
  user_id: ID;
  subject: string;
  category: string;
  message: string;
  state: TicketState;
  created_at: string;
  updated_at: string;
}

// --- Admin ----------------------------------------------------------------

export type AdminRole = 'super_admin' | 'admin' | 'finance' | 'support' | 'agent_manager';

export interface AdminUser {
  id: ID;
  email: string;
  name: string;
  role: AdminRole;
  two_factor_enabled: boolean;
  created_at: string;
}

export interface AuditLog {
  id: ID;
  actor: string;
  action: string;
  entity: string;
  entity_id: ID;
  meta?: Record<string, unknown>;
  created_at: string;
}

// --- API envelopes --------------------------------------------------------

export interface ApiError {
  statusCode: number;
  message: string;
  error?: string;
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}
