/**
 * @temp/utils — Shared helpers.
 */

export function formatETB(amount: number, opts: { compact?: boolean } = {}): string {
  if (opts.compact) {
    const abs = Math.abs(amount);
    if (abs >= 1_000_000) return `${(amount / 1_000_000).toFixed(1)}M ETB`;
    if (abs >= 1_000) return `${(amount / 1_000).toFixed(1)}K ETB`;
  }
  return `${amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })} ETB`;
}

export function formatSignedETB(amount: number): string {
  const sign = amount > 0 ? '+' : amount < 0 ? '-' : '';
  return `${sign}${formatETB(Math.abs(amount))}`;
}

export function formatOdds(odds: number): string {
  return odds.toFixed(2);
}

export function calcAccumulatorOdds(odds: number[]): number {
  if (!odds || odds.length === 0) return 0;
  return odds.reduce((acc, o) => acc * o, 1);
}

export function calcPotentialWin(stake: number, odds: number): number {
  return Math.round(stake * odds * 100) / 100;
}

/** Deterministic pseudo-random generator (mulberry32) for stable seed data. */
export function seededRandom(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function pick<T>(arr: T[], rng: () => number): T {
  return arr[Math.floor(rng() * arr.length)];
}

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export function countdownParts(target: string | number): { h: string; m: string; s: string } {
  const t = typeof target === 'string' ? new Date(target).getTime() : target;
  let diff = Math.max(0, Math.floor((t - Date.now()) / 1000));
  const h = Math.floor(diff / 3600);
  diff -= h * 3600;
  const m = Math.floor(diff / 60);
  const s = diff - m * 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return { h: pad(h), m: pad(m), s: pad(s) };
}

export function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export function classNames(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(' ');
}
