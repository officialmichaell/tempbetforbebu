#!/usr/bin/env node
/**
 * TemP — lightweight SQL migration runner.
 *
 * Usage:
 *   node database/migrate.js up      # apply all pending migrations
 *   node database/migrate.js status  # show applied migrations
 *
 * Reads DATABASE_URL from the environment (or .env at repo root).
 * Migrations live in database/migrations/*.sql and are applied in filename order.
 * Applied migrations are tracked in the schema_migrations table.
 */
const fs = require('node:fs');
const path = require('node:path');

function loadEnv() {
  const candidates = [path.join(__dirname, '..', '.env'), path.join(process.cwd(), '.env')];
  for (const file of candidates) {
    if (fs.existsSync(file)) {
      for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
        const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
        if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
      }
      break;
    }
  }
}

async function main() {
  loadEnv();
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error('✗ DATABASE_URL is not set. Copy .env.example to .env and configure it.');
    process.exit(1);
  }

  let pg;
  try {
    pg = require('pg');
  } catch {
    console.error('✗ The "pg" package is required. Run: npm install');
    process.exit(1);
  }

  const client = new pg.Client({ connectionString: url });
  await client.connect();

  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      name VARCHAR PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);

  const dir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  const applied = new Set((await client.query('SELECT name FROM schema_migrations')).rows.map((r) => r.name));

  const cmd = process.argv[2] ?? 'up';

  if (cmd === 'status') {
    for (const f of files) console.log(`${applied.has(f) ? '✓' : '·'} ${f}`);
    await client.end();
    return;
  }

  let count = 0;
  for (const f of files) {
    if (applied.has(f)) continue;
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    console.log(`→ applying ${f}`);
    await client.query('BEGIN');
    try {
      await client.query(sql);
      await client.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
      await client.query('COMMIT');
      count++;
    } catch (e) {
      await client.query('ROLLBACK');
      console.error(`✗ failed ${f}:`, e.message);
      await client.end();
      process.exit(1);
    }
  }
  console.log(count ? `✓ applied ${count} migration(s)` : '✓ database is up to date');
  await client.end();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
