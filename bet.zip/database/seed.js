#!/usr/bin/env node
/**
 * TemP — deterministic seed runner.
 *
 * Usage: node database/seed.js
 *
 * Seeds sports, leagues, events, markets, odds, games, promotions, promo codes,
 * agents, admin users and a demo user with a ledger-derived wallet.
 * All data is DEMO ONLY. Idempotent: re-running will not duplicate rows.
 */
const fs = require('node:fs');
const path = require('node:path');

function loadEnv() {
  const candidates = [path.join(__dirname, '..', '.env'), path.join(process.cwd(), '.env')];
  for (const file of candidates) {
    if (fs.existsSync(file)) {
      for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
        const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
        if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
      }
      break;
    }
  }
}

// Deterministic PRNG (mulberry32) — mirrors packages/utils
function seededRandom(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SPORTS = [
  { key: 'football', name: 'Football', icon: '⚽' },
  { key: 'basketball', name: 'Basketball', icon: '🏀' },
  { key: 'tennis', name: 'Tennis', icon: '🎾' },
  { key: 'volleyball', name: 'Volleyball', icon: '🏐' },
  { key: 'esports', name: 'Esports', icon: '🎮' },
  { key: 'horse', name: 'Horse Racing', icon: '🐎' },
];

const TEAMS = {
  football: ['Manchester United', 'Arsenal', 'Chelsea', 'Liverpool', 'Real Madrid', 'Barcelona', 'Saint George SC', 'Fasil Kenema'],
  basketball: ['Lakers', 'Celtics', 'Warriors', 'Bulls', 'Heat', 'Nuggets'],
  tennis: ['Djokovic', 'Alcaraz', 'Sinner', 'Medvedev'],
  volleyball: ['Italy', 'Brazil', 'Poland', 'France'],
  esports: ['NAVI', 'FaZe', 'G2', 'Vitality'],
  horse: ['Thunder Bolt', 'Silver Arrow', 'Desert King', 'Night Fury'],
};

const LEAGUES = {
  football: 'Premier League', basketball: 'NBA', tennis: 'ATP Masters',
  volleyball: 'Nations League', esports: 'CS2 Major', horse: 'Addis Derby',
};

const GAME_DEFS = [
  ['Football', 'Sports', 'Sportsbook'], ['Basketball', 'Sports', 'Sportsbook'], ['Tennis', 'Sports', 'Sportsbook'],
  ['Volleyball', 'Sports', 'Sportsbook'], ['Baseball', 'Sports', 'Sportsbook'], ['Ice Hockey', 'Sports', 'Sportsbook'],
  ['Handball', 'Sports', 'Sportsbook'], ['Rugby', 'Sports', 'Sportsbook'], ['Boxing', 'Sports', 'Sportsbook'],
  ['Esports', 'Sports', 'Sportsbook'], ['Roulette', 'Table Games', 'TemP Originals'], ['Blackjack', 'Table Games', 'TemP Originals'],
  ['Baccarat', 'Table Games', 'TemP Originals'], ['Dice', 'Casino', 'TemP Originals'], ['Keno', 'Lottery', 'TemP Originals'],
  ['Mines', 'Casino', 'TemP Originals'], ['Plinko', 'Crash', 'TemP Originals'], ['Crash', 'Crash', 'TemP Originals'],
  ['Wheel', 'Casino', 'TemP Originals'], ['Sic Bo', 'Table Games', 'TemP Originals'], ['Golden Fortune', 'Slots', 'TemP Slots'],
  ['Royal Gems', 'Slots', 'TemP Slots'], ['Lucky Pharaoh', 'Slots', 'TemP Slots'], ['Dragon Treasure', 'Slots', 'TemP Slots'],
  ['Ocean Riches', 'Slots', 'TemP Slots'], ['Mystic Fruits', 'Slots', 'TemP Slots'], ['Diamond Vault', 'Slots', 'TemP Slots'],
  ['Fire Coins', 'Slots', 'TemP Slots'], ['Golden Chicken', 'Slots', 'TemP Slots'], ['Star Fortune', 'Slots', 'TemP Slots'],
  ['Virtual Horse Racing', 'Live', 'TemP Virtuals'], ['Virtual Greyhound Racing', 'Live', 'TemP Virtuals'],
  ['Virtual Football', 'Live', 'TemP Virtuals'], ['Virtual Basketball', 'Live', 'TemP Virtuals'],
  ['Penalty Shootout', 'Sports', 'TemP Virtuals'], ['Lucky Numbers', 'Lottery', 'TemP Virtuals'],
  ['Tower', 'Crash', 'TemP Originals'], ['Coin Flip', 'Casino', 'TemP Originals'], ['Hi-Lo', 'Casino', 'TemP Originals'],
  ['Jackpot', 'Popular', 'TemP Originals'],
];

const PROMOTIONS = [
  ['Welcome Bonus', 'Get a 100% bonus on your first deposit up to 5,000 ETB.', 'welcome', 'NEW PLAYERS', 'Claim'],
  ['Daily Free Bet', 'Place any bet today and receive a 50 ETB free bet.', 'freebet', 'DAILY', 'Get Free Bet'],
  ['Deposit Bonus', 'Deposit 1,000 ETB and get 200 ETB bonus instantly.', 'deposit', 'HOT', 'Deposit'],
  ['Weekly Tournament', 'Compete for a 50,000 ETB prize pool every week.', 'tournament', 'PRIZE POOL', 'Join'],
  ['Daily Missions', 'Complete missions to earn points and rewards.', 'mission', 'MISSIONS', 'View'],
  ['Loyalty Rewards', 'Earn rewards every time you play. Level up for more.', 'reward', 'REWARDS', 'Explore'],
];

const PROMO_CODES = [
  ['TEMP100', 100, true], ['WELCOME', 250, true], ['EXPIRED', 0, false], ['VIPONLY', 500, true],
];

const AGENTS = [
  ['Addis Central', 'addis_agent', '+251911000001'],
  ['Bole Hub', 'bole_agent', '+251911000002'],
  ['Merkato Point', 'merkato_agent', '+251911000003'],
  ['Kazanchis Agent', 'kazanchis_agent', '+251911000004'],
  ['Piassa Corner', 'piassa_agent', '+251911000005'],
  ['Hawassa Branch', 'hawassa_agent', '+251911000006'],
];

async function main() {
  loadEnv();
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error('✗ DATABASE_URL is not set.');
    process.exit(1);
  }
  let pg;
  try { pg = require('pg'); } catch { console.error('✗ "pg" required. Run npm install'); process.exit(1); }

  const client = new pg.Client({ connectionString: url });
  await client.connect();
  const rng = seededRandom(20240907);

  // Sports + leagues + events + markets + odds
  for (const s of SPORTS) {
    const sport = await client.query(
      `INSERT INTO sports(key,name,icon) VALUES($1,$2,$3)
       ON CONFLICT (key) DO UPDATE SET name=EXCLUDED.name, icon=EXCLUDED.icon RETURNING id`,
      [s.key, s.name, s.icon],
    );
    const sportId = sport.rows[0].id;
    const league = await client.query(
      `INSERT INTO leagues(sport_id,name) SELECT $1,$2 WHERE NOT EXISTS (SELECT 1 FROM leagues WHERE sport_id=$1 AND name=$2) RETURNING id`,
      [sportId, LEAGUES[s.key]],
    );
    const leagueId = league.rows[0]?.id ?? (await client.query('SELECT id FROM leagues WHERE sport_id=$1 AND name=$2', [sportId, LEAGUES[s.key]])).rows[0].id;

    const teams = TEAMS[s.key];
    const count = s.key === 'football' ? 8 : 4;
    for (let i = 0; i < count; i++) {
      const home = teams[(i * 2) % teams.length];
      let away = teams[(i * 2 + 1) % teams.length];
      if (away === home) away = teams[(i * 2 + 2) % teams.length];
      const isLive = i % 3 === 0;
      const start = new Date(Date.now() + (isLive ? -1 : 1) * (i + 1) * 3600e3);
      const ev = await client.query(
        `INSERT INTO events(sport_id,league_id,home,away,start_time,is_live)
         SELECT $1,$2,$3,$4,$5,$6 WHERE NOT EXISTS (SELECT 1 FROM events WHERE sport_id=$1 AND home=$3 AND away=$4) RETURNING id`,
        [sportId, leagueId, home, away, start.toISOString(), isLive],
      );
      if (!ev.rows[0]) continue;
      const eventId = ev.rows[0].id;
      const mk = await client.query(`INSERT INTO markets(event_id,name) VALUES($1,'Match Result') RETURNING id`, [eventId]);
      const marketId = mk.rows[0].id;
      const base = Math.round((1.4 + rng() * 2.6) * 100) / 100;
      const draw = Math.round((2.8 + rng() * 1.6) * 100) / 100;
      const awayOdds = Math.round((1.6 + rng() * 3.2) * 100) / 100;
      for (const [name, odds] of [['Home', base], ['Draw', draw], ['Away', awayOdds]]) {
        await client.query(`INSERT INTO odds(market_id,name,odds) VALUES($1,$2,$3)`, [marketId, name, odds]);
      }
    }
  }

  // Games (40 launch + 10 coming soon)
  for (let i = 0; i < GAME_DEFS.length; i++) {
    const [title, category, provider] = GAME_DEFS[i];
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    await client.query(
      `INSERT INTO games(slug,title,category,provider,coming_soon,active)
       VALUES($1,$2,$3,$4,false,true) ON CONFLICT (slug) DO NOTHING`,
      [slug, title, category, provider],
    );
  }
  for (let i = 0; i < 10; i++) {
    await client.query(
      `INSERT INTO games(slug,title,category,provider,coming_soon,active)
       VALUES($1,$2,'New','TemP',true,false) ON CONFLICT (slug) DO NOTHING`,
      [`coming-soon-${i + 1}`, `Coming Soon ${i + 1}`],
    );
  }

  // Promotions
  for (const [title, description, category, badge, cta] of PROMOTIONS) {
    await client.query(
      `INSERT INTO promotions(title,description,category,badge,cta,active)
       SELECT $1,$2,$3,$4,$5,true WHERE NOT EXISTS (SELECT 1 FROM promotions WHERE title=$1)`,
      [title, description, category, badge, cta],
    );
  }

  // Promo codes
  for (const [code, reward, active] of PROMO_CODES) {
    await client.query(
      `INSERT INTO promo_codes(code,reward,active) VALUES($1,$2,$3) ON CONFLICT (code) DO UPDATE SET reward=EXCLUDED.reward, active=EXCLUDED.active`,
      [code, reward, active],
    );
  }

  // Agents
  for (const [name, tg, phone] of AGENTS) {
    await client.query(
      `INSERT INTO agents(name,telegram_username,phone,status)
       SELECT $1,$2,$3,'active' WHERE NOT EXISTS (SELECT 1 FROM agents WHERE name=$1)`,
      [name, tg, phone],
    );
  }

  // Admin users (password hashes are placeholders — replace in production)
  const admins = [
    ['owner@temp.et', 'Owner', 'super_admin'],
    ['finance@temp.et', 'Finance Lead', 'finance'],
    ['support@temp.et', 'Support Agent', 'support'],
    ['agents@temp.et', 'Agent Manager', 'agent_manager'],
  ];
  for (const [email, name, role] of admins) {
    await client.query(
      `INSERT INTO admin_users(email,name,password_hash,role,two_factor_enabled)
       VALUES($1,$2,'$2b$10$REPLACE_ME_WITH_REAL_HASH',$3,true) ON CONFLICT (email) DO NOTHING`,
      [email, name, role],
    );
  }

  // Demo user + wallet + ledger
  const demo = await client.query(
    `INSERT INTO users(telegram_id,telegram_username,first_name,last_name,status,language)
     VALUES(700000001,'abebe_demo','Abebe','Kebede','active','en')
     ON CONFLICT (telegram_id) DO UPDATE SET first_name=EXCLUDED.first_name RETURNING id`,
  );
  const userId = demo.rows[0].id;
  const wallet = await client.query(
    `INSERT INTO wallets(user_id,balance,bonus_balance,pending_balance,currency)
     VALUES($1,0,0,0,'ETB') ON CONFLICT (user_id) DO UPDATE SET user_id=EXCLUDED.user_id RETURNING id`,
    [userId],
  );
  const walletId = wallet.rows[0].id;

  const ledger = [
    ['deposit', 500, 'Agent deposit', 'seed_deposit_1'],
    ['bet_stake', -100, 'Bet on Man Utd vs Arsenal', 'seed_bet_1'],
    ['bet_win', 180, 'Bet won', 'seed_win_1'],
    ['withdrawal', -200, 'Withdrawal to Telebirr', 'seed_wd_1'],
    ['cashback', 45, 'Daily cashback', 'seed_cb_1'],
  ];
  let running = 0;
  for (const [type, amount, description, key] of ledger) {
    running = Math.round((running + amount) * 100) / 100;
    await client.query(
      `INSERT INTO wallet_transactions(wallet_id,user_id,type,amount,balance_after,description,idempotency_key)
       VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (idempotency_key) DO NOTHING`,
      [walletId, userId, type, amount, running, description, key],
    );
  }
  await client.query(`UPDATE wallets SET balance=$2 WHERE id=$1`, [walletId, running]);

  // Cashback + streak for demo user
  await client.query(
    `INSERT INTO cashback(user_id,percentage,accumulated) VALUES($1,5,45) ON CONFLICT (user_id) DO NOTHING`,
    [userId],
  );
  await client.query(
    `INSERT INTO streaks(user_id,current,best) VALUES($1,5,12) ON CONFLICT (user_id) DO NOTHING`,
    [userId],
  );

  // Notifications for demo user
  const notifs = [
    ['deposit', 'Deposit Approved', 'Your deposit of 500 ETB has been approved.'],
    ['bet_result', 'Bet Won 🎉', 'Your accumulator won 1,240 ETB.'],
    ['promotion', 'New Promotion', 'Weekly tournament with 50,000 ETB prize pool is live.'],
  ];
  for (const [type, title, body] of notifs) {
    await client.query(
      `INSERT INTO notifications(user_id,type,title,body) SELECT $1,$2,$3,$4 WHERE NOT EXISTS (SELECT 1 FROM notifications WHERE user_id=$1 AND title=$3)`,
      [userId, type, title, body],
    );
  }

  console.log('✓ seed complete');
  console.log(`  sports: ${SPORTS.length}, games: ${GAME_DEFS.length + 10}, promotions: ${PROMOTIONS.length}`);
  console.log(`  demo user: Abebe Kebede (telegram_id 700000001), balance ${running} ETB`);
  await client.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
